<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DCTI - Home</title>
  <link rel="stylesheet" href="css/style.css">
  <!-- FontAwesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

  <!-- Hero Section -->
  <section class="hero">
    <div class="container">
      <h1>Master IT Skills & Dominate the Digital World</h1>
      <p>DCTI is committed to transforming manpower into valuable assets...</p>
      <a href="#" class="btn">Browse Course</a>
      <a href="#" class="btn">Join free seminar</a>
    </div>
  </section>

  <!-- Free Seminar -->
  <section class="seminar">
    <h2>Join Our Free Seminars</h2>
    <p>Looking for guidance in choosing the right course?...</p>
    <a href="#" class="btn">Register</a>
  </section>

  <!-- Category Icons -->
  <section class="categories">
    <div class="container">
      <div class="cat-list">
        <div class="cat-item">
          <i class="fa-solid fa-house"></i>
          <h3>Basic Computer</h3>
        </div>
        <div class="cat-item">
          <i class="fa-solid fa-bullhorn"></i>
          <h3>Digital Marketing</h3>
        </div>
        <div class="cat-item">
          <i class="fa-solid fa-code"></i>
          <h3>Web & Software</h3>
        </div>
        <div class="cat-item">
          <i class="fa-solid fa-photo-film"></i>
          <h3>Graphic Design</h3>
        </div>
        <div class="cat-item">
          <i class="fa-solid fa-car"></i>
          <h3>Driving</h3>
        </div>
      </div>
    </div>
  </section>

  <!-- Popular Courses -->
  <section class="popular-courses">
    <h2>Popular Courses</h2>
    <div class="course-list">
      <div class="course">
        <img src="basic-computer.jpg" alt="Basic Computer">
        <h3>Basic Computer</h3>
        <p>Course Fee 3,000</p>
        <a href="#" class="btn">Enroll Now</a>
      </div>
      <div class="course">
        <img src="freelancing.jpg" alt="Data Entry">
        <h3>Data Entry & Freelancing</h3>
        <p>Course Fee 5,000</p>
        <a href="#" class="btn">Enroll Now</a>
      </div>
    </div>
  </section>

  <!-- Support Section -->
  <section class="support">
    <h2>Unique Solutions That Distinguish Us</h2>
    <div class="features">
      <div class="feature">Lifetime Support</div>
      <div class="feature">Career Placement Support</div>
      <div class="feature">Class Videos</div>
    </div>
  </section>

  <!-- Community Section -->
  <section class="community">
    <h2>Join Our Community</h2>
    <div class="videos">
      <!-- এখানে YouTube Embed কোড দাও -->
    </div>
  </section>

  <!-- Stats Section -->
  <section class="stats">
    <div>2,500+ Successful Students</div>
    <div>1,000+ Expert Freelancers</div>
    <div>1,200+ Skilled Job Holders</div>
    <div>250+ Companies</div>
  </section>

</body>
</html>
