<?php
// includes/auth.php

function requireStudent() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
        header("Location: ../login.php");
        exit;
    }
}

function requireAdmin() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        header("Location: ../login.php");
        exit;
    }
}

function requireTeacher() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit;
    }
    global $pdo;
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $role = $stmt->fetchColumn();
    if ($role !== 'teacher' && $role !== 'admin') {
        http_response_code(403);
        echo "Forbidden";
        exit;
    }
}

function getUserData($pdo, $userId) {
    $stmt = $pdo->prepare("
        SELECT u.*, p.avatar_url, sa.students_english_name, sa.students_bangla_name
        FROM users u
        LEFT JOIN profiles p ON u.id = p.user_id
        LEFT JOIN students_admission sa ON u.id = sa.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}
