<?php
// includes/config.php

$host = 'localhost';
$db   = 'dctiedu';
$user = 'root';      // ← Update as needed
$pass = '';          // ← Update as needed
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // For development, show detailed error
    if (isset($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'], 'localhost') !== false) {
        die("Database connection failed: " . $e->getMessage());
    } else {
        // For production, show generic error
        die("Database connection failed. Please contact administrator.");
    }
}

// Start session
session_start();
?>