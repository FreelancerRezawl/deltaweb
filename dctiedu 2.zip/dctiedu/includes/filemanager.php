<?php
// includes/filemanager.php

function uploadFile($file, $type) {
    $uploadDir = __DIR__ . '/../uploads/';
    $allowedTypes = [
        'student_photo' => ['jpg', 'jpeg', 'png', 'webp'],
        'assignment' => ['pdf', 'doc', 'docx', 'txt', 'zip'],
        'lesson_content' => ['mp4', 'pdf', 'mov', 'avi'],
        'certificate' => ['pdf']
    ];

    $maxSize = 20 * 1024 * 1024; // 20MB

    if (!isset($allowedTypes[$type])) {
        return ['error' => 'Invalid upload type.'];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'File upload error: ' . $file['error']];
    }

    if ($file['size'] > $maxSize) {
        return ['error' => 'File too large. Max 20MB allowed.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedTypes[$type])) {
        return ['error' => 'Invalid file type for ' . $type];
    }

    // Sanitize and create unique filename
    $originalName = basename($file['name']);
    $safeName = preg_replace('/[^A-Za-z0-9\-_\.]/', '_', $originalName);
    $filename = uniqid() . '__' . time() . '__' . $safeName;
    $folderMap = [
        'student_photo' => 'students/',
        'assignment' => 'assignments/',
        'lesson_content' => 'lessons/',
        'certificate' => 'certificates/'
    ];

    $targetDir = $uploadDir . $folderMap[$type];
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $targetPath = $targetDir . $filename;

    // Additional security: check actual file size
    if (filesize($file['tmp_name']) > $maxSize) {
        return ['error' => 'File too large.'];
    }

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        // Return relative path for DB storage
        return ['success' => 'uploads/' . $folderMap[$type] . $filename];
    } else {
        return ['error' => 'Failed to move uploaded file.'];
    }
}

function downloadFile($filePath) {
    if (!file_exists($filePath)) {
        die('File not found.');
    }

    $filename = basename($filePath);
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit;
}

function getFileUrl($relativePath) {
    // Returns public URL for display (e.g., in <img> or <a>)
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    return $protocol . $host . $basePath . '/' . ltrim($relativePath, '/');
}
?>