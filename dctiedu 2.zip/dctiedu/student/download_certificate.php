<?php
// student/download_certificate.php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/filemanager.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$certId = $_GET['id'] ?? 0;
$studentId = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT c.pdf_url 
    FROM certificates c
    JOIN enrollments e ON c.enrollment_id = e.id
    WHERE c.id = ? AND e.student_id = ?
");
$stmt->execute([$certId, $studentId]);
$cert = $stmt->fetch();

if (!$cert || !$cert['pdf_url']) {
    die("Certificate not found or access denied.");
}

// Trigger download
downloadFile(__DIR__ . '/../' . $cert['pdf_url']);
?>