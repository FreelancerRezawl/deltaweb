<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Student Portal Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root{
      --bg:#f3ecff;
      --panel:#ffffff;
      --ink:#1a102c;
      --muted:#7d6aa6;
      --brand:#7a4cff; /* primary purple */
      --brand-2:#a47cff; /* lighter */
      --brand-3:#e9ddff; /* light surface */
      --ring: rgba(122,76,255,.35);
      --radius:18px;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0; background:linear-gradient(180deg,var(--bg),#efe7ff 60%, #e9e1ff);
      font-family:"Poppins", system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji","Segoe UI Emoji";
      color:var(--ink);
    }
    .app{max-width:1200px; margin:40px auto; padding:0 24px}
    .shell{display:grid; grid-template-columns:260px 1fr; gap:24px}

    /* Sidebar */
    .sidebar{
      background:linear-gradient(160deg, #8b63ff, #6237ff 55%);
      border-radius:calc(var(--radius) + 6px);
      padding:22px 16px; color:#fff; position:relative; overflow:hidden;
      box-shadow:0 10px 30px rgba(83, 56, 255, .25);
    }
    .sb-brand{
      display:flex; align-items:center; gap:12px; padding:8px 12px; margin-bottom:10px;
    }
    .logo{
      width:46px; height:46px; border-radius:12px; background:#fff2; display:grid; place-items:center;
      box-shadow: inset 0 0 0 2px #ffffff22;
    }
    .logo svg{width:26px; height:26px; fill:#fff}
    .brand-title{font-weight:700; letter-spacing:.2px}

    .sb-nav{margin-top:12px}
    .sb-item{
      display:flex; align-items:center; gap:12px; color:#f0eaff; text-decoration:none;
      padding:12px 14px; border-radius:14px; font-weight:500; opacity:.95;
    }
    .sb-item svg{width:20px; height:20px; fill:#f0eaff}
    .sb-item:hover{background:#ffffff12}
    .sb-item.active{background:#fff; color:#5b3bff}
    .sb-item.active svg{fill:#5b3bff}

    .sb-spacer{height:12px}
    .logout{position:absolute; left:16px; right:16px; bottom:16px}
    .logout .sb-item{justify-content:center; background:#fff1;}

    /* Top bar */
    .topbar{display:flex; align-items:center; gap:16px}
    .search{
      flex:1; background:#fff; border-radius:999px; padding:10px 16px; display:flex; align-items:center; gap:10px;
      border:1px solid #eee; box-shadow:0 1px 0 rgba(0,0,0,.04);
    }
    .search input{border:none; outline:none; flex:1; font:500 14px Poppins; color:var(--ink)}
    .search svg{width:18px; height:18px; fill:#9b8ac6}

    .user-chip{display:flex; align-items:center; gap:10px; background:#fff; border-radius:999px; padding:6px 10px; border:1px solid #eee}
    .avatar{width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,#ffc06b,#ff7d7d); display:grid; place-items:center; color:#fff; font-weight:700}

    /* Banner */
    .banner{
      margin-top:20px; background:linear-gradient(130deg, var(--brand), var(--brand-2)); color:#fff; border-radius:var(--radius);
      padding:28px; position:relative; overflow:hidden; min-height:140px;
    }
    .banner::after{
      content:""; position:absolute; inset:auto -20% -30% -20%; height:160px; background:radial-gradient( circle at 50% 0%, #fff2 0 30%, transparent 31% ), radial-gradient(circle at 20% 40%, #fff2 0 18%, transparent 19%), radial-gradient(circle at 80% 60%, #fff2 0 14%, transparent 15%);
      filter:blur(10px);
    }
    .banner h2{margin:0 0 8px; font-weight:700}
    .banner p{margin:0; opacity:.9}
    .date-tag{position:absolute; top:16px; left:16px; background:#ffffff1a; border:1px solid #ffffff30; padding:6px 10px; border-radius:999px; font-size:12px}
    .mascot{position:absolute; right:24px; bottom:0; transform:translateY(18%); width:190px; height:150px; background:radial-gradient(60% 60% at 50% 50%, #ffffffa8 0, #ffffff00 70%); border-radius:999px; filter:blur(6px);}

    /* Main grid */
    .grid{
      display:grid; grid-template-columns:1.8fr .9fr; gap:24px; margin-top:24px;
    }

    /* Cards */
    .card{background:var(--panel); border-radius:var(--radius); box-shadow:0 8px 25px rgba(95,77,182,.12); border:1px solid #eee}
    .card.pad{padding:18px}
    .section-title{font-size:18px; font-weight:700; margin:0 0 12px}

    /* Finance */
    .finance-cards{display:grid; grid-template-columns:repeat(3, 1fr); gap:14px}
    .mini{
      border-radius:16px; padding:16px; border:1px solid #eee; background:#fff; display:grid; gap:8px; align-content:start; position:relative;
    }
    .mini.highlight{outline:3px solid var(--brand-3)}
    .stat-icon{width:38px; height:38px; border-radius:12px; background:linear-gradient(135deg,var(--brand-3),#fff); display:grid; place-items:center;}
    .stat-icon svg{width:22px; height:22px; fill:var(--brand)}
    .stat-value{font-weight:700; font-size:20px}
    .stat-label{font-size:13px; color:#6c5a97}

    /* Courses */
    .courses{display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-top:12px}
    .course{
      display:grid; grid-template-columns:auto 1fr auto; gap:12px; align-items:center; padding:14px; border-radius:16px; border:1px solid #eee; background:linear-gradient(135deg,#fff, #faf7ff);
    }
    .course .thumb{width:48px; height:48px; border-radius:12px; background:linear-gradient(135deg,#efe6ff,#fff)}
    .course h4{margin:0; font-size:15px}
    .course .view{padding:8px 14px; border-radius:999px; background:var(--brand); color:#fff; text-decoration:none; font-weight:600; font-size:13px; box-shadow:0 6px 18px var(--ring)}

    .see-all{font-size:13px; color:var(--brand); font-weight:600; text-decoration:none}

    /* Right rail */
    .instructors{display:flex; gap:10px}
    .inst{width:44px; height:44px; border-radius:50%; background:linear-gradient(135deg,#ffb6a8,#ff6b8b); border:3px solid #fff; box-shadow:0 6px 18px rgba(0,0,0,.08)}
    .inst:nth-child(2){background:linear-gradient(135deg,#8fd2ff,#7a8bff)}
    .inst:nth-child(3){background:linear-gradient(135deg,#ffd37f,#ff9b52)}

    .notice{display:grid; gap:12px}
    .note{padding:14px; border-radius:14px; border:1px solid #eee; background:#fff}
    .note h5{margin:0 0 6px; font-size:14px}
    .note p{margin:0; color:#6c5a97; font-size:13px}

    /* Utility */
    .row{display:flex; align-items:center; justify-content:space-between; gap:8px}
    .muted{color:#6c5a97}

    /* Responsive */
    @media (max-width: 1040px){
      .shell{grid-template-columns:1fr}
      .sidebar{display:flex; gap:14px; align-items:center; overflow:auto}
      .sb-nav{display:flex; gap:6px; margin:0}
      .logout{position:static}
    }
    @media (max-width: 860px){
      .grid{grid-template-columns:1fr}
    }
    @media (max-width: 560px){
      .finance-cards{grid-template-columns:1fr}
      .courses{grid-template-columns:1fr}
      .banner{padding-bottom:90px}
      .mascot{right:10px; width:140px; height:120px}
    }
  </style>
</head>
<body>
  <div class="app">
    <div class="shell">
      <!-- Sidebar -->
      <aside class="sidebar">
        <div class="sb-brand">
          <div class="logo" aria-hidden="true">
            <!-- Graduation Cap Icon -->
            <svg viewBox="0 0 24 24" role="img" aria-label="Graduation cap"><path d="M12 3 1 8l11 5 9-4.09V17h2V8L12 3Zm0 8.8L5.23 8.6 12 5.8l6.77 2.8L12 11.8ZM6 12.5v3.25C6 17.99 8.69 20 12 20s6-2.01 6-4.25V12.5l-6 2.5-6-2.5Z"/></svg>
          </div>
          <div>
            <div class="brand-title">UniPortal</div>
            <div style="font-size:12px; opacity:.8">Student</div>
          </div>
        </div>
        <nav class="sb-nav">
          <a class="sb-item active" href="#"><svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>Dashboard</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M21 7H3V5h18v2Zm0 4H3V9h18v2Zm0 4H3v-2h18v2Zm0 4H3v-2h18v2Z"/></svg>Payment Info</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M19 3H5a2 2 0 0 0-2 2v14l4-4h12a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2Z"/></svg>Registration</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M4 6h16v2H4zM4 11h16v2H4zm0 5h10v2H4z"/></svg>Courses</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M17 10H7v4h10v-4Zm2-6H5a2 2 0 0 0-2 2v12l4-3h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Z"/></svg>Drop Semester</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M11 17h2V7h-2v10Zm-4 0h2V11H7v6Zm8 0h2V9h-2v8Z"/></svg>Result</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M20 6H4v2h16V6Zm0 5H4v2h16v-2Zm0 5H4v2h16v-2Z"/></svg>Notice</a>
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M19 4H5v2h14V4ZM4 20h16v-2H4v2Zm1-9h14v2H5v-2Z"/></svg>Schedule</a>
        </nav>
        <div class="logout">
          <a class="sb-item" href="#"><svg viewBox="0 0 24 24"><path d="M10 17v-3h4v3l4-4-4-4v3h-4V5H5v14h5Z"/></svg>Logout</a>
        </div>
      </aside>

      <!-- Content -->
      <main>
        <!-- Topbar -->
        <div class="topbar">
          <div class="search">
            <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5Zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14Z"/></svg>
            <input placeholder="Search" />
          </div>
          <div class="user-chip">
            <div class="avatar">JD</div>
            <div>
              <div style="font-weight:600; font-size:13px">John Doe</div>
              <div class="muted" style="font-size:12px">3rd year</div>
            </div>
          </div>
        </div>

        <!-- Banner -->
        <section class="banner card">
          <div class="date-tag">September 4, 2023</div>
          <h2>Welcome back, John!</h2>
          <p>Always stay updated in your student portal.</p>
          <div class="mascot" aria-hidden="true"></div>
        </section>

        <div class="grid">
          <!-- Left column: Finance + Courses -->
          <section class="card pad">
            <div class="row">
              <h3 class="section-title">Finance</h3>
            </div>
            <div class="finance-cards">
              <div class="mini">
                <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 18h18v2H3v-2Zm2-5h3v4H5v-4Zm5-3h3v7h-3V10Zm5-4h3v11h-3V6Z"/></svg></div>
                <div class="stat-value">$ 10,000</div>
                <div class="stat-label">Total Payable</div>
              </div>
              <div class="mini highlight">
                <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4Zm0 17.9c-2.5-.77-4.5-3.36-4.92-6.5H12v-7l7 3v4.5c0 3.46-2.1 6.62-5 7.99Z"/></svg></div>
                <div class="stat-value">$ 5,000</div>
                <div class="stat-label">Total Paid</div>
              </div>
              <div class="mini">
                <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 17h18v2H3v-2Zm0-7h18v2H3V10Zm0-7h18v2H3V3Z"/></svg></div>
                <div class="stat-value">$ 300</div>
                <div class="stat-label">Others</div>
              </div>
            </div>

            <div class="row" style="margin-top:22px">
              <h3 class="section-title">Enrolled Courses</h3>
              <a class="see-all" href="#">See all</a>
            </div>
            <div class="courses">
              <article class="course">
                <div class="thumb" aria-hidden="true"></div>
                <div>
                  <h4>Object oriented programming</h4>
                  <div class="muted" style="font-size:12px">CSE 220 • 3 credits</div>
                </div>
                <a class="view" href="#">View</a>
              </article>
              <article class="course">
                <div class="thumb" aria-hidden="true"></div>
                <div>
                  <h4>Fundamentals of database systems</h4>
                  <div class="muted" style="font-size:12px">CSE 310 • 3 credits</div>
                </div>
                <a class="view" href="#">View</a>
              </article>
            </div>
          </section>

          <!-- Right rail -->
          <section class="card pad">
            <div class="row">
              <h3 class="section-title">Course instructors</h3>
              <a class="see-all" href="#">See all</a>
            </div>
            <div class="instructors">
              <div class="inst" title="Sarah" aria-label="Sarah"></div>
              <div class="inst" title="Raj" aria-label="Raj"></div>
              <div class="inst" title="Miguel" aria-label="Miguel"></div>
            </div>

            <div class="row" style="margin-top:22px">
              <h3 class="section-title">Daily notice</h3>
              <a class="see-all" href="#">See all</a>
            </div>
            <div class="notice">
              <div class="note">
                <h5>Prelim payment due</h5>
                <p>Sorem ipsum dolor sit amet, consectetur adipiscing elit. <a class="see-all" href="#">See more</a></p>
              </div>
              <div class="note">
                <h5>Exam schedule</h5>
                <p>Nunc vulputate libero et velit interdum, ac aliquet odio mattis. <a class="see-all" href="#">See more</a></p>
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  </div>
</body>
</html>