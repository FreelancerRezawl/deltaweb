<?php
// student/submit_assignment.php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/filemanager.php';

// Simple auth check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$assignmentId = $_GET['assignment_id'] ?? 0;
$studentId = $_SESSION['user_id'];

if ($_POST) {
    $error = null; // Initialize error variable
    $textAnswer = $_POST['text_answer'] ?? null;
    $fileUrl = null;

    if (!empty($_FILES['file']['name'])) {
        $uploadResult = uploadFile($_FILES['file'], 'assignment');
        if (isset($uploadResult['error'])) {
            $error = $uploadResult['error'];
        } else {
            $fileUrl = $uploadResult['success'];
        }
    }

    if (!$error) {
        // Validate required fields
        if ($assignmentId <= 0) {
            $error = "Invalid assignment.";
        } elseif (empty($textAnswer) && empty($fileUrl)) {
            $error = "Please provide either a text answer or upload a file.";
        }
    }

    if (!$error) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO submissions
                (assignment_id, student_id, file_url, text_answer, submitted_at)
                VALUES (?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE
                file_url = VALUES(file_url),
                text_answer = VALUES(text_answer),
                submitted_at = NOW()
            ");
            $stmt->execute([$assignmentId, $studentId, $fileUrl, $textAnswer]);

            header("Location: assignments.php?submitted=1");
            exit;
        } catch (PDOException $e) {
            $error = "Submission failed: " . $e->getMessage();
        }
    }
}

// Fetch assignment details
$assignment = $pdo->prepare("
    SELECT a.title, a.instructions, a.due_at, l.title as lesson_title 
    FROM assignments a 
    JOIN lessons l ON a.lesson_id = l.id 
    WHERE a.id = ?
");
$assignment->execute([$assignmentId]);
$assignment = $assignment->fetch();

if (!$assignment) {
    die("Assignment not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submit Assignment</title>
    <meta charset="utf-8">
</head>
<body>
    <h2>Submit: <?= htmlspecialchars($assignment['title']) ?></h2>
    <p><strong>Lesson:</strong> <?= htmlspecialchars($assignment['lesson_title']) ?></p>
    <p><strong>Due:</strong> <?= $assignment['due_at'] ?></p>
    <p><strong>Instructions:</strong><br><?= nl2br(htmlspecialchars($assignment['instructions'])) ?></p>

    <?php if (isset($error)): ?>
        <p style="color:red;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <textarea name="text_answer" placeholder="Type your answer here..." rows="6" style="width:100%"></textarea><br><br>
        <input type="file" name="file"><br><br>
        <small>Allowed: PDF, DOC, TXT, ZIP (Max 20MB)</small><br><br>
        <button type="submit">Submit Assignment</button>
    </form>
    <a href="assignments.php">← Back to Assignments</a>
</body>
</html>