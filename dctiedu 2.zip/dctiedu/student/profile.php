<?php
// student/profile.php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/filemanager.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch user + profile + admission data
$user = $pdo->prepare("
    SELECT u.*, p.avatar_url, sa.students_bangla_name, sa.fathers_english_name, sa.student_photo as admission_photo
    FROM users u
    LEFT JOIN profiles p ON u.id = p.user_id
    LEFT JOIN students_admission sa ON u.id = sa.user_id
    WHERE u.id = ?
");
$user->execute([$userId]);
$user = $user->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <meta charset="utf-8">
</head>
<body>
    <h2>My Profile</h2>

    <?php if (!empty($user['avatar_url'])): ?>
        <img src="<?= getFileUrl($user['avatar_url']) ?>" width="150" style="border-radius:10px;"><br><br>
    <?php elseif (!empty($user['admission_photo'])): ?>
        <img src="<?= getFileUrl($user['admission_photo']) ?>" width="150" style="border-radius:10px;"><br><br>
    <?php else: ?>
        <img src="assets/images/default-avatar.png" width="150"><br><br>
    <?php endif; ?>

    <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Bangla Name:</strong> <?= htmlspecialchars($user['students_bangla_name'] ?? '-') ?></p>
    <p><strong>Father’s Name:</strong> <?= htmlspecialchars($user['fathers_english_name'] ?? '-') ?></p>

    <a href="dashboard.php">← Back to Dashboard</a>
</body>
</html>