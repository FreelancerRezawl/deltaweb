<?php
// admin/manage_courses.php
declare(strict_types=1);

require_once '../includes/config.php'; // must define $pdo (PDO to dctiedu)

if (session_status() === PHP_SESSION_NONE) session_start();

// ------------------------------ helpers ------------------------------
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function qs(array $overrides = []): string {
  $q = array_merge($_GET, $overrides);
  return http_build_query(array_filter($q, fn($v) => $v !== null && $v !== '' && $v !== 'all'));
}
function slugify(string $t): string {
  $t = strtolower(trim($t));
  $t = preg_replace('/[^a-z0-9]+/','-',$t);
  $t = trim($t,'-');
  return $t ?: uniqid('course-');
}
function price_to_cents(?string $s): ?int {
  if ($s === null || $s === '') return null;
  if (!is_numeric($s)) return null;
  return (int)round(((float)$s) * 100);
}
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

// ------------------------------ handle POST (create / delete) ------------------------------
$flash_ok = $flash_err = null;

// CREATE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
  if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
    $flash_err = "Invalid CSRF token.";
  } else {
    $title = trim((string)($_POST['title'] ?? ''));
    $slug  = trim((string)($_POST['slug'] ?? ''));
    $desc  = trim((string)($_POST['description'] ?? ''));
    $lang  = (string)($_POST['language'] ?? 'bn');
    $level = (string)($_POST['level'] ?? 'beginner');
    $price = price_to_cents($_POST['price'] ?? '');
    $sale  = price_to_cents($_POST['sale_price'] ?? '');
    $curr  = (string)($_POST['currency'] ?? 'BDT');
    $status= (string)($_POST['status'] ?? 'draft');
    $thumb = '';
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
      $uploadDir = 'uploads/courses/';
      if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
      $ext = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
      if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        $fileName = uniqid('course_thumb_') . '.' . $ext;
        $filePath = $uploadDir . $fileName;
        if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $filePath)) {
          $thumb = 'admin/uploads/courses/' . $fileName;
        } else {
          $flash_err = "Failed to upload thumbnail.";
        }
      } else {
        $flash_err = "Invalid image format.";
      }
    }

    if ($title === '') $flash_err = "Title is required.";
    if (!$flash_err) {
      if ($slug === '') $slug = slugify($title);
      // ensure unique slug
      $chk = $pdo->prepare("SELECT COUNT(*) FROM courses WHERE slug = ?");
      $chk->execute([$slug]);
      if ($chk->fetchColumn() > 0) {
        $slug = slugify($title.'-'.substr(bin2hex(random_bytes(2)),0,4));
      }
      // created_by - since no login, default to user id 1 (Admin)
      $createdBy = 1;

      $ins = $pdo->prepare("
        INSERT INTO courses
          (title, slug, description, language, level, price_cents, sale_price_cents, currency, status, thumbnail_url, created_by, created_at, updated_at)
        VALUES
          (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ");
      $ins->execute([
        $title, $slug, $desc ?: null, $lang, $level,
        $price ?? 0, $sale, $curr, $status, $thumb ?: null, $createdBy
      ]);
      $flash_ok = "Course “".h($title)."” created.";
      // Redirect to avoid resubmission
      header('Location: manage_courses.php?'.qs(['msg'=>$flash_ok]));
      exit;
    }
  }
}

// DELETE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
    $flash_err = "Invalid CSRF token.";
  } else {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
      // Optional: check dependencies; DB has ON DELETE CASCADE for many tables
      $del = $pdo->prepare("DELETE FROM courses WHERE id = ?");
      $del->execute([$id]);
      $flash_ok = "Course #$id deleted.";
      header('Location: manage_courses.php?'.qs(['msg'=>$flash_ok]));
      exit;
    } else {
      $flash_err = "Invalid course id.";
    }
  }
}

if (isset($_GET['msg'])) $flash_ok = (string)$_GET['msg'];

// ------------------------------ filters / sorting / paging ------------------------------
$q       = trim((string)($_GET['q'] ?? ''));
$status  = (string)($_GET['status'] ?? 'all');   // draft|published|archived|all
$level   = (string)($_GET['level'] ?? 'all');    // beginner|intermediate|advanced|all
$limit   = (int)($_GET['limit'] ?? 20);
$limit   = in_array($limit, [10,20,50,100], true) ? $limit : 20;
$page    = max(1, (int)($_GET['page'] ?? 1));

$sortAllow = [
  'id'=>'c.id','title'=>'c.title','price'=>'c.price_cents','status'=>'c.status',
  'level'=>'c.level','created'=>'c.created_at','updated'=>'c.updated_at'
];
$sort = (string)($_GET['sort'] ?? 'created');
$sortCol = $sortAllow[$sort] ?? 'c.created_at';
$dir  = strtolower((string)($_GET['dir'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';

$where = []; $params = [];
if ($status !== 'all') { $where[] = 'c.status = ?'; $params[] = $status; }
if ($level !== 'all')  { $where[] = 'c.level  = ?'; $params[] = $level; }
if ($q !== '') {
  $where[] = '(c.title LIKE ? OR c.slug LIKE ? OR c.description LIKE ?)';
  $like = '%'.$q.'%'; array_push($params, $like, $like, $like);
}
$whereSql = $where ? 'WHERE '.implode(' AND ', $where) : '';

$count = $pdo->prepare("SELECT COUNT(*) FROM courses c $whereSql");
$count->execute($params);
$totalRows = (int)$count->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $limit));
$offset = ($page - 1) * $limit;

// fetch rows + small counts
$sql = "
  SELECT
    c.*,
    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS enrolled_count,
    (SELECT COUNT(*) FROM course_instructors ci WHERE ci.course_id = c.id) AS instructor_count
  FROM courses c
  $whereSql
  ORDER BY $sortCol $dir
  LIMIT $limit OFFSET $offset
";
$st = $pdo->prepare($sql);
$st->execute($params);
$courses = $st->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manage Courses</title>
  <link rel="stylesheet" href="dashboard.css"/>
  <style>
    .toolbar{display:flex; gap:8px; flex-wrap:wrap; align-items:end; margin:16px 0}
    .toolbar .field{display:grid; gap:6px}
    .toolbar input,.toolbar select, .toolbar textarea{
      border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; font:500 14px system-ui; background:#fff;
    }
    .field{display:grid; gap:6px; margin-bottom:10px}
    input,select,textarea{border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; font:500 14px system-ui; background:#fff}
    label{font-weight:500}
    .btn{display:inline-block; padding:10px 12px; border-radius:10px; border:1px solid #c7d2fe; background:#eef2ff; color:#1e3a8a; font-weight:700; text-decoration:none}
    .btn.primary{background:#2563eb; color:#fff; border-color:#2563eb}
    .btn.danger{background:#dc2626; color:#fff; border-color:#dc2626}
    .btn.ghost{background:#fff}
    .card{background:#fff; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.05); padding:16px}
    .grid-2{display:grid; grid-template-columns:1fr 1fr; gap:16px}
    @media (max-width:900px){.grid-2{grid-template-columns:1fr}}
    table{width:100%; border-collapse:collapse}
    th,td{padding:12px 14px; border-bottom:1px solid #eef2f7; text-align:left; vertical-align:top}
    th{font-size:12px; text-transform:uppercase; letter-spacing:.04em; color:#6b7280}
    .muted{color:#6b7280; font-size:12px}
    .pill{display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; background:#f3f4f6; border:1px solid #e5e7eb}
    .pill.blue{background:#eff6ff; border-color:#bfdbfe; color:#1d4ed8}
    .pill.green{background:#ecfdf5; border-color:#bbf7d0; color:#065f46}
    .pill.orange{background:#fff7ed; border-color:#fed7aa; color:#9a3412}
    .row{display:flex; gap:10px; flex-wrap:wrap; align-items:center}
    .pagination{display:flex; gap:6px; justify-content:flex-end; margin-top:12px}
    .pagination a, .pagination span{padding:6px 10px; border-radius:8px; border:1px solid #e5e7eb; text-decoration:none; color:#111827; background:#fff}
    .pagination .active{background:#2563eb; color:#fff; border-color:#2563eb}
    .price{font-weight:800}
    .strike{text-decoration:line-through; color:#9ca3af; margin-left:6px}
    .thumb{width:56px; height:40px; object-fit:cover; border-radius:8px; border:1px solid #e5e7eb; background:#f3f4f6}
    .flash{margin:8px 0; padding:10px 12px; border-radius:10px; font-size:14px}
    .ok{background:#ecfeff; border:1px solid #a5f3fc; color:#155e75}
    .err{background:#fff1f2; border:1px solid #fecdd3; color:#9f1239}
  </style>
  <script>
    // Auto-generate slug from title (simple)
    function makeSlug(s){ return s.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,''); }
    function bindSlug() {
      const t = document.getElementById('title');
      const s = document.getElementById('slug');
      if (!t || !s) return;
      t.addEventListener('input', () => {
        if (s.dataset.touched === '1') return;
        s.value = makeSlug(t.value);
      });
      s.addEventListener('input', ()=> s.dataset.touched = '1');
    }
    document.addEventListener('DOMContentLoaded', bindSlug);
    function confirmDel(formId){
      if (confirm('Delete this course? This cannot be undone.')) {
        document.getElementById(formId).submit();
      }
    }
  </script>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="brand">DCti Admin</div>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_teachers.php">Manage Teachers</a></li>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="assign_teacher.php">Assign Teacher</a></li>
        <li><a href="course_edit.php">Course Edit</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="#">Settings</a></li>
      </ul>
    </aside>

    <!-- Main -->
    <main class="main">
      <header class="topbar">
        <h1>Manage Courses</h1>
        <span><?= date('F d, Y') ?></span>
      </header>

      <?php if ($flash_ok): ?><div class="flash ok"><?= $flash_ok ?></div><?php endif; ?>
      <?php if ($flash_err): ?><div class="flash err"><?= $flash_err ?></div><?php endif; ?>

      <!-- Create course + Filters -->
      <div class="grid-2">
        <!-- Create form -->
        <section class="card">
          <h3 style="margin-top:0">Add New Course</h3>
          <form method="post" enctype="multipart/form-data" class="row" style="align-items:stretch">
            <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="create">
            <div class="w100" style="flex:1 1 100%">
              <div class="row" style="gap:12px">
                <div class="field" style="flex:1 1 60%">
                  <label>Title *</label>
                  <input id="title" name="title" required placeholder="e.g. Basic Computer">
                </div>
                <div class="field" style="flex:1 1 40%">
                  <label>Slug</label>
                  <input id="slug" name="slug" placeholder="auto-from-title">
                </div>
              </div>

              <div class="field" style="margin-top:8px">
                <label>Description</label>
                <textarea name="description" rows="3" placeholder="Short summary..."></textarea>
              </div>

              <div class="row" style="gap:12px; margin-top:8px">
                <div class="field" style="flex:1">
                  <label>Language</label>
                  <select name="language">
                    <option value="bn">bn</option>
                    <option value="en">en</option>
                  </select>
                </div>
                <div class="field" style="flex:1">
                  <label>Level</label>
                  <select name="level">
                    <option value="beginner">beginner</option>
                    <option value="intermediate">intermediate</option>
                    <option value="advanced">advanced</option>
                  </select>
                </div>
                <div class="field" style="flex:1">
                  <label>Status</label>
                  <select name="status">
                    <option value="draft">draft</option>
                    <option value="published">published</option>
                    <option value="archived">archived</option>
                  </select>
                </div>
              </div>

              <div class="row" style="gap:12px; margin-top:8px">
                <div class="field" style="flex:1">
                  <label>Price (<?= h('BDT') ?>)</label>
                  <input type="number" step="0.01" name="price" placeholder="3000">
                </div>
                <div class="field" style="flex:1">
                  <label>Sale Price (optional)</label>
                  <input type="number" step="0.01" name="sale_price" placeholder="2500">
                </div>
                <div class="field" style="flex:1">
                  <label>Currency</label>
                  <select name="currency">
                    <option value="BDT">BDT</option>
                    <option value="USD">USD</option>
                  </select>
                </div>
              </div>

              <div class="field" style="margin-top:8px">
                <label>Thumbnail</label>
                <input type="file" name="thumbnail" accept="image/*">
              </div>

              <div class="row" style="margin-top:10px">
                <button class="btn primary" type="submit">Create Course</button>
                <a class="btn ghost" href="manage_courses.php">Reset</a>
              </div>
            </div>
          </form>
        </section>

        <!-- Filters -->
        <section class="card">
          <h3 style="margin-top:0">Filter Courses</h3>
          <form class="toolbar" method="get">
            <div class="field" style="flex:1 1 100%">
              <label>Search (title / slug / description)</label>
              <input type="text" name="q" value="<?= h($q) ?>" placeholder="Type to search...">
            </div>
            <div class="field">
              <label>Status</label>
              <select name="status">
                <?php
                  $opts = ['all'=>'All','draft'=>'draft','published'=>'published','archived'=>'archived'];
                  foreach ($opts as $k=>$v) { $sel=$status===$k?'selected':''; echo "<option value='".h($k)."' $sel>".h($v)."</option>"; }
                ?>
              </select>
            </div>
            <div class="field">
              <label>Level</label>
              <select name="level">
                <?php
                  $levs = ['all'=>'All','beginner'=>'beginner','intermediate'=>'intermediate','advanced'=>'advanced'];
                  foreach ($levs as $k=>$v) { $sel=$level===$k?'selected':''; echo "<option value='".h($k)."' $sel>".h($v)."</option>"; }
                ?>
              </select>
            </div>
            <div class="field">
              <label>Rows</label>
              <select name="limit">
                <?php foreach ([10,20,50,100] as $n): ?>
                  <option value="<?= $n ?>" <?= $limit===$n?'selected':'' ?>><?= $n ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <button class="btn primary" type="submit">Apply</button>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <a class="btn ghost" href="manage_courses.php">Reset</a>
            </div>
          </form>
        </section>
      </div>

      <!-- Table -->
      <section class="card" style="margin-top:16px">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:4px 0">All Courses (<?= number_format($totalRows) ?>)</h3>
          <div class="muted">Sorted by <?= h(array_search($sortCol, $sortAllow, true) ?: 'created') ?> (<?= strtolower($dir)==='asc'?'ASC':'DESC' ?>)</div>
        </div>
        <table>
          <thead>
            <?php
              function th_sort($label, $key, $currentSort, $currentDir) {
                $dir = ($currentSort === $key && strtolower($currentDir)==='asc') ? 'desc' : 'asc';
                $arrow = $currentSort === $key ? (strtolower($currentDir)==='asc' ? '↑' : '↓') : '';
                $qs = qs(['sort'=>$key,'dir'=>$dir,'page'=>1]);
                echo "<th><a href=\"?$qs\" style=\"text-decoration:none;color:inherit\">".h($label)." $arrow</a></th>";
              }
            ?>
            <tr>
              <?php th_sort('ID','id',$sort,$dir); ?>
              <th>Thumbnail</th>
              <?php th_sort('Title','title',$sort,$dir); ?>
              <th>Level</th>
              <th>Status</th>
              <th>People</th>
              <th>Pricing</th>
              <?php th_sort('Created','created',$sort,$dir); ?>
              <?php th_sort('Updated','updated',$sort,$dir); ?>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$courses): ?>
            <tr><td colspan="10" class="muted">No courses found.</td></tr>
          <?php else: ?>
            <?php foreach ($courses as $c): ?>
              <tr>
                <td><?= (int)$c['id'] ?></td>
                <td>
                  <img class="thumb" src="<?= !empty($c['thumbnail_url']) ? h($c['thumbnail_url']) : 'https://via.placeholder.com/56x40/f3f4f6/6b7280?text=No+Thumb' ?>" alt="Thumbnail">
                </td>
                <td>
                  <div style="font-weight:700"><?= h($c['title']) ?></div>
                  <div class="muted"><?= h($c['slug']) ?></div>
                </td>
                <td><span class="pill blue"><?= h($c['level']) ?></span></td>
                <td>
                  <?php
                    $cls = $c['status']==='published' ? 'green' : ($c['status']==='draft' ? 'orange' : '');
                  ?>
                  <span class="pill <?= $cls ?>"><?= h($c['status']) ?></span>
                </td>
                <td>
                  <div class="muted">Instructors: <?= (int)$c['instructor_count'] ?></div>
                  <div class="muted">Enrolled: <?= (int)$c['enrolled_count'] ?></div>
                </td>
                <td>
                  <span class="price">৳ <?= number_format(((int)$c['price_cents'])/100, 2) ?></span>
                  <?php if (!is_null($c['sale_price_cents'])): ?>
                    <span class="strike">৳ <?= number_format(((int)$c['sale_price_cents'])/100, 2) ?></span>
                  <?php endif; ?>
                  <div class="muted"><?= h($c['currency']) ?></div>
                </td>
                <td>
                  <div><?= h(date('M d, Y', strtotime((string)$c['created_at']))) ?></div>
                  <div class="muted"><?= h(date('H:i', strtotime((string)$c['created_at']))) ?></div>
                </td>
                <td>
                  <div><?= h(date('M d, Y', strtotime((string)$c['updated_at']))) ?></div>
                  <div class="muted"><?= h(date('H:i', strtotime((string)$c['updated_at']))) ?></div>
                </td>
                <td>
                  <div class="row">
                    <a class="btn" href="course_edit.php?id=<?= (int)$c['id'] ?>">Edit</a>
                    <form id="del<?= (int)$c['id'] ?>" method="post" onsubmit="return false;">
                      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
                      <input type="hidden" name="action" value="delete">
                      <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                      <button class="btn danger" onclick="confirmDel('del<?= (int)$c['id'] ?>')">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
          <?php
            $page = max(1,$page);
            if ($page > 1) {
              echo '<a href="?'.qs(['page'=>1]).'">« First</a>';
              echo '<a href="?'.qs(['page'=>$page-1]).'">‹ Prev</a>';
            } else {
              echo '<span>« First</span><span>‹ Prev</span>';
            }
            $win = 2;
            $start = max(1, $page-$win);
            $end = min($totalPages, $page+$win);
            for ($i=$start; $i<=$end; $i++) {
              if ($i === $page) echo '<span class="active">'.$i.'</span>';
              else echo '<a href="?'.qs(['page'=>$i]).'">'.$i.'</a>';
            }
            if ($page < $totalPages) {
              echo '<a href="?'.qs(['page'=>$page+1]).'">Next ›</a>';
              echo '<a href="?'.qs(['page'=>$totalPages]).'">Last »</a>';
            } else {
              echo '<span>Next ›</span><span>Last »</span>';
            }
          ?>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
