<?php
// admin/manage_teachers.php
declare(strict_types=1);

require_once '../includes/config.php'; // must define $pdo (PDO to dctiedu)

if (session_status() === PHP_SESSION_NONE) session_start();

// ---------- helpers ----------
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function qs(array $overrides = []): string {
  $q = array_merge($_GET, $overrides);
  return http_build_query(array_filter($q, fn($v) => $v !== null && $v !== '' && $v !== 'all'));
}
function random_password(int $len = 10): string {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@$!#%&?';
  $out = '';
  for ($i=0; $i<$len; $i++) $out .= $alphabet[random_int(0, strlen($alphabet)-1)];
  return $out;
}
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$flash_ok  = $_SESSION['flash_ok']  ?? null;
$flash_err = $_SESSION['flash_err'] ?? null;
unset($_SESSION['flash_ok'], $_SESSION['flash_err']);

// ---------- handle POST: create / delete ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = (string)($_POST['action'] ?? '');
  if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
    $_SESSION['flash_err'] = 'Invalid CSRF token.';
    header('Location: manage_teachers.php');
    exit;
  }

  if ($action === 'create') {
    $name   = trim((string)($_POST['name'] ?? ''));
    $email  = trim((string)($_POST['email'] ?? ''));
    $phone  = trim((string)($_POST['phone'] ?? ''));
    $status = (string)($_POST['status'] ?? 'active');
    $city   = trim((string)($_POST['city'] ?? ''));
    $country= trim((string)($_POST['country'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if ($name === '' || $email === '') {
      $_SESSION['flash_err'] = 'Name and Email are required.';
      header('Location: manage_teachers.php'); exit;
    }
    // unique email check
    $chk = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $chk->execute([$email]);
    if ((int)$chk->fetchColumn() > 0) {
      $_SESSION['flash_err'] = 'Email already exists.';
      header('Location: manage_teachers.php'); exit;
    }
    // password
    if ($password === '') $password = random_password(10);
    $hash = password_hash($password, PASSWORD_BCRYPT);

    // create user
    $ins = $pdo->prepare("
      INSERT INTO users (name, email, phone, password_hash, role, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'teacher', ?, NOW(), NOW())
    ");
    $ins->execute([$name, $email, $phone ?: null, $hash, $status]);

    $uid = (int)$pdo->lastInsertId();
    // profile (optional)
    if ($city || $country) {
      $pr = $pdo->prepare("INSERT INTO profiles (user_id, city, country, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
      $pr->execute([$uid, $city ?: null, $country ?: null]);
    }

    $_SESSION['flash_ok'] = "Teacher created. Temp password: <b>".h($password)."</b>";
    header('Location: manage_teachers.php'); exit;
  }

  if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) { $_SESSION['flash_err'] = 'Invalid teacher id.'; header('Location: manage_teachers.php'); exit; }
    // Delete (course_instructors has ON DELETE CASCADE)
    $del = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'teacher'");
    $del->execute([$id]);
    $_SESSION['flash_ok'] = "Teacher #$id deleted.";
    header('Location: manage_teachers.php'); exit;
  }
}

// ---------- filters / list ----------
$q       = trim((string)($_GET['q'] ?? ''));
$status  = (string)($_GET['status'] ?? 'all');   // all|active|disabled
$limit   = (int)($_GET['limit'] ?? 20);
$limit   = in_array($limit, [10,20,50,100], true) ? $limit : 20;
$page    = max(1, (int)($_GET['page'] ?? 1));

$sortAllow = [
  'id' => 'u.id', 'name' => 'u.name', 'email' => 'u.email', 'phone' => 'u.phone',
  'status' => 'u.status', 'created_at' => 'u.created_at', 'last_login_at' => 'u.last_login_at'
];
$sort    = (string)($_GET['sort'] ?? 'created_at');
$sortCol = $sortAllow[$sort] ?? 'u.created_at';
$dir     = strtolower((string)($_GET['dir'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';

$where = ["u.role = 'teacher'"];
$params = [];
if ($status !== 'all') { $where[] = 'u.status = ?'; $params[] = $status; }
if ($q !== '') {
  $where[] = "(u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR p.city LIKE ? OR p.country LIKE ?)";
  for ($i=0;$i<5;$i++) $params[] = '%'.$q.'%';
}
$whereSql = 'WHERE '.implode(' AND ', $where);

// count
$cnt = $pdo->prepare("SELECT COUNT(DISTINCT u.id) FROM users u LEFT JOIN profiles p ON p.user_id=u.id $whereSql");
$cnt->execute($params);
$totalRows = (int)$cnt->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $limit));
$offset = ($page - 1) * $limit;

// rows
$sql = "
  SELECT
    u.id, u.name, u.email, u.phone, u.status, u.created_at, u.last_login_at,
    p.city, p.country,
    (SELECT COUNT(*) FROM course_instructors ci WHERE ci.user_id = u.id) AS course_count
  FROM users u
  LEFT JOIN profiles p ON p.user_id = u.id
  $whereSql
  GROUP BY u.id
  ORDER BY $sortCol $dir
  LIMIT $limit OFFSET $offset
";
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  $csvSql = "
    SELECT
      u.id, u.name, u.email, u.phone, u.status, u.created_at, u.last_login_at,
      p.city, p.country
    FROM users u
    LEFT JOIN profiles p ON p.user_id = u.id
    $whereSql
    GROUP BY u.id
    ORDER BY $sortCol $dir
  ";
  $ex = $pdo->prepare($csvSql);
  $ex->execute($params);

  header('Content-Type: text/csv; charset=UTF-8');
  header('Content-Disposition: attachment; filename="teachers_'.date('Ymd_His').'.csv"');
  $out = fopen('php://output', 'w');
  fputcsv($out, ['ID','Name','Email','Phone','Status','Created At','Last Login','City','Country']);
  while ($r = $ex->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($out, [$r['id'],$r['name'],$r['email'],$r['phone'],$r['status'],$r['created_at'],$r['last_login_at'],$r['city'],$r['country']]);
  }
  fclose($out);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Teachers</title>
  <link rel="stylesheet" href="dashboard.css">
  <style>
    .toolbar{display:flex; gap:8px; flex-wrap:wrap; align-items:end; margin:16px 0}
    .toolbar .field{display:grid; gap:6px}
    .toolbar input,.toolbar select{border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; font:500 14px system-ui; background:#fff}
    .field{display:grid; gap:6px; margin-bottom:10px}
    input,select,textarea{border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; font:500 14px system-ui; background:#fff}
    .btn{display:inline-block; padding:10px 12px; border-radius:10px; border:1px solid #c7d2fe; background:#eef2ff; color:#1e3a8a; font-weight:700; text-decoration:none}
    .btn.primary{background:#2563eb; color:#fff; border-color:#2563eb}
    .btn.danger{background:#dc2626; color:#fff; border-color:#dc2626}
    .btn.ghost{background:#fff}
    .card{background:#fff; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.05); padding:16px}
    .grid-2{display:grid; grid-template-columns:1fr 2fr; gap:16px}
    @media (max-width:900px){.grid-2{grid-template-columns:1fr}}
    table{width:100%; border-collapse:collapse}
    th,td{padding:12px 14px; border-bottom:1px solid #eef2f7; text-align:left; vertical-align:top}
    th{font-size:12px; text-transform:uppercase; letter-spacing:.04em; color:#6b7280}
    .muted{color:#6b7280; font-size:12px}
    .pill{display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; background:#f3f4f6; border:1px solid #e5e7eb}
    .pill.green{background:#ecfdf5; border-color:#bbf7d0; color:#065f46}
    .pill.red{background:#fef2f2; border-color:#fecaca; color:#991b1b}
    .pagination{display:flex; gap:6px; justify-content:flex-end; margin-top:12px}
    .pagination a,.pagination span{padding:6px 10px; border-radius:8px; border:1px solid #e5e7eb; text-decoration:none; color:#111827; background:#fff}
    .pagination .active{background:#2563eb; color:#fff; border-color:#2563eb}
    .flash{margin:8px 0; padding:10px 12px; border-radius:10px; font-size:14px}
    .ok{background:#ecfeff; border:1px solid #a5f3fc; color:#155e75}
    .err{background:#fff1f2; border:1px solid #fecdd3; color:#9f1239}
    .row{display:flex; gap:10px; flex-wrap:wrap; align-items:center}
  </style>
  <script>
    function confirmDel(formId){
      if (confirm('Delete this teacher? This cannot be undone.')) {
        document.getElementById(formId).submit();
      }
    }
  </script>
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">DCti Admin</div>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_teachers.php">Manage Teachers</a></li>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="assign_teacher.php">Assign Teacher</a></li>
        <li><a href="course_edit.php">Course Edit</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="#">Settings</a></li>
      </ul>
    </aside>

    <main class="main">
      <header class="topbar">
        <h1>Manage Teachers</h1>
        <span><?= date('F d, Y') ?></span>
      </header>

      <?php if ($flash_ok):  ?><div class="flash ok"><?= $flash_ok  ?></div><?php endif; ?>
      <?php if ($flash_err): ?><div class="flash err"><?= $flash_err ?></div><?php endif; ?>

      <div class="grid-2">
        <!-- Create Teacher -->
        <section class="card">
          <h3 style="margin-top:0">Add New Teacher</h3>
          <form method="post">
            <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="create">

            <div class="field">
              <label>Name *</label>
              <input name="name" required placeholder="Tania Teacher">
            </div>
            <div class="field">
              <label>Email *</label>
              <input type="email" name="email" required placeholder="tania@example.com">
            </div>
            <div class="row">
              <div class="field" style="flex:1">
                <label>Phone</label>
                <input name="phone" placeholder="017...">
              </div>
              <div class="field" style="flex:1">
                <label>Status</label>
                <select name="status">
                  <option value="active">active</option>
                  <option value="disabled">disabled</option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="field" style="flex:1">
                <label>City (optional)</label>
                <input name="city" placeholder="Gazipur">
              </div>
              <div class="field" style="flex:1">
                <label>Country (optional)</label>
                <input name="country" placeholder="Bangladesh">
              </div>
            </div>
            <div class="field">
              <label>Password (leave blank to auto-generate)</label>
              <input name="password" type="text" placeholder="Auto if empty">
            </div>
            <div class="row">
              <button class="btn primary" type="submit">Create Teacher</button>
              <a class="btn ghost" href="manage_teachers.php">Reset</a>
            </div>
          </form>
          <p class="muted" style="margin-top:8px">Note: If password left blank, a secure temp password is generated and shown in the success message.</p>
        </section>

        <!-- Filters -->
        <section class="card">
          <h3 style="margin-top:0">Filter & Export</h3>
          <form class="toolbar" method="get">
            <div class="field" style="flex:1 1 100%">
              <label>Search (name / email / phone / city / country)</label>
              <input type="text" name="q" value="<?= h($q) ?>" placeholder="Type to search...">
            </div>
            <div class="field">
              <label>Status</label>
              <select name="status">
                <?php foreach (['all'=>'All','active'=>'active','disabled'=>'disabled'] as $k=>$v): ?>
                  <option value="<?= h($k) ?>" <?= $status===$k?'selected':'' ?>><?= h($v) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label>Rows</label>
              <select name="limit">
                <?php foreach ([10,20,50,100] as $n): ?>
                  <option value="<?= $n ?>" <?= $limit===$n?'selected':'' ?>><?= $n ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <button class="btn primary" type="submit">Apply</button>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <a class="btn ghost" href="manage_teachers.php">Reset</a>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <a class="btn" href="manage_teachers.php?<?= qs(['export'=>'csv','page'=>null]) ?>">Export CSV</a>
            </div>
          </form>
        </section>
      </div>

      <!-- Table -->
      <section class="card" style="margin-top:16px">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:4px 0">All Teachers (<?= number_format($totalRows) ?>)</h3>
          <div class="muted">Sort: <?= h($sort) ?> (<?= strtolower($dir)==='asc'?'ASC':'DESC' ?>)</div>
        </div>

        <table>
          <thead>
            <?php
              function th_sort($label, $key, $currentSort, $currentDir) {
                $dir = ($currentSort === $key && strtolower($currentDir)==='asc') ? 'desc' : 'asc';
                $arrow = $currentSort === $key ? (strtolower($currentDir)==='asc' ? '↑' : '↓') : '';
                $qs = qs(['sort'=>$key,'dir'=>$dir,'page'=>1]);
                echo "<th><a href=\"?$qs\" style=\"text-decoration:none;color:inherit\">".h($label)." $arrow</a></th>";
              }
            ?>
            <tr>
              <?php th_sort('ID','id',$sort,$dir); ?>
              <?php th_sort('Name','name',$sort,$dir); ?>
              <?php th_sort('Email','email',$sort,$dir); ?>
              <?php th_sort('Phone','phone',$sort,$dir); ?>
              <th>Location</th>
              <th>Courses</th>
              <?php th_sort('Status','status',$sort,$dir); ?>
              <?php th_sort('Created','created_at',$sort,$dir); ?>
              <?php th_sort('Last Login','last_login_at',$sort,$dir); ?>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="10" class="muted">No teachers found.</td></tr>
            <?php else: ?>
              <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= (int)$r['id'] ?></td>
                <td style="font-weight:700"><?= h($r['name']) ?></td>
                <td><?= h($r['email']) ?></td>
                <td><?= h($r['phone'] ?? '—') ?></td>
                <td class="muted"><?= h($r['city'] ?? '—') ?><?= $r['country'] ? ', '.h($r['country']) : '' ?></td>
                <td class="muted"><?= (int)$r['course_count'] ?> course(s)</td>
                <td>
                  <?php $cls = $r['status']==='active' ? 'green' : 'red'; ?>
                  <span class="pill <?= $cls ?>"><?= h($r['status']) ?></span>
                </td>
                <td>
                  <div><?= h(date('M d, Y', strtotime((string)$r['created_at']))) ?></div>
                  <div class="muted"><?= h(date('H:i', strtotime((string)$r['created_at']))) ?></div>
                </td>
                <td>
                  <?php if (!empty($r['last_login_at'])): ?>
                    <div><?= h(date('M d, Y', strtotime((string)$r['last_login_at']))) ?></div>
                    <div class="muted"><?= h(date('H:i', strtotime((string)$r['last_login_at']))) ?></div>
                  <?php else: ?>
                    <span class="muted">—</span>
                  <?php endif; ?>
                </td>
                <td>
                  <div class="row">
                    <!-- Future: link to assign courses page -->
                    <form id="del<?= (int)$r['id'] ?>" method="post" onsubmit="return false;">
                      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
                      <input type="hidden" name="action" value="delete">
                      <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                      <button class="btn danger" onclick="confirmDel('del<?= (int)$r['id'] ?>')">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
          <?php
            if ($page > 1) {
              echo '<a href="?'.qs(['page'=>1]).'">« First</a>';
              echo '<a href="?'.qs(['page'=>$page-1]).'">‹ Prev</a>';
            } else {
              echo '<span>« First</span><span>‹ Prev</span>';
            }
            $win = 2;
            $start = max(1, $page-$win);
            $end = min($totalPages, $page+$win);
            for ($i=$start; $i<=$end; $i++) {
              if ($i === $page) echo '<span class="active">'.$i.'</span>';
              else echo '<a href="?'.qs(['page'=>$i]).'">'.$i.'</a>';
            }
            if ($page < $totalPages) {
              echo '<a href="?'.qs(['page'=>$page+1]).'">Next ›</a>';
              echo '<a href="?'.qs(['page'=>$totalPages]).'">Last »</a>';
            } else {
              echo '<span>Next ›</span><span>Last »</span>';
            }
          ?>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
