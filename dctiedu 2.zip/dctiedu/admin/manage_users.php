<?php
// admin/manage_users.php
declare(strict_types=1);

require_once '../includes/config.php';   // must define $pdo (PDO connected to dctiedu)

// If you later want to protect this page, uncomment the next two lines:
// require_once '../includes/auth.php';
// requireAdmin();

// ------------------------------ helpers ------------------------------
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function qs(array $overrides = []): string {
  $q = array_merge($_GET, $overrides);
  return http_build_query(array_filter($q, fn($v) => $v !== null && $v !== '' && $v !== 'all'));
}

// Inputs
$q       = trim((string)($_GET['q'] ?? ''));
$role    = (string)($_GET['role'] ?? 'all');     // all | admin | teacher | staff | student
$status  = (string)($_GET['status'] ?? 'all');   // all | active | disabled
$limit   = (int)($_GET['limit'] ?? 20);
$limit   = in_array($limit, [10,20,50,100], true) ? $limit : 20;
$page    = max(1, (int)($_GET['page'] ?? 1));

$sortAllow = [
  'id' => 'u.id', 'name' => 'u.name', 'email' => 'u.email', 'phone' => 'u.phone',
  'role' => 'u.role', 'status' => 'u.status', 'created_at' => 'u.created_at', 'last_login_at' => 'u.last_login_at'
];
$sort    = (string)($_GET['sort'] ?? 'created_at');
$sortCol = $sortAllow[$sort] ?? 'u.created_at';
$dir     = strtolower((string)($_GET['dir'] ?? 'desc'));
$dir     = $dir === 'asc' ? 'ASC' : 'DESC';

$offset = ($page - 1) * $limit;

// Build WHERE
$where = [];
$params = [];

if ($role !== 'all') { $where[] = 'u.role = ?'; $params[] = $role; }
if ($status !== 'all') { $where[] = 'u.status = ?'; $params[] = $status; }
if ($q !== '') {
  $where[] = "(u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR sa.students_english_name LIKE ? OR sa.students_bangla_name LIKE ? OR sa.id_number LIKE ?)";
  for ($i=0;$i<6;$i++) $params[] = '%'.$q.'%';
}
$whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

// Count
$countSql = "
  SELECT COUNT(DISTINCT u.id)
  FROM users u
  LEFT JOIN profiles p ON p.user_id = u.id
  LEFT JOIN students_admission sa ON sa.user_id = u.id
  $whereSql
";
$st = $pdo->prepare($countSql);
$st->execute($params);
$totalRows = (int)$st->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $limit));

// Fetch rows
$listSql = "
  SELECT
    u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at, u.last_login_at,
    p.city, p.country, p.address, p.avatar_url,
    sa.students_english_name, sa.students_bangla_name, sa.session as admission_session,
    sa.id_number as admission_id, sa.admission_date
  FROM users u
  LEFT JOIN profiles p ON p.user_id = u.id
  LEFT JOIN students_admission sa ON sa.user_id = u.id
  $whereSql
  GROUP BY u.id
  ORDER BY $sortCol $dir
  LIMIT $limit OFFSET $offset
";
$st = $pdo->prepare($listSql);
$st->execute($params);
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

// CSV export (same filters, but no limit)
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  $csvSql = "
    SELECT
      u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at, u.last_login_at,
      p.city, p.country, p.address,
      sa.students_english_name, sa.students_bangla_name, sa.session as admission_session,
      sa.id_number as admission_id, sa.admission_date
    FROM users u
    LEFT JOIN profiles p ON p.user_id = u.id
    LEFT JOIN students_admission sa ON sa.user_id = u.id
    $whereSql
    GROUP BY u.id
    ORDER BY $sortCol $dir
  ";
  $ex = $pdo->prepare($csvSql);
  $ex->execute($params);

  header('Content-Type: text/csv; charset=UTF-8');
  header('Content-Disposition: attachment; filename="users_'.date('Ymd_His').'.csv"');
  $out = fopen('php://output', 'w');
  fputcsv($out, [
    'ID','Name','Email','Phone','Role','Status','Created At','Last Login',
    'City','Country','Address','Student English Name','Student Bangla Name','Admission Session','Admission ID','Admission Date'
  ]);
  while ($r = $ex->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($out, [
      $r['id'], $r['name'], $r['email'], $r['phone'], $r['role'], $r['status'],
      $r['created_at'], $r['last_login_at'], $r['city'], $r['country'], $r['address'],
      $r['students_english_name'], $r['students_bangla_name'], $r['admission_session'],
      $r['admission_id'], $r['admission_date']
    ]);
  }
  fclose($out);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users</title>
  <link rel="stylesheet" href="dashboard.css">
  <style>
    .toolbar{display:flex; gap:8px; flex-wrap:wrap; align-items:end; margin:16px 0}
    .toolbar .field{display:grid; gap:6px}
    .toolbar input, .toolbar select{
      border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; font:500 14px system-ui; background:#fff;
    }
    .btn{display:inline-block; padding:10px 12px; border-radius:10px; border:1px solid #c7d2fe; background:#eef2ff; color:#1e3a8a; font-weight:700; text-decoration:none}
    .btn.primary{background:#2563eb; color:#fff; border-color:#2563eb}
    .btn.ghost{background:#fff}
    .table-card{background:#fff; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.05)}
    table{width:100%; border-collapse:collapse}
    th,td{padding:12px 14px; border-bottom:1px solid #eef2f7; text-align:left; vertical-align:top}
    th{font-size:12px; text-transform:uppercase; letter-spacing:.04em; color:#6b7280}
    .pill{display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; background:#f3f4f6; border:1px solid #e5e7eb}
    .pill.green{background:#ecfdf5; border-color:#bbf7d0; color:#065f46}
    .pill.gray{background:#f3f4f6; color:#374151}
    .pill.red{background:#fef2f2; border-color:#fecaca; color:#991b1b}
    .muted{color:#6b7280; font-size:12px}
    details summary{cursor:pointer; font-weight:700}
    .pagination{display:flex; gap:6px; justify-content:flex-end; margin-top:12px}
    .pagination a, .pagination span{padding:6px 10px; border-radius:8px; border:1px solid #e5e7eb; text-decoration:none; color:#111827; background:#fff}
    .pagination .active{background:#2563eb; color:#fff; border-color:#2563eb}
    .search-grow{flex:1; min-width:220px}
    .w100{width:100%}
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="brand">DCti Admin</div>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_teachers.php">Manage Teachers</a></li>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="assign_teacher.php">Assign Teacher</a></li>
        <li><a href="course_edit.php">Course Edit</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="#">Settings</a></li>
      </ul>
    </aside>

    <!-- Main -->
    <main class="main">
      <header class="topbar">
        <h1>Manage Users</h1>
        <span><?= date('F d, Y') ?></span>
      </header>

      <!-- Filters / toolbar -->
      <form class="toolbar" method="get">
        <div class="field search-grow">
          <label>Search (name / email / phone / admission)</label>
          <input type="text" name="q" value="<?= h($q) ?>" placeholder="Type to search...">
        </div>
        <div class="field">
          <label>Role</label>
          <select name="role">
            <?php
              $roles = ['all'=>'All roles','student'=>'student','teacher'=>'teacher','staff'=>'staff','admin'=>'admin'];
              foreach ($roles as $k=>$label) {
                $sel = $role===$k ? 'selected' : '';
                echo "<option value='".h($k)."' $sel>".h($label)."</option>";
              }
            ?>
          </select>
        </div>
        <div class="field">
          <label>Status</label>
          <select name="status">
            <?php
              $stts = ['all'=>'All statuses','active'=>'active','disabled'=>'disabled'];
              foreach ($stts as $k=>$label) {
                $sel = $status===$k ? 'selected' : '';
                echo "<option value='".h($k)."' $sel>".h($label)."</option>";
              }
            ?>
          </select>
        </div>
        <div class="field">
          <label>Rows</label>
          <select name="limit">
            <?php foreach ([10,20,50,100] as $n): ?>
              <option value="<?= $n ?>" <?= $limit===$n?'selected':'' ?>><?= $n ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label>&nbsp;</label>
          <button class="btn primary" type="submit">Apply</button>
        </div>
        <div class="field">
          <label>&nbsp;</label>
          <a class="btn ghost" href="manage_users.php">Reset</a>
        </div>
        <div class="field">
          <label>&nbsp;</label>
          <a class="btn" href="manage_users.php?<?= qs(['export'=>'csv','page'=>null]) ?>">Export CSV</a>
        </div>
      </form>

      <section class="table-card">
        <table>
          <thead>
            <?php
              // Helper to build sortable header links
              function th_sort($label, $key, $currentSort, $currentDir) {
                $dir = ($currentSort === $key && $currentDir === 'ASC') ? 'desc' : 'asc';
                $arrow = $currentSort === $key ? ($currentDir === 'ASC' ? '↑' : '↓') : '';
                $qs = qs(['sort'=>$key,'dir'=>$dir,'page'=>1]);
                echo "<th><a href=\"?$qs\" style=\"text-decoration:none; color:inherit\">".h($label)." $arrow</a></th>";
              }
            ?>
            <tr>
              <?php th_sort('ID','id',$sort,strtoupper($dir)); ?>
              <?php th_sort('Name','name',$sort,strtoupper($dir)); ?>
              <?php th_sort('Email','email',$sort,strtoupper($dir)); ?>
              <?php th_sort('Phone','phone',$sort,strtoupper($dir)); ?>
              <?php th_sort('Role','role',$sort,strtoupper($dir)); ?>
              <?php th_sort('Status','status',$sort,strtoupper($dir)); ?>
              <?php th_sort('Created','created_at',$sort,strtoupper($dir)); ?>
              <?php th_sort('Last Login','last_login_at',$sort,strtoupper($dir)); ?>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="9" class="muted">No users found.</td></tr>
            <?php else: ?>
              <?php foreach ($rows as $r): ?>
                <tr>
                  <td><?= (int)$r['id'] ?></td>
                  <td>
                    <div style="font-weight:700"><?= h($r['name']) ?></div>
                    <?php if (!empty($r['students_english_name']) || !empty($r['students_bangla_name'])): ?>
                      <div class="muted">
                        <?= h($r['students_english_name'] ?? '') ?>
                        <?= !empty($r['students_bangla_name']) ? ' / '.h($r['students_bangla_name']) : '' ?>
                      </div>
                    <?php endif; ?>
                  </td>
                  <td><?= h($r['email']) ?></td>
                  <td><?= h($r['phone'] ?? '—') ?></td>
                  <td>
                    <?php
                      $roleCls = match ($r['role']) {
                        'admin' => 'red',
                        'teacher' => 'green',
                        'staff' => 'gray',
                        default => 'gray'
                      };
                    ?>
                    <span class="pill <?= $roleCls ?>"><?= h($r['role']) ?></span>
                  </td>
                  <td>
                    <?php $scls = $r['status']==='active' ? 'green' : 'red'; ?>
                    <span class="pill <?= $scls ?>"><?= h($r['status']) ?></span>
                  </td>
                  <td>
                    <div><?= h(date('M d, Y', strtotime((string)$r['created_at']))) ?></div>
                    <div class="muted"><?= h(date('H:i', strtotime((string)$r['created_at']))) ?></div>
                  </td>
                  <td>
                    <?php if (!empty($r['last_login_at'])): ?>
                      <div><?= h(date('M d, Y', strtotime((string)$r['last_login_at']))) ?></div>
                      <div class="muted"><?= h(date('H:i', strtotime((string)$r['last_login_at']))) ?></div>
                    <?php else: ?>
                      <span class="muted">—</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <details>
                      <summary>View</summary>
                      <div class="muted" style="margin-top:8px">
                        <div><b>City:</b> <?= h($r['city'] ?? '—') ?> &nbsp; <b>Country:</b> <?= h($r['country'] ?? '—') ?></div>
                        <div><b>Address:</b> <?= h($r['address'] ?? '—') ?></div>
                        <div><b>Admission:</b>
                          <?= h($r['admission_session'] ?? '—') ?>,
                          ID: <?= h($r['admission_id'] ?? '—') ?>,
                          Date: <?= !empty($r['admission_date']) ? h(date('M d, Y', strtotime((string)$r['admission_date']))) : '—' ?>
                        </div>
                      </div>
                    </details>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
          <?php
            if ($page > 1) {
              echo '<a href="?'.qs(['page'=>1]).'">« First</a>';
              echo '<a href="?'.qs(['page'=>$page-1]).'">‹ Prev</a>';
            } else {
              echo '<span>« First</span><span>‹ Prev</span>';
            }
            // windowed page numbers
            $win = 2;
            $start = max(1, $page-$win);
            $end = min($totalPages, $page+$win);
            for ($i=$start; $i<=$end; $i++) {
              if ($i === $page) echo '<span class="active">'.$i.'</span>';
              else echo '<a href="?'.qs(['page'=>$i]).'">'.$i.'</a>';
            }
            if ($page < $totalPages) {
              echo '<a href="?'.qs(['page'=>$page+1]).'">Next ›</a>';
              echo '<a href="?'.qs(['page'=>$totalPages]).'">Last »</a>';
            } else {
              echo '<span>Next ›</span><span>Last »</span>';
            }
          ?>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
