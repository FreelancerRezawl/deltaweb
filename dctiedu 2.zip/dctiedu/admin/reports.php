<?php
// admin/reports.php
declare(strict_types=1);

require_once '../includes/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// ---------- helpers ----------
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money_bdt(float $v): string { return '৳ '.number_format($v, 2); }

// ---------- Date helpers: build last 12 months buckets ----------
$months = []; // ['2024-10' => 'Oct 2024', ..., '2025-09' => 'Sep 2025']
$labels = [];
$keys   = [];
$now = new DateTime('first day of this month');
for ($i = 11; $i >= 0; $i--) {
  $d = (clone $now)->modify("-$i months");
  $key = $d->format('Y-m'); // e.g., 2025-09
  $label = $d->format('M Y');
  $months[$key] = $label;
  $labels[] = $label;
  $keys[] = $key;
}
$startDate = array_key_first($months) . '-01';
$endDate   = (new DateTime('first day of next month'))->format('Y-m-d'); // exclusive

// ---------- Revenue & Orders (last 12 months) ----------
$rev = array_fill_keys($keys, 0.0);
$ord = array_fill_keys($keys, 0);

$stm = $pdo->prepare("
  SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym,
         SUM(CASE WHEN status='success' THEN amount_cents ELSE 0 END)/100 AS revenue_bdt,
         COUNT(*) AS orders
  FROM payments
  WHERE created_at >= ? AND created_at < ?
  GROUP BY ym
");
$stm->execute([$startDate, $endDate]);
foreach ($stm->fetchAll(PDO::FETCH_ASSOC) as $r) {
  $k = $r['ym'];
  if (isset($rev[$k])) $rev[$k] = (float)$r['revenue_bdt'];
  if (isset($ord[$k])) $ord[$k] = (int)$r['orders'];
}

// ---------- Payment method breakdown (all-time & last 12 months) ----------
$methods = ['sslcommerz','bkash','nagad','stripe','manual'];
$methodCount = array_fill_keys($methods, 0);
$methodSum   = array_fill_keys($methods, 0.0);

$stm = $pdo->query("
  SELECT method,
         COUNT(*) AS cnt,
         SUM(CASE WHEN status='success' THEN amount_cents ELSE 0 END)/100 AS amt
  FROM payments
  GROUP BY method
");
foreach ($stm->fetchAll(PDO::FETCH_ASSOC) as $r) {
  $m = $r['method'];
  if (!isset($methodCount[$m])) { $methodCount[$m]=0; $methodSum[$m]=0.0; }
  $methodCount[$m] = (int)$r['cnt'];
  $methodSum[$m]   = (float)$r['amt'];
}

// ---------- Payment status breakdown (last 12 months) ----------
$statuses = ['pending','success','failed','refunded'];
$statusCount = array_fill_keys($statuses, 0);
$stm = $pdo->prepare("
  SELECT status, COUNT(*) AS cnt
  FROM payments
  WHERE created_at >= ? AND created_at < ?
  GROUP BY status
");
$stm->execute([$startDate, $endDate]);
foreach ($stm->fetchAll(PDO::FETCH_ASSOC) as $r) {
  $s = $r['status'];
  if (isset($statusCount[$s])) $statusCount[$s] = (int)$r['cnt'];
}

// ---------- Top Courses by revenue (last 12 months) ----------
$topRev = $pdo->prepare("
  SELECT c.id, c.title,
         SUM(CASE WHEN p.status='success' THEN p.amount_cents ELSE 0 END)/100 AS revenue_bdt,
         COUNT(p.id) AS orders
  FROM payments p
  JOIN courses c ON c.id = p.course_id
  WHERE p.created_at >= ? AND p.created_at < ?
  GROUP BY c.id, c.title
  ORDER BY revenue_bdt DESC
  LIMIT 10
");
$topRev->execute([$startDate, $endDate]);
$topCoursesRevenue = $topRev->fetchAll(PDO::FETCH_ASSOC);

// ---------- Top Courses by enrollments (last 12 months) ----------
$topEnr = $pdo->prepare("
  SELECT c.id, c.title, COUNT(e.id) AS enrollments
  FROM enrollments e
  JOIN courses c ON c.id = e.course_id
  WHERE e.created_at >= ? AND e.created_at < ?
  GROUP BY c.id, c.title
  ORDER BY enrollments DESC
  LIMIT 10
");
$topEnr->execute([$startDate, $endDate]);
$topCoursesEnroll = $topEnr->fetchAll(PDO::FETCH_ASSOC);

// ---------- KPIs ----------
$totalRevenue = array_sum($rev);
$totalOrders  = array_sum($ord);
$avgOrder     = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0.0;
$successOrders= $statusCount['success'] ?? 0;
$successRate  = $totalOrders > 0 ? ($successOrders / $totalOrders) * 100 : 0.0;

// ---------- CSV exports ----------
if (isset($_GET['export'])) {
  $what = (string)$_GET['export'];
  if ($what === 'monthly_revenue') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="monthly_revenue_'.date('Ymd_His').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Month','Revenue (BDT)','Orders']);
    foreach ($keys as $k) {
      fputcsv($out, [$months[$k], $rev[$k], $ord[$k]]);
    }
    fclose($out); exit;
  }
  if ($what === 'monthly_enrollments') {
    // Build enrollments per month quickly
    $enr = array_fill_keys($keys, 0);
    $stmE = $pdo->prepare("
      SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, COUNT(*) AS cnt
      FROM enrollments
      WHERE created_at >= ? AND created_at < ?
      GROUP BY ym
    ");
    $stmE->execute([$startDate, $endDate]);
    foreach ($stmE->fetchAll(PDO::FETCH_ASSOC) as $r) {
      $k = $r['ym']; if (isset($enr[$k])) $enr[$k] = (int)$r['cnt'];
    }

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="monthly_enrollments_'.date('Ymd_His').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Month','Enrollments']);
    foreach ($keys as $k) {
      fputcsv($out, [$months[$k], $enr[$k]]);
    }
    fclose($out); exit;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reports & Analytics</title>
  <link rel="stylesheet" href="dashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    .kpis {display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:16px; margin-bottom:16px}
    .card {background:#fff; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.05); padding:16px}
    .kpi h4{margin:0; color:#6b7280; font-size:13px}
    .kpi .v{margin-top:6px; font-size:24px; font-weight:800}
    .muted{color:#6b7280; font-size:12px}
    .grid-2{display:grid; grid-template-columns:1.5fr 1fr; gap:16px}
    @media (max-width:1000px){.grid-2{grid-template-columns:1fr}}
    .grid-3{display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px}
    @media (max-width:1200px){.grid-3{grid-template-columns:1fr}}
    table{width:100%; border-collapse:collapse; font-size:14px}
    th,td{padding:10px 12px; border-bottom:1px solid #eef2f7; text-align:left}
    th{font-size:12px; text-transform:uppercase; letter-spacing:.05em; color:#6b7280; background:#f9fafb}
    .btn{display:inline-block; padding:8px 12px; border-radius:8px; border:1px solid #c7d2fe; background:#eef2ff; color:#1e3a8a; font-weight:700; font-size:13px; text-decoration:none}
    .btn.ghost{background:#fff}
  </style>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="brand">DCti Admin</div>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_teachers.php">Manage Teachers</a></li>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="assign_teacher.php">Assign Teacher</a></li>
        <li><a href="course_edit.php">Course Edit</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="#">Settings</a></li>
      </ul>
    </aside>

    <!-- Main -->
    <main class="main">
      <header class="topbar">
        <h1>Reports & Analytics</h1>
        <span><?= date('F d, Y') ?></span>
      </header>

      <!-- KPIs -->
      <section class="kpis">
        <div class="card kpi">
          <h4>Total Revenue (12 mo)</h4>
          <div class="v"><?= money_bdt($totalRevenue) ?></div>
          <div class="muted">From successful payments</div>
        </div>
        <div class="card kpi">
          <h4>Total Orders (12 mo)</h4>
          <div class="v"><?= number_format($totalOrders) ?></div>
          <div class="muted">All payment intents</div>
        </div>
        <div class="card kpi">
          <h4>Avg Order Value</h4>
          <div class="v"><?= money_bdt($avgOrder) ?></div>
          <div class="muted"><?= $totalOrders>0?number_format($totalOrders):'0' ?> orders</div>
        </div>
        <div class="card kpi">
          <h4>Success Rate</h4>
          <div class="v"><?= number_format($successRate,1) ?>%</div>
          <div class="muted"><?= number_format($successOrders) ?> successful</div>
        </div>
      </section>

      <!-- Charts row -->
      <section class="grid-2">
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <h3 style="margin:0">Revenue (Last 12 Months)</h3>
            <a class="btn" href="?export=monthly_revenue">Export CSV</a>
          </div>
          <canvas id="revChart" height="120"></canvas>
        </div>
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <h3 style="margin:0">Orders (Last 12 Months)</h3>
            <a class="btn ghost" href="?export=monthly_enrollments">Export Enrollments CSV</a>
          </div>
          <canvas id="ordChart" height="120"></canvas>
        </div>
      </section>

      <!-- Breakdown row -->
      <section class="grid-3" style="margin-top:16px">
        <div class="card">
          <h3 style="margin-top:0">Payment Methods (All-time)</h3>
          <canvas id="methodChart" height="180"></canvas>
          <div class="muted" style="margin-top:6px">
            <?= implode(' • ', array_map(fn($m)=> h($m).': '.number_format($methodCount[$m] ?? 0).' orders ('.money_bdt($methodSum[$m] ?? 0).')', $methods)) ?>
          </div>
        </div>
        <div class="card">
          <h3 style="margin-top:0">Payment Status (12 mo)</h3>
          <canvas id="statusChart" height="180"></canvas>
          <div class="muted" style="margin-top:6px">
            <?php foreach ($statuses as $s): ?>
              <?= h($s) ?>: <?= number_format($statusCount[$s] ?? 0) ?> &nbsp;
            <?php endforeach; ?>
          </div>
        </div>
        <div class="card">
          <h3 style="margin-top:0">Quick Actions</h3>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn" href="manage_courses.php">Manage Courses</a>
            <a class="btn" href="manage_users.php">Manage Users</a>
            <a class="btn" href="manage_teachers.php">Manage Teachers</a>
          </div>
          <p class="muted" style="margin-top:8px">Use quick actions to drill into data from this report.</p>
        </div>
      </section>

      <!-- Top courses -->
      <section class="grid-2" style="margin-top:16px">
        <div class="card">
          <h3 style="margin-top:0">Top Courses by Revenue (12 mo)</h3>
          <table>
            <thead>
              <tr><th>#</th><th>Course</th><th>Orders</th><th>Revenue</th></tr>
            </thead>
            <tbody>
              <?php if (!$topCoursesRevenue): ?>
                <tr><td colspan="4" class="muted">No data.</td></tr>
              <?php else: $i=1; foreach ($topCoursesRevenue as $row): ?>
                <tr>
                  <td><?= $i++ ?></td>
                  <td><?= h($row['title']) ?></td>
                  <td><?= number_format((int)$row['orders']) ?></td>
                  <td><?= money_bdt((float)$row['revenue_bdt']) ?></td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>

        <div class="card">
          <h3 style="margin-top:0">Top Courses by Enrollments (12 mo)</h3>
          <table>
            <thead>
              <tr><th>#</th><th>Course</th><th>Enrollments</th></tr>
            </thead>
            <tbody>
              <?php if (!$topCoursesEnroll): ?>
                <tr><td colspan="3" class="muted">No data.</td></tr>
              <?php else: $i=1; foreach ($topCoursesEnroll as $row): ?>
                <tr>
                  <td><?= $i++ ?></td>
                  <td><?= h($row['title']) ?></td>
                  <td><?= number_format((int)$row['enrollments']) ?></td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>

<script>
const labels = <?= json_encode(array_values($months)) ?>;
const revenue = <?= json_encode(array_values($rev), JSON_NUMERIC_CHECK) ?>;
const orders  = <?= json_encode(array_values($ord), JSON_NUMERIC_CHECK) ?>;

new Chart(document.getElementById('revChart'), {
  type: 'line',
  data: {
    labels,
    datasets: [{
      label: 'Revenue (BDT)',
      data: revenue,
      borderColor: '#2563eb',
      backgroundColor: 'rgba(37,99,235,.15)',
      fill: true,
      tension: .3,
      pointRadius: 3
    }]
  },
  options: {responsive:true, maintainAspectRatio:false}
});

new Chart(document.getElementById('ordChart'), {
  type: 'bar',
  data: {
    labels,
    datasets: [{
      label: 'Orders',
      data: orders,
      backgroundColor: '#16a34a'
    }]
  },
  options: {responsive:true, maintainAspectRatio:false}
});

const methodLabels = <?= json_encode($methods) ?>;
const methodCounts = <?= json_encode(array_values($methodCount), JSON_NUMERIC_CHECK) ?>;
new Chart(document.getElementById('methodChart'), {
  type: 'doughnut',
  data: {
    labels: methodLabels,
    datasets: [{ data: methodCounts, backgroundColor: ['#2563eb','#f59e0b','#10b981','#ef4444','#8b5cf6'] }]
  }
});

const statusLabels = <?= json_encode($statuses) ?>;
const statusCounts = <?= json_encode(array_values($statusCount), JSON_NUMERIC_CHECK) ?>;
new Chart(document.getElementById('statusChart'), {
  type: 'doughnut',
  data: {
    labels: statusLabels,
    datasets: [{ data: statusCounts, backgroundColor: ['#f59e0b','#10b981','#ef4444','#6b7280'] }]
  }
});
</script>
</body>
</html>
