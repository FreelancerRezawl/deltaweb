<?php
// FILE: /var/www/html/delta/delta_a.php
// Student Admission Form — uses db.php and matches table dctiedu.students_admission

declare(strict_types=1);

ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/upload_errors.log');
ini_set('display_errors', '1');

require __DIR__ . '/db.php';   // DB connection
@include 'menu.php';           // optional

function assemble_date($y, $m, $d) {
    $y = intval($y); $m = intval($m); $d = intval($d);
    if ($y && $m && $d && checkdate($m, $d, $y)) {
        return sprintf("%04d-%02d-%02d", $y, $m, $d);
    }
    return null;
}
function h($v) { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }

$success_msg = "";
$error_msg   = "";
$upload_file = null;

if (isset($_POST["submit"])) {
    $conn = db();

    // Dates (hidden fields from JS; fallback to dropdowns)
    $dob   = $_POST['Date_of_Birth']  ?? '';
    $adate = $_POST['Admission_Date'] ?? '';
    if (!$dob)   { $dob   = assemble_date($_POST['dob_year'] ?? '', $_POST['dob_month'] ?? '', $_POST['dob_day'] ?? ''); }
    if (!$adate) { $adate = assemble_date($_POST['ad_year'] ?? '', $_POST['ad_month'] ?? '', $_POST['ad_day'] ?? ''); }

    // Validate DOB
    $today = date('Y-m-d');
    if (!$dob || $dob < '1910-01-01' || $dob > $today) {
        $error_msg = "Please select a valid Date of Birth (1910 to today).";
    }

    // Validate Admission Date
    if (!$error_msg) {
        $max_ad = date('Y-m-d', strtotime('+30 days'));
        if (!$adate || $adate < '1910-01-01' || $adate > $max_ad) {
            $error_msg = "Please select a valid Admission Date (up to 30 days in future).";
        }
    }

    // Ensure uploads dir
    $upload_dir = dirname(__DIR__) . "/uploads/";
    if (!$error_msg && !is_dir($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            $error_msg = "Failed to create uploads directory. Check permissions.";
        }
    }

    // Photo upload (optional)
    if (!$error_msg && isset($_FILES["Student_Photo"]) && $_FILES["Student_Photo"]["error"] === UPLOAD_ERR_OK) {
        $allowed_exts  = ['jpg','jpeg','png','gif','webp'];
        $allowed_mimes = ['image/jpeg','image/png','image/gif','image/webp'];
        $max_bytes     = 2 * 1024 * 1024;

        $orig = $_FILES["Student_Photo"]["name"];
        $tmp  = $_FILES["Student_Photo"]["tmp_name"];
        $size = $_FILES["Student_Photo"]["size"];

        if ($size > $max_bytes) {
            $error_msg = "Photo must be ≤ 2MB. Your file is " . round($size/1048576, 2) . "MB.";
        } else {
            $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed_exts, true)) {
                $error_msg = "Only JPG, PNG, GIF, WEBP images are allowed.";
            } else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if (!$finfo) {
                    $error_msg = "Fileinfo extension not available.";
                } else {
                    $mime = finfo_file($finfo, $tmp);
                    finfo_close($finfo);
                    if (!in_array($mime, $allowed_mimes, true)) {
                        $error_msg = "Invalid image type detected: " . $mime;
                    } else {
                        $safeBase = preg_replace('/[^A-Za-z0-9_\-]/', '_', pathinfo($orig, PATHINFO_FILENAME));
                        $newName  = $safeBase . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
                        $target   = $upload_dir . $newName;
                        if (move_uploaded_file($tmp, $target)) {
                            $upload_file = "uploads/" . $newName;
                        } else {
                            $error_msg = "Server failed to save file. Check folder permissions.";
                            error_log("Failed to move: $target");
                        }
                    }
                }
            }
        }
    } else {
        if (isset($_FILES["Student_Photo"]) && $_FILES["Student_Photo"]["error"] !== UPLOAD_ERR_NO_FILE && $_FILES["Student_Photo"]["error"] !== UPLOAD_ERR_OK) {
            $errs = [
                UPLOAD_ERR_INI_SIZE   => 'File too large (php.ini).',
                UPLOAD_ERR_FORM_SIZE  => 'File too large (form limit).',
                UPLOAD_ERR_PARTIAL    => 'Partial upload.',
                UPLOAD_ERR_NO_TMP_DIR => 'No temp directory.',
                UPLOAD_ERR_CANT_WRITE => 'Cannot write to disk.',
                UPLOAD_ERR_EXTENSION  => 'Upload stopped by extension.'
            ];
            $error_msg = "Upload error: " . ($errs[$_FILES["Student_Photo"]["error"]] ?? "Unknown error");
        }
        if (!isset($_FILES["Student_Photo"]) || $_FILES["Student_Photo"]["error"] === UPLOAD_ERR_NO_FILE) {
            $upload_file = null;
        }
    }

    // Govt ID (accept either packed hidden or type+number)
    $gov_id_type    = trim($_POST['gov_id_type']   ?? '');
    $gov_id_number  = trim($_POST['gov_id_number'] ?? '');  // requires name attr
    $combined_id    = trim($_POST['National_ID_Number'] ?? ''); // JS-packed fallback

    if ($combined_id === '') {
        if ($gov_id_type && $gov_id_number) {
            $prefix      = ($gov_id_type === 'BIRTH') ? 'BIRTH' : 'NID';
            $combined_id = $prefix . ': ' . $gov_id_number;
        } elseif (($gov_id_type && !$gov_id_number) || ($gov_id_number && !$gov_id_type)) {
            $error_msg = "Please select ID type and enter the ID number.";
        } else {
            $combined_id = null; // optional field
        }
    }

    // Insert
    if (!$error_msg) {
        $sql = "INSERT INTO students_admission (
            admission_name, cours_duration, id_number, session,
            students_bangla_name, students_english_name,
            fathers_bangla_name, fathers_english_name,
            mothers_bangla_name, mothers_english_name,
            mailing_address, permanent_address,
            religion, gender, date_of_birth, blood_group,
            nationality, national_id_number, phone_number,
            email_address, student_photo, admission_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            $conn = db();
            $stmt = $conn->prepare($sql);

            $nationality_fixed = 'Bangladeshi';
            $admission_name = $_POST['Admission_Name'] ?? '';
            $cours_duration = $_POST['Cours_Duration'] ?? '';
            $id_number      = $_POST['ID_Number'] ?? '';
            $session        = $_POST['Session'] ?? ''; // from preset dropdown

            $students_bangla_name  = $_POST['Students_Bangla_Name'] ?? '';
            $students_english_name = $_POST['Students_English_Name'] ?? '';
            $fathers_bangla_name   = $_POST['Fathers_Bangla_name'] ?? '';
            $fathers_english_name  = $_POST['Fathers_English_name'] ?? '';
            $mothers_bangla_name   = $_POST['Mothers_Bangla_name'] ?? '';
            $mothers_english_name  = $_POST['Mothers_English_name'] ?? '';
            $mailing_address       = $_POST['Mailing_Address'] ?? '';
            $permanent_address     = $_POST['Permanent_Address'] ?? '';
            $religion              = $_POST['Religion'] ?? '';
            $gender                = $_POST['Gender'] ?? '';
            $blood_group           = $_POST['Blood_Group'] ?? '';
            $national_id_number    = $combined_id; // may be NULL
            $phone_number          = $_POST['Phone_Number'] ?? '';
            $email_address         = $_POST['Email_Address'] ?? '';

            $params = [
                $admission_name,
                $cours_duration,
                $id_number,
                $session,
                $students_bangla_name,
                $students_english_name,
                $fathers_bangla_name,
                $fathers_english_name,
                $mothers_bangla_name,
                $mothers_english_name,
                $mailing_address,
                $permanent_address,
                $religion,
                $gender,
                $dob,
                $blood_group,
                $nationality_fixed,
                $national_id_number,
                $phone_number,
                $email_address,
                $upload_file,
                $adate
            ];

            $stmt->execute($params);
            $success_msg = "ভর্তি আবেদন সফলভাবে জমা হয়েছে! / Admission submitted successfully.";
            $_POST = []; // Clear form
        } catch (PDOException $e) {
            $error_code = $e->getCode();
            $error_info = $e->errorInfo();
            if ($error_code == 23000 && strpos($error_info[2], 'uniq_id_number') !== false) {
                $error_msg = "This ID Number is already registered. Please use a different one.";
            } else {
                $error_msg = "Database error: " . h($e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Student Admission — Delta Computer Training Institute</title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Bengali:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    :root{
      --bg:#0b1020; --bg-2:#0b122a; --ink:#eef3ff; --muted:#aab4d6;
      --border:rgba(255,255,255,.10); --brand:#7c8cff; --accent:#72e6b4;
      --shadow: 0 18px 50px rgba(2,8,23,.45); --ring: 0 0 0 3px rgba(124,140,255,.25);
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0; font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Bengali", Arial, sans-serif;
      color:var(--ink); background: linear-gradient(120deg, var(--bg), var(--bg-2)); background-attachment: fixed;
    }
    .wrap{max-width:1100px; margin:34px auto 60px; padding:0 18px; position:relative}
    .backdrop{position:absolute; inset:-80px -20px -80px -20px; z-index:-1;
      background: radial-gradient(1200px 600px at 10% -20%, rgba(124,140,255,.25), transparent 60%),
                  radial-gradient(1200px 600px at 90% 120%, rgba(114,230,180,.15), transparent 60%);
      filter: blur(12px);
    }
    .hero{
      background: linear-gradient(135deg, rgba(124,140,255,.20), rgba(0,0,0,.2));
      border:1px solid var(--border); border-radius:28px; padding:28px; box-shadow: var(--shadow);
      display:grid; grid-template-columns: 96px 1fr auto; gap:18px; align-items:center;
    }
    .hero .logo{display:flex; align-items:center; justify-content:center; width:96px; height:96px; border-radius:24px;
      background:rgba(255,255,255,.04); border:1px solid var(--border);}
    .hero .logo img{max-height:64px; width:auto; filter: drop-shadow(0 6px 10px rgba(0,0,0,.35));}
    .hero .title h1{margin:0; font-weight:800; letter-spacing:.2px}
    .hero .title .sub{margin:3px 0 0; color:var(--muted)}
    .hero .badge{justify-self:end; align-self:start; background:rgba(114,230,180,.18); color:#dff9ef;
      border:1px solid rgba(114,230,180,.45); padding:8px 14px; border-radius:999px; font-weight:700; font-size:13px;}
    .notice{margin:16px 0 0; padding:12px 14px; border-radius:14px; font-weight:600; text-align:center; border:1px solid var(--border);}
    .notice.ok{ background:rgba(25,211,166,.12); color:#d6fff3; }
    .notice.err{ background:rgba(255,107,107,.12); color:#ffe2e2; }
    .sheet{margin-top:22px; background:linear-gradient(180deg, rgba(255,255,255,.04), rgba(255,255,255,.02));
      border:1px solid var(--border); border-radius:28px; box-shadow: var(--shadow); overflow:hidden;}
    .sheet .section{padding:24px 22px; border-top:1px solid rgba(255,255,255,.06);}
    .sheet .section:first-child{border-top:0;}
    .section h3{margin:0 0 14px; font-size:18px; letter-spacing:.3px; font-weight:800; display:flex; align-items:center; gap:10px;}
    .section h3 .dot{width:10px; height:10px; border-radius:999px; background:var(--accent); box-shadow:0 0 0 4px rgba(114,230,180,.18);}
    form{ display:grid; grid-template-columns: 1fr 1fr; gap:16px 20px; }
    @media (max-width:820px){ form{ grid-template-columns:1fr; } }
    .field{display:flex; flex-direction:column; gap:8px; background:rgba(0,0,0,.15); border:1px solid var(--border);
      border-radius:14px; padding:12px; transition: box-shadow .15s, border-color .15s, background .15s;}
    .field:focus-within{ border-color:rgba(124,140,255,.6); box-shadow:var(--ring); background:rgba(0,0,0,.22); }
    label{font-size:12px; color:var(--muted); letter-spacing:.2px}
    input[type="text"], input[type="email"], input[type="file"], select{
      width:100%; padding:12px; border:1px solid rgba(255,255,255,.12); border-radius:10px; background:#0f1428; color:var(--ink); outline:none;
    }
    input[readonly]{opacity:.9; cursor:not-allowed}
    .row{ display:flex; gap:10px; } .row > *{ flex:1; }
    .hint{ font-size:12px; color:var(--muted); }
    .actions{ display:flex; justify-content:center; padding:18px 22px 26px; background:rgba(0,0,0,.14); border-top:1px solid rgba(255,255,255,.06); }
    .btn{appearance:none; border:0; background:linear-gradient(135deg, var(--brand), #5466ff); color:#fff; padding:12px 22px;
      border-radius:999px; font-weight:800; letter-spacing:.3px; cursor:pointer; box-shadow: 0 12px 28px rgba(124,140,255,.35);
      transition: transform .08s ease, filter .15s ease;}
    .btn:hover{ filter:brightness(1.05); } .btn:active{ transform: translateY(1px); }
    .divider{ grid-column:1/-1; margin:8px 0 -2px; color:var(--muted); font-size:13px; font-weight:700; opacity:.9; display:flex; align-items:center; gap:10px; }
    .divider:before, .divider:after{ content:""; height:1px; background:rgba(255,255,255,.12); flex:1; }
    .date-row select{ flex:1; }
    .caps{ font-variant: all-small-caps; letter-spacing:.5px; }
  </style>
</head>
<body>
<div class="layout">
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="brand">DCti Admin</div>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="delta_a.php">Add Student</a></li>
      <li><a href="students_search.php">Search Student</a></li>
      <li><a href="manage_users.php">Manage Users</a></li>
      <li><a href="manage_teachers.php">Manage Teachers</a></li>
      <li><a href="manage_courses.php">Manage Courses</a></li>
      <li><a href="assign_teacher.php">Assign Teacher</a></li>
      <li><a href="course_edit.php">Course Edit</a></li>
      <li><a href="reports.php">Reports</a></li>
      <li><a href="#">Settings</a></li>
    </ul>
  </aside>

  <!-- Main -->
  <main class="main">
    <header class="topbar">
      <h1>Add Student</h1>
      <span><?= date("F d, Y") ?></span>
    </header>

  <div class="wrap">
    <div class="backdrop"></div>

    <div class="hero">
      <div class="logo"><img src="../img/logo.png" alt="Logo"></div>
      <div class="title">
        <h1>ডেলটা কম্পিউটার ট্রেনিং ইন্সটিটিউট</h1>
        <div class="sub">Delta Computer Training Institute — Kaliakoir Hi-Tech Park, Gazipur</div>
      </div>
      <div class="badge">Admission Form</div>
    </div>

    <?php if (!empty($success_msg)): ?>
      <div class="notice ok"><?= h($success_msg) ?></div>
    <?php elseif (!empty($error_msg)): ?>
      <div class="notice err"><?= h($error_msg) ?></div>
    <?php endif; ?>

    <div class="sheet">
      <div class="section">
        <h3><span class="dot"></span> Program Selection</h3>
        <form action="delta_a.php" method="POST" enctype="multipart/form-data" id="admissionForm">

          <div class="field">
            <label>Application for Admission in</label>
            <select name="Admission_Name" required>
              <option value="">Select</option>
              <option value="Basic Office Application" <?= (($_POST['Admission_Name'] ?? '')==='Basic Office Application')?'selected':'' ?>>কম্পিউটার অফিস এপ্লিকেশন</option>
              <option value="Responsive Web Design" <?= (($_POST['Admission_Name'] ?? '')==='Responsive Web Design')?'selected':'' ?>>ওয়েব ডিজাইন + আউটসোর্সিং / ফ্রিল্যান্সিং</option>
              <option value="Digital Marketing" <?= (($_POST['Admission_Name'] ?? '')==='Digital Marketing')?'selected':'' ?>>ডিজিটাল মার্কেটিং + আউটসোর্সিং / ফ্রিল্যান্সিং</option>
              <option value="Graphics Design" <?= (($_POST['Admission_Name'] ?? '')==='Graphics Design')?'selected':'' ?>>গ্রাফিক্স ডিজাইন অ্যান্ড মাল্টিমিডিয়া প্রোগ্রামিং + আউটসোর্সিং / ফ্রিল্যান্সিং</option>
              <option value="Driving cum Auto Mechanics (Driving Training)" <?= (($_POST['Admission_Name'] ?? '')==='Driving cum Auto Mechanics (Driving Training)')?'selected':'' ?>>ড্রাইভিং কাম অটো মেকানিক্স (ড্রাইভিং প্রশিক্ষণ)</option>
              <option value="Others" <?= (($_POST['Admission_Name'] ?? '')==='Others')?'selected':'' ?>>Others</option>
            </select>
          </div>

          <div class="field">
            <label>Duration</label>
            <select name="Cours_Duration" required>
              <option value="">Select</option>
              <option value="1 Month" <?= (($_POST['Cours_Duration'] ?? '')==='1 Month')?'selected':'' ?>>1 Month</option>
              <option value="3 Month" <?= (($_POST['Cours_Duration'] ?? '')==='3 Month')?'selected':'' ?>>3 Month</option>
              <option value="6 Month" <?= (($_POST['Cours_Duration'] ?? '')==='6 Month')?'selected':'' ?>>6 Month</option>
            </select>
          </div>

          <div class="field">
            <label>ID Number <span class="caps">(unique)</span></label>
            <input type="text" name="ID_Number" placeholder="আইডির নাম্বার" value="<?= h($_POST['ID_Number'] ?? '') ?>" required>
          </div>

          <!-- Session with your 6 presets -->
          <div class="field">
            <label>Session</label>
            <select id="session_combo" name="session_combo" required>
              <option value="">Select session</option>
              <?php
                $sessionPreset = $_POST['Session'] ?? $_POST['session_combo'] ?? '';
                function sel($v, $cur){ return $v===$cur ? 'selected' : ''; }
              ?>
              <option value="January-March"     <?= sel('January-March', $sessionPreset) ?>>January-March</option>
              <option value="April-June"        <?= sel('April-June', $sessionPreset) ?>>April-June</option>
              <option value="July-September"    <?= sel('July-September', $sessionPreset) ?>>July-September</option>
              <option value="October-December"  <?= sel('October-December', $sessionPreset) ?>>October-December</option>
              <option value="January-June"      <?= sel('January-June', $sessionPreset) ?>>January-June</option>
              <option value="July-December"     <?= sel('July-December', $sessionPreset) ?>>July-December</option>
            </select>
            <input type="hidden" name="Session" id="Session" value="<?= h($sessionPreset) ?>">
            <div class="hint">Choose one of the preset sessions.</div>
          </div>

          <div class="divider">Student &amp; Parents</div>

          <div class="field">
            <label>Student Name (Bangla)</label>
            <input type="text" name="Students_Bangla_Name" placeholder="বাংলায় নাম" value="<?= h($_POST['Students_Bangla_Name'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Student Name (English)</label>
            <input type="text" name="Students_English_Name" placeholder="ইংরেজীতে নাম" value="<?= h($_POST['Students_English_Name'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Father's Name (Bangla)</label>
            <input type="text" name="Fathers_Bangla_name" placeholder="বাংলায় নাম" value="<?= h($_POST['Fathers_Bangla_name'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Father's Name (English)</label>
            <input type="text" name="Fathers_English_name" placeholder="ইংরেজীতে নাম" value="<?= h($_POST['Fathers_English_name'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Mother's Name (Bangla)</label>
            <input type="text" name="Mothers_Bangla_name" placeholder="বাংলায় নাম" value="<?= h($_POST['Mothers_Bangla_name'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Mother's Name (English)</label>
            <input type="text" name="Mothers_English_name" placeholder="ইংরেজীতে নাম" value="<?= h($_POST['Mothers_English_name'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Mailing Address</label>
            <input type="text" name="Mailing_Address" placeholder="বর্তমান ঠিকানা" value="<?= h($_POST['Mailing_Address'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Permanent Address</label>
            <input type="text" name="Permanent_Address" placeholder="স্থায়ী ঠিকানা" value="<?= h($_POST['Permanent_Address'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Religion</label>
            <select name="Religion" required>
              <option value="">Select</option>
              <option value="Islam"        <?= (($_POST['Religion'] ?? '')==='Islam')?'selected':'' ?>>Islam</option>
              <option value="Hinduism"     <?= (($_POST['Religion'] ?? '')==='Hinduism')?'selected':'' ?>>Hinduism</option>
              <option value="Christianity" <?= (($_POST['Religion'] ?? '')==='Christianity')?'selected':'' ?>>Christianity</option>
              <option value="Buddhism"     <?= (($_POST['Religion'] ?? '')==='Buddhism')?'selected':'' ?>>Buddhism</option>
              <option value="Others"       <?= (($_POST['Religion'] ?? '')==='Others')?'selected':'' ?>>Others</option>
            </select>
          </div>
          <div class="field">
            <label>Gender</label>
            <select name="Gender" required>
              <option value="">Select</option>
              <option value="Male"   <?= (($_POST['Gender'] ?? '')==='Male')?'selected':'' ?>>Male</option>
              <option value="Female" <?= (($_POST['Gender'] ?? '')==='Female')?'selected':'' ?>>Female</option>
              <option value="Others" <?= (($_POST['Gender'] ?? '')==='Others')?'selected':'' ?>>Others</option>
            </select>
          </div>

          <div class="field">
            <label>Date of Birth</label>
            <div class="row date-row">
              <select id="dob_year" name="dob_year"></select>
              <select id="dob_month" name="dob_month"></select>
              <select id="dob_day" name="dob_day"></select>
            </div>
            <div class="hint">Year / Month / Day (1910 onward)</div>
            <input type="hidden" name="Date_of_Birth" id="Date_of_Birth" value="<?= h($_POST['Date_of_Birth'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Blood Group</label>
            <input type="text" name="Blood_Group" placeholder="রক্তের গ্রুপ" value="<?= h($_POST['Blood_Group'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Nationality</label>
            <input type="text" name="Nationality" value="Bangladeshi" readonly>
          </div>

          <div class="field">
            <label>Government ID</label>
            <div class="row">
              <select id="gov_id_type" name="gov_id_type">
                <option value="">Select ID Type</option>
                <option value="NID"   <?= (isset($_POST['gov_id_type']) && $_POST['gov_id_type']==='NID')?'selected':'' ?>>National ID</option>
                <option value="BIRTH" <?= (isset($_POST['gov_id_type']) && $_POST['gov_id_type']==='BIRTH')?'selected':'' ?>>Birth Certificate</option>
              </select>
              <input id="gov_id_number" name="gov_id_number" type="text" placeholder="Enter ID number" value="<?= h($_POST['gov_id_number'] ?? '') ?>">
            </div>
            <div id="gov_id_helper" class="hint">Choose a type, then enter the number.</div>
            <input type="hidden" name="National_ID_Number" id="National_ID_Number" value="<?= h($_POST['National_ID_Number'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Phone Number</label>
            <input type="text" name="Phone_Number" placeholder="মোবাইল নাম্বার" value="<?= h($_POST['Phone_Number'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Email</label>
            <input type="email" name="Email_Address" placeholder="ইমেল আইডি" value="<?= h($_POST['Email_Address'] ?? '') ?>">
          </div>

          <div class="field">
            <label>Photo Upload</label>
            <input type="file" name="Student_Photo" accept="image/*">
            <div class="hint">JPG/PNG/GIF/WEBP, max 2MB</div>
          </div>

          <div class="field">
            <label>Date of Admission</label>
            <div class="row date-row">
              <select id="ad_year" name="ad_year"></select>
              <select id="ad_month" name="ad_month"></select>
              <select id="ad_day" name="ad_day"></select>
            </div>
            <div class="hint">Year / Month / Day</div>
            <input type="hidden" name="Admission_Date" id="Admission_Date" value="<?= h($_POST['Admission_Date'] ?? '') ?>">
          </div>

          <div class="actions">
            <input type="submit" class="btn" name="submit" value="Save & Submit Admission">
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    (function(){
      const startYear = 1910;
      const today = new Date();
      const currentYear = today.getFullYear();
      const form = document.getElementById('admissionForm');

      function populateYMD(prefix, preset){
        const ySel = document.getElementById(prefix + '_year');
        const mSel = document.getElementById(prefix + '_month');
        const dSel = document.getElementById(prefix + '_day');
        if(!ySel || !mSel || !dSel) return;

        ySel.innerHTML = '<option value="">Year</option>';
        for (let y=currentYear; y>=startYear; y--){
          const o=document.createElement('option');
          o.value=o.textContent=y;
          ySel.appendChild(o);
        }

        const monthNames = ["01 - Jan","02 - Feb","03 - Mar","04 - Apr","05 - May","06 - Jun","07 - Jul","08 - Aug","09 - Sep","10 - Oct","11 - Nov","12 - Dec"];
        mSel.innerHTML = '<option value="">Month</option>';
        for (let m=1; m<=12; m++){
          const o=document.createElement('option');
          o.value=m;
          o.textContent=monthNames[m-1];
          mSel.appendChild(o);
        }

        function refillDays(){
          const y = parseInt(ySel.value,10);
          const m = parseInt(mSel.value,10);
          let daysInMonth = 31;
          if (y && m){ daysInMonth = new Date(y, m, 0).getDate(); }
          const prev = dSel.value;
          dSel.innerHTML = '<option value="">Day</option>';
          for (let d=1; d<=daysInMonth; d++){
            const o=document.createElement('option');
            o.value=d;
            o.textContent=String(d).padStart(2,'0');
            dSel.appendChild(o);
          }
          if (prev && parseInt(prev,10) <= daysInMonth){ dSel.value = prev; }
        }
        ySel.addEventListener('change', refillDays);
        mSel.addEventListener('change', refillDays);
        refillDays();

        if (preset){
          const parts = preset.split('-');
          if (parts.length===3){
            ySel.value = parts[0];
            mSel.value = parseInt(parts[1],10);
            refillDays();
            dSel.value = parseInt(parts[2],10);
          }
        }
      }

      function setHiddenOnSubmit(form, prefix, hiddenId){
        if(!form) return;
        form.addEventListener('submit', function(){
          const y = document.getElementById(prefix+'_year').value;
          const m = document.getElementById(prefix+'_month').value;
          const d = document.getElementById(prefix+'_day').value;
          const hidden = document.getElementById(hiddenId);
          if (y && m && d){
            const mm = String(m).padStart(2,'0');
            const dd = String(d).padStart(2,'0');
            hidden.value = `${y}-${mm}-${dd}`;
          } else {
            hidden.value = '';
          }
        });
      }

      // Initialize DOB & Admission Date
      populateYMD('dob', document.getElementById('Date_of_Birth').value || '');
      populateYMD('ad', document.getElementById('Admission_Date').value || (new Date().toISOString().slice(0,10)));
      setHiddenOnSubmit(form, 'dob', 'Date_of_Birth');
      setHiddenOnSubmit(form, 'ad', 'Admission_Date');

      // File name preview
      const photoInput = document.querySelector('input[name="Student_Photo"]');
      if (photoInput) {
        photoInput.addEventListener('change', function(e){
          const fileName = e.target.files[0]?.name || 'No file chosen';
          const hint = this.parentElement.querySelector('.hint');
          if (hint) hint.textContent = fileName + ' (JPG/PNG/GIF/WEBP, max 2MB)';
        });
      }

      // Preset Session dropdown -> hidden "Session"
      (function(){
        const combo = document.getElementById('session_combo');
        const hidden = document.getElementById('Session');
        if (!combo || !hidden || !form) return;

        if (hidden.value) combo.value = hidden.value; // hydrate from server-posted value

        form.addEventListener('submit', function(){
          hidden.value = combo.value || '';
        });
      })();

      // Government ID (Type + Number) -> hidden "National_ID_Number"
      (function(){
        const typeSel   = document.getElementById('gov_id_type');
        const numInput  = document.getElementById('gov_id_number');
        const hiddenNID = document.getElementById('National_ID_Number');
        const help      = document.getElementById('gov_id_helper');
        if (!(typeSel && numInput && hiddenNID)) return;

        function updatePlaceholder(){
          const t = typeSel.value;
          numInput.placeholder = t === 'BIRTH' ? 'Birth Certificate number'
                                : t === 'NID'   ? 'National ID number'
                                : 'Enter ID number';
          if (help){
            help.textContent = (t==='BIRTH')
              ? 'Enter your Birth Certificate number.'
              : (t==='NID')
                ? 'Enter your National ID number.'
                : 'Choose a type, then enter the number.';
          }
        }
        typeSel.addEventListener('change', updatePlaceholder);
        updatePlaceholder();

        // Hydrate if hidden had "NID: 123" / "BIRTH: 456"
        (function hydrate(){
          const v = (hiddenNID.value || '').trim();
          const m = v.match(/^(NID|BIRTH)\s*:\s*(.+)$/i);
          if (m){
            typeSel.value = m[1].toUpperCase();
            numInput.value = m[2];
            updatePlaceholder();
          }
        })();

        if (form){
          form.addEventListener('submit', function(e){
            const t = typeSel.value;
            const n = (numInput.value || '').trim();

            if (t && !n){
              e.preventDefault(); numInput.focus();
              alert('Please enter the selected ID number.'); return;
            }
            if (n && !t){
              e.preventDefault(); typeSel.focus();
              alert('Please select the ID type (National ID or Birth Certificate).'); return;
            }
            hiddenNID.value = (t && n) ? `${t}: ${n}` : '';
          });
        }
      })();

    })();
  </script>
  </main>
</div>
</body>
</html>
