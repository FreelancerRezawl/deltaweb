<?php
// admin/course_edit.php
declare(strict_types=1);

require_once '../includes/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function price_to_cents(?string $s): ?int {
  if ($s === null || $s === '') return null;
  if (!is_numeric($s)) return null;
  return (int)round(((float)$s) * 100);
}
function slugify(string $t): string {
  $t = strtolower(trim($t));
  $t = preg_replace('/[^a-z0-9]+/','-',$t);
  return trim($t,'-') ?: uniqid('course-');
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(400); echo "Missing ?id"; exit; }

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$flash_ok = $flash_err = null;

// Load course
$st = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
$st->execute([$id]);
$course = $st->fetch(PDO::FETCH_ASSOC);
if (!$course) { http_response_code(404); echo "Course not found."; exit; }

// Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update') {
  if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
    $flash_err = "Invalid CSRF token.";
  } else {
    $title = trim((string)($_POST['title'] ?? ''));
    $slug  = trim((string)($_POST['slug'] ?? ''));
    $desc  = trim((string)($_POST['description'] ?? ''));
    $lang  = (string)($_POST['language'] ?? 'bn');
    $level = (string)($_POST['level'] ?? 'beginner');
    $price = price_to_cents($_POST['price'] ?? '');
    $sale  = price_to_cents($_POST['sale_price'] ?? '');
    $curr  = (string)($_POST['currency'] ?? 'BDT');
    $status= (string)($_POST['status'] ?? 'draft');
    $thumb = $course['thumbnail_url'] ?? '';
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
      $uploadDir = 'uploads/courses/';
      if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
      $ext = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
      if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        $fileName = uniqid('course_thumb_') . '.' . $ext;
        $filePath = $uploadDir . $fileName;
        if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $filePath)) {
          $thumb = 'admin/uploads/courses/' . $fileName;
        } else {
          $flash_err = "Failed to upload thumbnail.";
        }
      } else {
        $flash_err = "Invalid image format.";
      }
    }

    if ($title === '') $flash_err = "Title is required.";
    if ($slug === '') $slug = slugify($title);

    if (!$flash_err) {
      // unique slug check (excluding current course)
      $chk = $pdo->prepare("SELECT COUNT(*) FROM courses WHERE slug = ? AND id <> ?");
      $chk->execute([$slug, $id]);
      if ($chk->fetchColumn() > 0) {
        $slug .= '-'.substr(bin2hex(random_bytes(2)),0,4);
      }

      $upd = $pdo->prepare("
        UPDATE courses
          SET title=?, slug=?, description=?, language=?, level=?,
              price_cents=?, sale_price_cents=?, currency=?, status=?, thumbnail_url=?,
              updated_at = NOW()
        WHERE id = ?
      ");
      $upd->execute([
        $title, $slug, $desc ?: null, $lang, $level,
        $price ?? 0, $sale, $curr, $status, $thumb ?: null, $id
      ]);
      $flash_ok = "Course updated successfully.";
      // reload fresh
      $st = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
      $st->execute([$id]);
      $course = $st->fetch(PDO::FETCH_ASSOC);
    }
  }
}

// Small counts
$counts = $pdo->prepare("
  SELECT
   (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = ?) AS enrolled_count,
   (SELECT COUNT(*) FROM course_instructors ci WHERE ci.course_id = ?) AS instructor_count
");
$counts->execute([$id, $id]);
$meta = $counts->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Edit Course #<?= (int)$id ?></title>
  <link rel="stylesheet" href="dashboard.css"/>
  <style>
    .card{background:#fff; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.05); padding:16px}
    .grid-2{display:grid; grid-template-columns:2fr 1fr; gap:16px}
    @media (max-width:900px){.grid-2{grid-template-columns:1fr}}
    .field{display:grid; gap:6px; margin-bottom:10px}
    input,select,textarea{border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px; font:500 14px system-ui; background:#fff}
    label{font-weight:500}
    .row{display:flex; gap:10px; flex-wrap:wrap}
    .btn{display:inline-block; padding:10px 12px; border-radius:10px; border:1px solid #c7d2fe; background:#eef2ff; color:#1e3a8a; font-weight:700; text-decoration:none}
    .btn.primary{background:#2563eb; color:#fff; border-color:#2563eb}
    .btn.ghost{background:#fff}
    .pill{display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; background:#f3f4f6; border:1px solid #e5e7eb}
    .flash{margin:8px 0; padding:10px 12px; border-radius:10px; font-size:14px}
    .ok{background:#ecfeff; border:1px solid #a5f3fc; color:#155e75}
    .err{background:#fff1f2; border:1px solid #fecdd3; color:#9f1239}
    .thumb{width:100%; max-width:320px; height:180px; object-fit:cover; border-radius:10px; border:1px solid #e5e7eb; background:#f3f4f6}
  </style>
  <script>
    function makeSlug(s){ return s.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,''); }
    document.addEventListener('DOMContentLoaded', ()=>{
      const t=document.getElementById('title'), s=document.getElementById('slug');
      if(t&&s){
        t.addEventListener('input', ()=>{ if(s.dataset.touched!=='1') s.value=makeSlug(t.value); });
        s.addEventListener('input', ()=> s.dataset.touched='1');
      }
    });
  </script>
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">DCti Admin</div>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_teachers.php">Manage Teachers</a></li>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="assign_teacher.php">Assign Teacher</a></li>
        <li><a href="course_edit.php">Course Edit</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="#">Settings</a></li>
      </ul>
    </aside>

    <main class="main">
      <header class="topbar">
        <h1>Edit Course #<?= (int)$id ?></h1>
        <span><?= date('F d, Y') ?></span>
      </header>

      <?php if ($flash_ok): ?><div class="flash ok"><?= $flash_ok ?></div><?php endif; ?>
      <?php if ($flash_err): ?><div class="flash err"><?= $flash_err ?></div><?php endif; ?>

      <div class="grid-2">
        <!-- Form -->
        <section class="card">
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="update">

            <div class="row">
              <div class="field" style="flex:1">
                <label>Title *</label>
                <input id="title" name="title" required value="<?= h($course['title']) ?>">
              </div>
              <div class="field" style="flex:1">
                <label>Slug</label>
                <input id="slug" name="slug" value="<?= h($course['slug']) ?>">
              </div>
            </div>

            <div class="field">
              <label>Description</label>
              <textarea name="description" rows="4"><?= h($course['description'] ?? '') ?></textarea>
            </div>

            <div class="row">
              <div class="field" style="flex:1">
                <label>Language</label>
                <select name="language">
                  <option value="bn" <?= $course['language']==='bn'?'selected':'' ?>>bn</option>
                  <option value="en" <?= $course['language']==='en'?'selected':'' ?>>en</option>
                </select>
              </div>
              <div class="field" style="flex:1">
                <label>Level</label>
                <select name="level">
                  <?php foreach (['beginner','intermediate','advanced'] as $lvl): ?>
                    <option value="<?= $lvl ?>" <?= $course['level']===$lvl?'selected':'' ?>><?= $lvl ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="field" style="flex:1">
                <label>Status</label>
                <select name="status">
                  <?php foreach (['draft','published','archived'] as $st): ?>
                    <option value="<?= $st ?>" <?= $course['status']===$st?'selected':'' ?>><?= $st ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="row">
              <div class="field" style="flex:1">
                <label>Price (<?= h($course['currency']) ?>)</label>
                <input type="number" step="0.01" name="price"
                       value="<?= number_format(((int)$course['price_cents'])/100, 2, '.', '') ?>">
              </div>
              <div class="field" style="flex:1">
                <label>Sale Price</label>
                <input type="number" step="0.01" name="sale_price"
                       value="<?= is_null($course['sale_price_cents']) ? '' : number_format(((int)$course['sale_price_cents'])/100, 2, '.', '') ?>">
              </div>
              <div class="field" style="flex:1">
                <label>Currency</label>
                <select name="currency">
                  <?php foreach (['BDT','USD'] as $c): ?>
                    <option value="<?= $c ?>" <?= $course['currency']===$c?'selected':'' ?>><?= $c ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="field">
              <label>Thumbnail</label>
              <input type="file" name="thumbnail" accept="image/*">
              <?php if (!empty($course['thumbnail_url'])): ?>
                <small>Current: <a href="<?= h($course['thumbnail_url']) ?>" target="_blank">View</a></small>
              <?php endif; ?>
            </div>

            <div class="row">
              <button class="btn primary" type="submit">Save Changes</button>
              <a class="btn ghost" href="manage_courses.php">Back to list</a>
            </div>
          </form>
        </section>

        <!-- Meta / Preview -->
        <section class="card">
          <h3 style="margin-top:0"><?= h($course['title']) ?></h3>
          <div class="pill"><?= h($course['status']) ?></div>
          <div class="pill"><?= h($course['level']) ?></div>
          <div style="margin:10px 0" class="muted">
            Created: <?= h(date('M d, Y H:i', strtotime((string)$course['created_at']))) ?><br>
            Updated: <?= h(date('M d, Y H:i', strtotime((string)$course['updated_at']))) ?><br>
            Instructors: <?= (int)($meta['instructor_count'] ?? 0) ?> |
            Enrolled: <?= (int)($meta['enrolled_count'] ?? 0) ?>
          </div>
          <img class="thumb" src="<?= !empty($course['thumbnail_url']) ? h($course['thumbnail_url']) : 'https://via.placeholder.com/320x180/f3f4f6/6b7280?text=No+Thumb' ?>" alt="Thumbnail">
          <div class="muted" style="margin-top:10px">Slug: <b><?= h($course['slug']) ?></b></div>
        </section>
      </div>
    </main>
  </div>
</body>
</html>
