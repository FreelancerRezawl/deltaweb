<?php
// FILE: admin/search_students.php
// Search students + inline edit & update (no auth popup)

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/../includes/config.php'; // provides $pdo

// ---------- Helpers ----------
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function csrf_token(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function csrf_check($t){ return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)$t); }

// Unified list of sessions (presets + single months)
$SESSION_OPTIONS = [
  // Presets
  'January-March','April-June','July-September','October-December','January-June','July-December',
  // Singles
  'January','February','March','April','May','June','July','August','September','October','November','December'
];

$success_msg = '';
$error_msg   = '';

$mode  = (isset($_GET['edit']) && ctype_digit((string)$_GET['edit'])) ? 'edit' : 'search';
$editId = $mode === 'edit' ? (int)$_GET['edit'] : 0;

// ---------- UPDATE (Edit Submit) ----------
if ($mode === 'edit' && isset($_POST['update'])) {
    if (!csrf_check($_POST['csrf'] ?? '')) {
        $error_msg = 'Security check failed. Please reload the page.';
    } else {
        $fields = [
            'admission_name'       => trim($_POST['Admission_Name'] ?? ''),
            'cours_duration'       => trim($_POST['Cours_Duration'] ?? ''),
            'id_number'            => trim($_POST['ID_Number'] ?? ''),
            'session'              => trim($_POST['Session'] ?? ''),
            'students_bangla_name' => trim($_POST['Students_Bangla_Name'] ?? ''),
            'students_english_name'=> trim($_POST['Students_English_Name'] ?? ''),
            'fathers_bangla_name'  => trim($_POST['Fathers_Bangla_name'] ?? ''),
            'fathers_english_name' => trim($_POST['Fathers_English_name'] ?? ''),
            'mothers_bangla_name'  => trim($_POST['Mothers_Bangla_name'] ?? ''),
            'mothers_english_name' => trim($_POST['Mothers_English_name'] ?? ''),
            'mailing_address'      => trim($_POST['Mailing_Address'] ?? ''),
            'permanent_address'    => trim($_POST['Permanent_Address'] ?? ''),
            'religion'             => trim($_POST['Religion'] ?? ''),
            'gender'               => trim($_POST['Gender'] ?? ''),
            'date_of_birth'        => trim($_POST['Date_of_Birth'] ?? ''),
            'blood_group'          => trim($_POST['Blood_Group'] ?? ''),
            'nationality'          => 'Bangladeshi',
            'national_id_number'   => trim($_POST['National_ID_Number'] ?? ''),
            'phone_number'         => trim($_POST['Phone_Number'] ?? ''),
            'email_address'        => trim($_POST['Email_Address'] ?? ''),
            'admission_date'       => trim($_POST['Admission_Date'] ?? ''),
        ];

        // Validate dates (match admission form)
        $today  = date('Y-m-d');
        $max_ad = date('Y-m-d', strtotime('+30 days'));
        if ($fields['date_of_birth'] < '1910-01-01' || $fields['date_of_birth'] > $today) {
            $error_msg = 'Please select a valid Date of Birth (1910 to today).';
        }
        if (!$error_msg && ($fields['admission_date'] < '1910-01-01' || $fields['admission_date'] > $max_ad)) {
            $error_msg = 'Please select a valid Admission Date (up to 30 days in future).';
        }

        // Photo upload
        $new_photo_rel = null; // null = unchanged; '' = remove; 'uploads/..' = new
        $upload_dir_fs = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
        $upload_dir_fs .= '/uploads/';
        if (!is_dir($upload_dir_fs)) { @mkdir($upload_dir_fs, 0755, true); }

        if (!$error_msg && isset($_FILES['Student_Photo']) && $_FILES['Student_Photo']['error'] === UPLOAD_ERR_OK) {
            $allowed_exts  = ['jpg','jpeg','png','gif','webp'];
            $allowed_mimes = ['image/jpeg','image/png','image/gif','image/webp'];
            $max_bytes     = 2 * 1024 * 1024;

            $orig = $_FILES['Student_Photo']['name'];
            $tmp  = $_FILES['Student_Photo']['tmp_name'];
            $size = $_FILES['Student_Photo']['size'];

            if ($size > $max_bytes) {
                $error_msg = 'Photo must be ≤ 2MB.';
            } else {
                $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
                if (!in_array($ext, $allowed_exts, true)) {
                    $error_msg = 'Only JPG, PNG, GIF, WEBP images are allowed.';
                } else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime  = $finfo ? finfo_file($finfo, $tmp) : '';
                    if ($finfo) finfo_close($finfo);
                    if (!in_array($mime, $allowed_mimes, true)) {
                        $error_msg = 'Invalid image type.';
                    } else {
                        $safeBase = preg_replace('/[^A-Za-z0-9_\-]/', '_', pathinfo($orig, PATHINFO_FILENAME));
                        $newName  = $safeBase . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
                        if (move_uploaded_file($tmp, $upload_dir_fs . $newName)) {
                            $new_photo_rel = 'uploads/' . $newName;
                        } else {
                            $error_msg = 'Server failed to save file (permissions?).';
                        }
                    }
                }
            }
        } elseif (isset($_POST['remove_photo']) && $_POST['remove_photo'] === '1') {
            $new_photo_rel = '';
        }

        if (!$error_msg) {
            $sql = "UPDATE students_admission SET
                admission_name=?, cours_duration=?, id_number=?, session=?,
                students_bangla_name=?, students_english_name=?,
                fathers_bangla_name=?, fathers_english_name=?,
                mothers_bangla_name=?, mothers_english_name=?,
                mailing_address=?, permanent_address=?, religion=?, gender=?,
                date_of_birth=?, blood_group=?, nationality=?, national_id_number=?,
                phone_number=?, email_address=?, admission_date=?";

            $params = [
                $fields['admission_name'], $fields['cours_duration'], $fields['id_number'], $fields['session'],
                $fields['students_bangla_name'], $fields['students_english_name'],
                $fields['fathers_bangla_name'], $fields['fathers_english_name'],
                $fields['mothers_bangla_name'], $fields['mothers_english_name'],
                $fields['mailing_address'], $fields['permanent_address'], $fields['religion'], $fields['gender'],
                $fields['date_of_birth'], $fields['blood_group'], $fields['nationality'], $fields['national_id_number'],
                $fields['phone_number'], $fields['email_address'], $fields['admission_date']
            ];

            if ($new_photo_rel !== null) {
                if ($new_photo_rel === '') {
                    $sql .= ", student_photo = NULL";
                } else {
                    $sql .= ", student_photo = ?";
                    $params[] = $new_photo_rel;
                }
            }

            $sql .= " WHERE id = ?";
            $params[] = $editId;

            try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $success_msg = 'Student updated successfully.';
            } catch (PDOException $e) {
                $error_msg = 'Update failed: ' . h($e->getMessage());
            }
        }
    }
}

// ---------- Load record for edit view ----------
$editRow = null;
if ($mode === 'edit') {
    $stmt = $pdo->prepare("SELECT * FROM students_admission WHERE id = ?");
    $stmt->execute([$editId]);
    $editRow = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$editRow) { $error_msg = 'Record not found.'; $mode = 'search'; }
}

// ---------- Search ----------
$search_query = trim($_GET['search'] ?? '');
$filter_session = trim($_GET['session'] ?? ''); // new filter for session
$results = [];
if ($mode === 'search') {
    $where = [];
    $params = [];

    if ($search_query !== '') {
        $like = '%' . $search_query . '%';
        $where[] = "(students_english_name LIKE ? OR students_bangla_name LIKE ? OR id_number LIKE ? OR phone_number LIKE ? OR email_address LIKE ?)";
        array_push($params, $like, $like, $like, $like, $like);
    }
    if ($filter_session !== '') {
        $where[] = "session = ?";
        $params[] = $filter_session;
    }

    $where_sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    $sql = "SELECT * FROM students_admission $where_sql ORDER BY id DESC LIMIT 500";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Search & Edit Students</title>
  <link rel="stylesheet" href="dashboard.css">
  <style>
    .main { padding: 20px; }
    .topbar h1 { margin: 0; color: #333; }
    .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
    .notice { padding: 10px 12px; border-radius: 6px; margin: 10px 0; }
    .ok { background: #e9f9f0; color: #126b3f; border:1px solid #c9eddc; }
    .err{ background: #ffeaea; color: #7b1111; border:1px solid #f0c7c7; }

    input[type="text"], input[type="email"], input[type="date"], select, textarea {
      width: 100%; padding: 10px; font-size: 14px; margin-bottom: 10px; box-sizing: border-box; border:1px solid #ccc; border-radius: 6px;
    }
    input[type="file"] { margin: 6px 0 10px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 800px){ .grid{ grid-template-columns: 1fr; } }
    .row { display:flex; gap:10px; align-items:center; flex-wrap: wrap; }

    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 10px; border: 1px solid #ccc; text-align: left; font-size: 14px; }
    th { background-color: #007BFF; color: white; }
    img { max-width: 80px; border-radius: 4px; border:1px solid #ddd; background:#fafafa; }
    .btn { padding: 6px 10px; text-decoration: none; color: white; border-radius: 4px; font-size: 13px; display:inline-block; border:0; cursor:pointer; }
    .edit-btn { background-color: #17a2b8; }
    .back-btn { background: #6c757d; }
    .save-btn { background: #007bff; }
    .muted { color:#666; font-size:12px; }
    .pill { display:inline-block; background:#eef4ff; color:#224; padding:2px 8px; border-radius:999px; border:1px solid #cfe2ff; font-size:12px; }
  </style>
</head>
<body>
<div class="layout">
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="brand">DCti Admin</div>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="delta_a.php">Add Student</a></li>
      <li><a href="students_search.php">Search Student</a></li>
      <li><a href="manage_users.php">Manage Users</a></li>
      <li><a href="manage_teachers.php">Manage Teachers</a></li>
      <li><a href="manage_courses.php">Manage Courses</a></li>
      <li><a href="assign_teacher.php">Assign Teacher</a></li>
      <li><a href="course_edit.php">Course Edit</a></li>
      <li><a href="reports.php">Reports</a></li>
      <li><a href="#">Settings</a></li>
    </ul>
  </aside>

  <!-- Main -->
  <main class="main">
    <header class="topbar">
      <h1>Search Students</h1>
      <span><?= date("F d, Y") ?></span>
    </header>

    <div class="container">
      <?php if ($success_msg): ?><div class="notice ok"><?= h($success_msg) ?></div><?php endif; ?>
      <?php if ($error_msg):   ?><div class="notice err"><?= h($error_msg) ?></div><?php endif; ?>

      <?php if ($mode === 'search'): ?>
        <form method="GET" action="">
          <div class="grid">
            <div>
              <input type="text" name="search" placeholder="Search by Name, ID, Phone or Email..." value="<?= h($search_query) ?>" autofocus>
            </div>
            <div>
              <select name="session">
                <option value="">All Sessions</option>
                <?php $sess = $filter_session;
                  foreach ($SESSION_OPTIONS as $opt){
                    $sel = ($opt === $sess) ? 'selected' : '';
                    echo '<option value="'.h($opt).'" '.$sel.'>'.h($opt).'</option>';
                  }
                ?>
              </select>
            </div>
          </div>
        </form>

        <?php if (!empty($results)): ?>
          <table>
            <thead>
              <tr>
                <th>DB ID</th>
                <th>ID Number</th>
                <th>Name</th>
                <th>Father</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Photo</th>
                <th>Session / Program</th>
                <th>Admission</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($results as $student): ?>
                <tr>
                  <td><?= h($student['id']) ?></td>
                  <td><?= h($student['id_number']) ?></td>
                  <td><?= h($student['students_english_name']) ?><br><small><?= h($student['students_bangla_name']) ?></small></td>
                  <td><?= h($student['fathers_english_name']) ?><br><small><?= h($student['fathers_bangla_name']) ?></small></td>
                  <td><?= h($student['phone_number']) ?></td>
                  <td><?= h($student['email_address']) ?></td>
                  <td>
                    <?php if (!empty($student['student_photo'])): ?>
                      <img src="../<?= h($student['student_photo']) ?>" alt="Photo">
                    <?php else: ?>
                      <span class="muted">No photo</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <div><span class="pill"><?= h($student['session']) ?></span></div>
                    <small class="muted"><?= h($student['admission_name']) ?></small>
                  </td>
                  <td><?= h($student['admission_date']) ?></td>
                  <td><a class="btn edit-btn" href="?edit=<?= (int)$student['id'] ?>">Edit</a></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php elseif ($search_query !== "" || $filter_session !== ""): ?>
          <p style="color:red;">No results found.</p>
        <?php endif; ?>
      <?php endif; ?>

      <?php if ($mode === 'edit' && $editRow): ?>
        <div class="row" style="justify-content: space-between; margin-bottom: 10px;">
          <a class="btn back-btn" href="students_search.php">← Back</a>
          <div>Editing Record: <strong>#<?= (int)$editRow['id'] ?></strong></div>
        </div>

        <form method="post" enctype="multipart/form-data">
          <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
          <div class="grid">
            <div>
              <label>Application for Admission in</label>
              <?php $cur = $editRow['admission_name']; ?>
              <select name="Admission_Name" required>
                <option value="">Select</option>
                <option value="Basic Office Application" <?= $cur==='Basic Office Application'?'selected':'' ?>>Basic Office Application</option>
                <option value="Responsive Web Design" <?= $cur==='Responsive Web Design'?'selected':'' ?>>Responsive Web Design</option>
                <option value="Digital Marketing" <?= $cur==='Digital Marketing'?'selected':'' ?>>Digital Marketing</option>
                <option value="Graphics Design" <?= $cur==='Graphics Design'?'selected':'' ?>>Graphics Design</option>
                <option value="Driving cum Auto Mechanics (Driving Training)" <?= $cur==='Driving cum Auto Mechanics (Driving Training)'?'selected':'' ?>>Driving cum Auto Mechanics (Driving Training)</option>
                <option value="Others" <?= $cur==='Others'?'selected':'' ?>>Others</option>
              </select>
            </div>

            <div>
              <label>Duration</label>
              <?php $cur = $editRow['cours_duration']; ?>
              <select name="Cours_Duration" required>
                <option value="">Select</option>
                <option value="1 Month" <?= $cur==='1 Month'?'selected':'' ?>>1 Month</option>
                <option value="3 Month" <?= $cur==='3 Month'?'selected':'' ?>>3 Month</option>
                <option value="6 Month" <?= $cur==='6 Month'?'selected':'' ?>>6 Month</option>
              </select>
            </div>

            <div>
              <label>ID Number (unique)</label>
              <input type="text" name="ID_Number" value="<?= h($editRow['id_number']) ?>" required>
            </div>

            <div>
              <label>Session</label>
              <?php $sess = $editRow['session']; ?>
              <select name="Session" required>
                <option value="">Select session</option>
                <?php
                  foreach ($SESSION_OPTIONS as $opt){
                    $sel = ($opt === $sess) ? 'selected' : '';
                    echo '<option value="'.h($opt).'" '.$sel.'>'.h($opt).'</option>';
                  }
                ?>
              </select>
            </div>

            <div><label>Student Name (Bangla)</label><input type="text" name="Students_Bangla_Name" value="<?= h($editRow['students_bangla_name']) ?>"></div>
            <div><label>Student Name (English)</label><input type="text" name="Students_English_Name" value="<?= h($editRow['students_english_name']) ?>"></div>
            <div><label>Father\'s Name (Bangla)</label><input type="text" name="Fathers_Bangla_name" value="<?= h($editRow['fathers_bangla_name']) ?>"></div>
            <div><label>Father\'s Name (English)</label><input type="text" name="Fathers_English_name" value="<?= h($editRow['fathers_english_name']) ?>"></div>
            <div><label>Mother\'s Name (Bangla)</label><input type="text" name="Mothers_Bangla_name" value="<?= h($editRow['mothers_bangla_name']) ?>"></div>
            <div><label>Mother\'s Name (English)</label><input type="text" name="Mothers_English_name" value="<?= h($editRow['mothers_english_name']) ?>"></div>

            <div><label>Mailing Address</label><input type="text" name="Mailing_Address" value="<?= h($editRow['mailing_address']) ?>"></div>
            <div><label>Permanent Address</label><input type="text" name="Permanent_Address" value="<?= h($editRow['permanent_address']) ?>"></div>

            <div>
              <label>Religion</label>
              <?php $cur = $editRow['religion']; ?>
              <select name="Religion">
                <option value="">Select</option>
                <option value="Islam"        <?= $cur==='Islam'?'selected':'' ?>>Islam</option>
                <option value="Hinduism"     <?= $cur==='Hinduism'?'selected':'' ?>>Hinduism</option>
                <option value="Christianity" <?= $cur==='Christianity'?'selected':'' ?>>Christianity</option>
                <option value="Buddhism"     <?= $cur==='Buddhism'?'selected':'' ?>>Buddhism</option>
                <option value="Others"       <?= $cur==='Others'?'selected':'' ?>>Others</option>
              </select>
            </div>

            <div>
              <label>Gender</label>
              <?php $cur = $editRow['gender']; ?>
              <select name="Gender">
                <option value="">Select</option>
                <option value="Male"   <?= $cur==='Male'?'selected':'' ?>>Male</option>
                <option value="Female" <?= $cur==='Female'?'selected':'' ?>>Female</option>
                <option value="Others" <?= $cur==='Others'?'selected':'' ?>>Others</option>
              </select>
            </div>

            <div><label>Date of Birth</label><input type="date" name="Date_of_Birth" value="<?= h($editRow['date_of_birth']) ?>"></div>
            <div><label>Blood Group</label><input type="text" name="Blood_Group" value="<?= h($editRow['blood_group']) ?>"></div>

            <div>
              <label>Government ID</label>
              <input type="text" name="National_ID_Number" value="<?= h($editRow['national_id_number']) ?>" placeholder="NID: 123... or BIRTH: 123...">
            </div>

            <div><label>Phone Number</label><input type="text" name="Phone_Number" value="<?= h($editRow['phone_number']) ?>"></div>
            <div><label>Email</label><input type="email" name="Email_Address" value="<?= h($editRow['email_address']) ?>"></div>

            <div>
              <label>Photo (replace)</label>
              <input type="file" name="Student_Photo" accept="image/*">
              <?php if (!empty($editRow['student_photo'])): ?>
                <div class="row" style="margin-top:6px;">
                  <img src="../<?= h($editRow['student_photo']) ?>" alt="Current Photo">
                  <label><input type="checkbox" name="remove_photo" value="1"> Remove photo</label>
                </div>
              <?php endif; ?>
              <div class="muted">JPG/PNG/GIF/WEBP, max 2MB</div>
            </div>

            <div><label>Date of Admission</label><input type="date" name="Admission_Date" value="<?= h($editRow['admission_date']) ?>"></div>
          </div>

          <div class="row" style="justify-content:flex-end; margin-top:10px;">
            <button type="submit" name="update" value="1" class="btn save-btn">Save Changes</button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </main>
</div>

</body>
</html>
