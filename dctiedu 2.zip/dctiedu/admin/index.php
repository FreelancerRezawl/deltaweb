<?php
// admin/index.php (Modern UI Dashboard - No login required)
require_once '../includes/config.php';

// Fetch stats
$totalStudents = $pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$totalTeachers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='teacher'")->fetchColumn();
$totalCourses  = $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$totalPayments = $pdo->query("SELECT SUM(amount_cents)/100 FROM payments WHERE status='success'")->fetchColumn() ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="dashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="brand">DCti Admin</div>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="delta_a.php">Add Student</a></li>
        <li><a href="students_search.php">Search Student</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_teachers.php">Manage Teachers</a></li>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="assign_teacher.php">Assign Teacher</a></li>
        <li><a href="course_edit.php">Course Edit</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="#">Settings</a></li>
      </ul>
    </aside>

    <!-- Main -->
    <main class="main">
      <header class="topbar">
        <h1>Dashboard</h1>
        <span><?= date("F d, Y") ?></span>
      </header>

      <!-- Stats -->
      <section class="stats">
        <div class="stat"><h3>Students</h3><p><?= $totalStudents ?></p></div>
        <div class="stat"><h3>Teachers</h3><p><?= $totalTeachers ?></p></div>
        <div class="stat"><h3>Courses</h3><p><?= $totalCourses ?></p></div>
        <div class="stat"><h3>Revenue</h3><p>৳ <?= number_format($totalPayments,2) ?></p></div>
      </section>

      <!-- Charts -->
      <section class="charts">
        <div class="chart-card">
          <h3>Academic Performance</h3>
          <canvas id="lineChart"></canvas>
        </div>
        <div class="chart-card">
          <h3>Earnings</h3>
          <canvas id="barChart"></canvas>
        </div>
      </section>

      <!-- Bottom panels -->
      <section class="bottom">
        <div class="card">
          <h3>Messages</h3>
          <ul class="messages">
            <li><b>Susan Grey</b> Reminder: Meeting at 3 PM</li>
            <li><b>Jordan Kim</b> Trouble accessing library</li>
            <li><b>Dean Neal</b> Welcome new faculty</li>
          </ul>
        </div>
        <div class="card">
          <h3>Students</h3>
          <canvas id="pieChart"></canvas>
        </div>
        <div class="card">
          <h3>Student Activity</h3>
          <ul>
            <li>🏅 Math Olympiad - Gold Medal</li>
            <li>🚀 Project Showcase - Innovation Award</li>
            <li>🤝 Volunteer Day - Lead Organizer</li>
          </ul>
        </div>
      </section>
    </main>
  </div>

<script>
// Line Chart
new Chart(document.getElementById('lineChart'), {
  type: 'line',
  data: {
    labels: ['2023','2024','2025','2026'],
    datasets: [{
      label: 'Performance %',
      data: [40, 55, 70, 65],
      borderColor: '#2563eb',
      fill: true,
      tension: .3
    }]
  }
});

// Bar Chart
new Chart(document.getElementById('barChart'), {
  type: 'bar',
  data: {
    labels: ['Jan','Feb','Mar','Apr','May'],
    datasets: [
      {label:'Earnings', data:[50000,60000,70000,55000,80000], backgroundColor:'#16a34a'},
      {label:'Expenses', data:[30000,35000,40000,30000,45000], backgroundColor:'#f59e0b'}
    ]
  }
});

// Pie Chart
new Chart(document.getElementById('pieChart'), {
  type: 'doughnut',
  data: {
    labels: ['2023','2024','2025'],
    datasets: [{
      data:[1200,1250,1400],
      backgroundColor:['#2563eb','#16a34a','#f59e0b']
    }]
  }
});
</script>
</body>
</html>
