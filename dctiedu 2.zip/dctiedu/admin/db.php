<?php
// FILE: /var/www/html/delta/db.php
// Central DB connection for dctiedu

declare(strict_types=1);

ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/php_errors.log');

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "dctiedu";

$charset = 'utf8mb4';
$dsn = "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

/**
 * Returns a singleton PDO connection.
 * Usage: $conn = db();
 */
function db(): PDO {
    static $conn = null;
    global $dsn, $DB_USER, $DB_PASS, $options;

    if ($conn instanceof PDO) {
        return $conn;
    }

    try {
        $conn = new PDO($dsn, $DB_USER, $DB_PASS, $options);
    } catch (\PDOException $e) {
        http_response_code(500);
        die("Database connection failed: " . htmlspecialchars($e->getMessage()));
    }
    return $conn;
}
