<?php // header.php ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Delta Institute</title>

<style>
  :root{
    --brand-text:#0f172a;           /* slate-900 */
    --muted:#64748b;                /* slate-500 */
    --line:#eef2f7;                 /* subtle border */
    --bg:#ffffff;
    --bg-soft:#fafafa;

    /* Social brand colors */
    --fb:#1877F2;
    --tw:#1DA1F2;   /* Twitter blue */
    --ig1:#F58529;  --ig2:#DD2A7B;  --ig3:#8134AF;  --ig4:#515BD4; /* gradient */
    --yt:#FF0000;
    --accent:#f1f5f9;
  }

  /* ===== Base ===== */
  *{box-sizing:border-box}
  body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:var(--brand-text);background:var(--bg)}
  a{color:inherit;text-decoration:none}
  .container{max-width:1200px;margin:0 auto;padding:0 20px}

  /* ===== Top header (hides on scroll) ===== */
  .top-header{
    background:var(--bg);
    border-bottom:1px solid var(--line);
    font-size:14px;
    line-height:1.2;
  }
  .top-header__row{
    display:flex;align-items:center;justify-content:space-between;
    padding:10px 0;
    gap:12px;
  }
  .contact{
    display:flex;flex-wrap:wrap;gap:12px;color:var(--muted);font-weight:600
  }
  .contact span{white-space:nowrap}
  .social{
    display:flex;align-items:center;gap:10px;
  }
  .social a{
    width:34px;height:34px;border-radius:999px;display:inline-grid;place-items:center;
    background:#f6f7f9;border:1px solid var(--line);
    transition:transform .15s ease, box-shadow .15s ease, background .15s ease;
  }
  .social a svg{width:18px;height:18px;display:block}
  .social a:hover{transform:translateY(-2px);box-shadow:0 6px 16px rgba(0,0,0,.08)}
  /* brand fills */
  .social a.fb{background:var(--fb)} .social a.fb svg{fill:#fff}
  .social a.tw{background:var(--tw)} .social a.tw svg{fill:#fff}
  .social a.ig{
    background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, var(--ig1) 45%, var(--ig2) 60%, var(--ig3) 90%),
                linear-gradient(45deg, var(--ig4), var(--ig3));
    border-color:transparent;
  }
  .social a.ig svg{fill:#fff}
  .social a.yt{background:var(--yt)} .social a.yt svg{fill:#fff}

  /* ===== Sticky Navbar ===== */
  .navbar{
    position:sticky;top:0;z-index:999;background:var(--bg);
    box-shadow:0 2px 8px rgba(15,23,42,.06);
  }
  .nav-row{
    display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;
  }
  .logo-wrap{display:flex;align-items:center;gap:12px}
  .logo-wrap img{height:44px}
  .menu{
    display:flex;align-items:center;gap:18px;font-weight:700;
  }
  .menu a{padding:8px 10px;border-radius:10px}
  .menu a:hover{background:var(--accent)}
  .right{
    display:flex;align-items:center;gap:10px
  }
  .flag{width:26px;height:18px;object-fit:cover;border-radius:3px;border:1px solid var(--line)}
  .profile{
    width:36px;height:36px;border-radius:999px;border:1px solid var(--line);
    display:grid;place-items:center;font-size:18px;background:var(--bg-soft)
  }

  /* ===== Marquee (shows after scroll) ===== */
  .marquee{display:none;background:var(--bg-soft);border-bottom:1px solid var(--line)}
  .marquee__inner{
    overflow:hidden;white-space:nowrap;padding:6px 0;font-weight:700;color:#333
  }
  .marquee__inner span{
    display:inline-block;padding-left:100%;animation:marq 14s linear infinite
  }
  @keyframes marq{from{transform:translateX(0)}to{transform:translateX(-100%)}}

  /* ===== Mobile ===== */
  .hamburger{display:none;cursor:pointer;border:1px solid var(--line);border-radius:10px;padding:8px;background:var(--bg-soft)}
  .hamburger span{display:block;width:22px;height:2px;background:#111;margin:4px 0}

  @media (max-width: 992px){
    .menu{gap:12px}
  }
  @media (max-width: 820px){
    .menu{display:none;position:absolute;left:0;right:0;top:100%;background:var(--bg);padding:12px 20px;border-top:1px solid var(--line)}
    .menu.open{display:flex;flex-direction:column;gap:6px}
    .hamburger{display:block}
  }
  @media (max-width:640px){
    .contact{font-weight:600}
    .logo-wrap img{height:38px}
  }
</style>
</head>
<body>

<!-- ===== Top Header ===== -->
<div class="top-header" id="topHeader">
  <div class="container top-header__row">
    <div class="contact">
      <span>Email: deltacomputer53181@gmail.com</span>
      <span>Phone: +8801319511008 , +8801319511009</span>
    </div>

    <div class="social" aria-label="Social media">
      <!-- Facebook -->
      <a class="fb" href="#" aria-label="Facebook">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 12.07C22 6.477 17.523 2 11.93 2 6.338 2 1.86 6.477 1.86 12.07c0 4.997 3.657 9.145 8.438 9.93v-7.02H7.898v-2.91h2.4V9.845c0-2.37 1.414-3.676 3.579-3.676 1.037 0 2.123.185 2.123.185v2.34h-1.197c-1.18 0-1.548.733-1.548 1.485v1.78h2.635l-.421 2.91h-2.214v7.02C18.343 21.215 22 17.067 22 12.07z"/></svg>
      </a>
      <!-- Twitter -->
      <a class="tw" href="#" aria-label="Twitter">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.27 4.27 0 0 0 1.87-2.36 8.53 8.53 0 0 1-2.71 1.03 4.25 4.25 0 0 0-7.24 3.88A12.07 12.07 0 0 1 3.16 4.9a4.25 4.25 0 0 0 1.32 5.67 4.2 4.2 0 0 1-1.93-.53v.05a4.25 4.25 0 0 0 3.41 4.17 4.3 4.3 0 0 1-1.92.07 4.26 4.26 0 0 0 3.97 2.95A8.52 8.52 0 0 1 2 19.54a12.03 12.03 0 0 0 6.53 1.92c7.84 0 12.13-6.5 12.13-12.13l-.01-.55A8.7 8.7 0 0 0 22.46 6z"/></svg>
      </a>
      <!-- Instagram -->
      <a class="ig" href="#" aria-label="Instagram">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.16c3.2 0 3.584.012 4.85.07 1.17.055 1.8.248 2.22.412.56.217.96.476 1.38.896.42.42.68.82.896 1.38.164.42.357 1.05.412 2.22.058 1.266.07 1.65.07 4.85s-.012 3.584-.07 4.85c-.055 1.17-.248 1.8-.412 2.22a3.95 3.95 0 0 1-.896 1.38 3.95 3.95 0 0 1-1.38.896c-.42.164-1.05.357-2.22.412-1.266.058-1.65.07-4.85.07s-3.584-.012-4.85-.07c-1.17-.055-1.8-.248-2.22-.412a3.95 3.95 0 0 1-1.38-.896 3.95 3.95 0 0 1-.896-1.38c-.164-.42-.357-1.05-.412-2.22C2.172 15.584 2.16 15.2 2.16 12s.012-3.584.07-4.85c.055-1.17.248-1.8.412-2.22.217-.56.476-.96.896-1.38s.82-.68 1.38-.896c.42-.164 1.05-.357 2.22-.412C8.416 2.172 8.8 2.16 12 2.16Zm0 1.8c-3.15 0-3.522.012-4.762.069-.98.045-1.512.209-1.865.347-.47.182-.8.399-1.152.75-.35.352-.568.681-.75 1.152-.138.353-.302.885-.347 1.865-.057 1.24-.069 1.612-.069 4.762s.012 3.522.069 4.762c.045.98.209 1.512.347 1.865.182.47.399.8.75 1.152.352.35.681.568 1.152.75.353.138.885.302 1.865.347 1.24.057 1.612.069 4.762.069s3.522-.012 4.762-.069c.98-.045 1.512-.209 1.865-.347.47-.182.8-.399 1.152-.75.35-.352.568-.681.75-1.152.138-.353.302-.885.347-1.865.057-1.24.069-1.612.069-4.762s-.012-3.522-.069-4.762c-.045-.98-.209-1.512-.347-1.865-.182-.47-.399-.8-.75-1.152a2.74 2.74 0 0 0-1.152-.75c-.353-.138-.885-.302-1.865-.347-1.24-.057-1.612-.069-4.762-.069Zm0 3.84a5.2 5.2 0 1 1 0 10.4 5.2 5.2 0 0 1 0-10.4Zm0 1.8a3.4 3.4 0 1 0 0 6.8 3.4 3.4 0 0 0 0-6.8Zm5.46-2.22a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4Z"/></svg>
      </a>
      <!-- YouTube -->
      <a class="yt" href="#" aria-label="YouTube">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23.5 6.2a3.04 3.04 0 0 0-2.14-2.15C19.64 3.5 12 3.5 12 3.5s-7.64 0-9.36.55A3.04 3.04 0 0 0 .5 6.2 31.3 31.3 0 0 0 0 12a31.3 31.3 0 0 0 .5 5.8 3.04 3.04 0 0 0 2.14 2.15C4.36 20.5 12 20.5 12 20.5s7.64 0 9.36-.55A3.04 3.04 0 0 0 23.5 17.8 31.3 31.3 0 0 0 24 12a31.3 31.3 0 0 0-.5-5.8ZM9.75 15.5v-7l6 3.5-6 3.5Z"/></svg>
      </a>
    </div>
  </div>
</div>

<!-- ===== Sticky Navbar ===== -->
<div class="navbar">
  <div class="container nav-row">
    <div class="logo-wrap">
      <img src="logo/logo.png" alt="Delta Computer Training Institute" />
    </div>

    <button class="hamburger" id="hamburger" aria-label="Toggle menu">
      <span></span><span></span><span></span>
    </button>

    <nav class="menu" id="menu">
      <a href="#">Home</a>
      <a href="#">Freelancing</a>
      <a href="#">Success Story</a>
      <a href="#">Contact Us</a>
      <a href="#">About Us</a>
      <a href="#">Result</a>
      <a href="#">Our Team</a>
    </nav>

    <div class="right">
      <img class="flag" src="bd.png" alt="BN" />
      <img class="flag" src="uk.png" alt="EN" />
      <div class="profile" title="Account">👤</div>
    </div>
  </div>
</div>

<!-- ===== Marquee (shows when top header is hidden) ===== -->
<div class="marquee" id="marquee">
  <div class="container marquee__inner">
    <span>আসসালামু আলাইকুম! ডেল্টা কম্পিউটার ট্রেনিং ইন্সটিটিউটে চলছে দারুণ অফার! এখনই সুযোগ—নিজেকে তৈরি করুন।</span>
  </div>
</div>

<script>
  // Hide top bar on scroll; show marquee
  const topHeader = document.getElementById('topHeader');
  const marquee  = document.getElementById('marquee');

  const toggleTop = () => {
    if (window.scrollY > 50) {
      if (topHeader.style.display !== 'none') topHeader.style.display = 'none';
      if (marquee.style.display !== 'block') marquee.style.display = 'block';
    } else {
      if (topHeader.style.display !== 'block') topHeader.style.display = 'block';
      if (marquee.style.display !== 'none') marquee.style.display = 'none';
    }
  };
  window.addEventListener('scroll', toggleTop);
  // initial state on load
  toggleTop();

  // Mobile menu
  const hamburger = document.getElementById('hamburger');
  const menu = document.getElementById('menu');
  hamburger.addEventListener('click', () => {
    menu.classList.toggle('open');
  });
</script>

</body>
</html>
