<?php
// register.php
require_once 'includes/config.php';
require_once 'includes/filemanager.php';

$error = null;

if ($_POST) {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $phone = $_POST['phone'] ?? '';

    // Handle photo upload
    $photoPath = null;
    $error = null; // Initialize error variable
    if (!empty($_FILES['photo']['name'])) {
        $uploadResult = uploadFile($_FILES['photo'], 'student_photo');
        if (isset($uploadResult['error'])) {
            $error = $uploadResult['error'];
        } else {
            $photoPath = $uploadResult['success'];
        }
    }

    if (!$error) {
        // Validate required fields
        if (empty($name)) {
            $error = "Name is required.";
        } elseif (empty($email)) {
            $error = "Email is required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } elseif (empty($password)) {
            $error = "Password is required.";
        } elseif (strlen($password) < 6) {
            $error = "Password must be at least 6 characters long.";
        }
    }

    if (!$error) {
        try {
            // Insert into users
            $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, 'student', 'active', NOW())");
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt->execute([$name, $email, $phone, $hashedPassword]);
            $userId = $pdo->lastInsertId();

            // Insert into profiles (optional)
            $pdo->prepare("INSERT INTO profiles (user_id, avatar_url, created_at) VALUES (?, ?, NOW())")
                ->execute([$userId, $photoPath]);

            // Optional: Link to students_admission if form has extra fields
            // You can extend this with Bangla name, father’s name, etc.

            header("Location: login.php?registered=1");
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Duplicate entry
                $error = "Email already exists. Please use a different email.";
            } else {
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <meta charset="utf-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #5a41d9;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
            background: #ffe6e6;
            padding: 10px;
            border-radius: 8px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input {
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }
        button {
            padding: 12px;
            background: #6a5af9;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #5347e0;
        }
        a {
            text-align: center;
            margin-top: 20px;
            color: #6a5af9;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Register as Student</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="text" name="phone" placeholder="Phone">
            <input type="file" name="photo" accept="image/*">
            <button type="submit">Register</button>
        </form>
        <a href="login.php">Already have an account? Login</a>
    </div>
</body>
</html>