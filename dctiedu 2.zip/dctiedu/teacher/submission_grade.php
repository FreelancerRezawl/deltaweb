<?php
// /teacher/submission_grade.php
declare(strict_types=1);

require_once '../includes/config.php';
require_once '../includes/auth.php';
@require_once '../includes/filemanager.php';

requireTeacher();

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$teacherId = (int)$_SESSION['user_id'];
$subId = isset($_GET['id']) && ctype_digit($_GET['id']) ? (int)$_GET['id'] : 0;

if ($subId <= 0) { http_response_code(400); echo "Invalid submission id."; exit; }

// Load submission + ownership check
try {
  $sql = "
    SELECT sub.id, sub.assignment_id, sub.student_id, sub.file_url, sub.text_answer, sub.grade, sub.feedback, sub.submitted_at,
           u.name AS student_name,
           a.title AS assignment_title,
           l.title AS lesson_title,
           c.title AS course_title,
           c.id    AS course_id
    FROM submissions sub
    JOIN assignments a   ON a.id = sub.assignment_id
    JOIN lessons l       ON l.id = a.lesson_id
    JOIN course_sections s ON s.id = l.section_id
    JOIN courses c       ON c.id = s.course_id
    JOIN users u         ON u.id = sub.student_id
    WHERE sub.id = ?
  ";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([$subId]);
  $sub = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$sub) { http_response_code(404); echo "Submission not found."; exit; }

  // Verify the teacher owns this course
  $own = $pdo->prepare("SELECT 1 FROM course_instructors WHERE course_id = ? AND user_id = ?");
  $own->execute([(int)$sub['course_id'], $teacherId]);
  if (!$own->fetchColumn()) { http_response_code(403); echo "Forbidden"; exit; }
} catch (PDOException $e) {
  http_response_code(500);
  echo "Database error occurred. Please contact administrator.";
  exit;
}

$ok = $err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    $grade = $_POST['grade'] ?? '';
    $feedback = trim((string)($_POST['feedback'] ?? ''));

    if ($grade === '') {
      $gradeVal = null;
    } else if (is_numeric($grade) && $grade >= 0 && $grade <= 100) {
      $gradeVal = (float)$grade;
    } else {
      $err = "Grade must be a number between 0 and 100 (or leave blank).";
    }

    if (!$err) {
      $upd = $pdo->prepare("UPDATE submissions SET grade = ?, feedback = ?, graded_at = NOW() WHERE id = ?");
      $upd->execute([$gradeVal, ($feedback !== '' ? $feedback : null), $subId]);
      $ok = "Saved.";
      // refresh displayed data
      $stmt->execute([$subId]);
      $sub = $stmt->fetch(PDO::FETCH_ASSOC);
    }
  } catch (PDOException $e) {
    $err = "Database error occurred while saving. Please try again.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Grade Submission</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root{--ink:#1a102c; --muted:#6c5a97; --panel:#fff; --brand:#7a4cff; --ring:rgba(122,76,255,.35); --radius:16px;}
  *{box-sizing:border-box} body{margin:0; font-family:Poppins,system-ui; color:var(--ink); background:#f3ecff;}
  .wrap{max-width:780px; margin:24px auto; padding:0 16px}
  .card{background:var(--panel); border:1px solid #eee; border-radius:var(--radius); box-shadow:0 8px 25px rgba(95,77,182,.12); padding:18px}
  h1{margin:0 0 12px} .muted{color:var(--muted)}
  .row{display:flex; gap:8px; align-items:center; justify-content:space-between}
  .field{display:grid; gap:6px; margin-top:12px}
  label{font-weight:600; font-size:13px}
  input, textarea{border:1px solid #e5e3f3; border-radius:12px; padding:10px 12px; font:500 14px Poppins; outline:none; background:#fff; width:100%}
  textarea{min-height:120px; resize:vertical}
  .btn{display:inline-block; padding:10px 14px; border-radius:10px; border:1px solid #dad2ff; background:#fff; color:#5b3bff; text-decoration:none; font-weight:600; font-size:13px}
  .btn.primary{background:var(--brand); color:#fff; border-color:transparent; box-shadow:0 6px 18px var(--ring)}
  .msg{padding:10px 12px; border-radius:12px; font-size:14px; margin-top:12px}
  .ok{background:#ecfff6; border:1px solid #b6f3d1}
  .err{background:#fff0f0; border:1px solid #ffc9c9}
</style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="row">
        <h1>Grade Submission</h1>
        <a class="btn" href="dashboard.php">Back</a>
      </div>
      <div class="muted" style="font-size:13px">
        <?= h($sub['student_name']) ?> • <?= h($sub['course_title']) ?> • <?= h($sub['lesson_title']) ?> • <strong><?= h($sub['assignment_title']) ?></strong>
        • Submitted <?= h(date('M d, Y H:i', strtotime($sub['submitted_at']))) ?>
      </div>

      <?php if ($ok): ?><div class="msg ok"><?= h($ok) ?></div><?php endif; ?>
      <?php if ($err): ?><div class="msg err"><?= h($err) ?></div><?php endif; ?>

      <form method="post">
        <div class="field">
          <label for="grade">Grade (0-100, leave blank for none)</label>
          <input type="number" name="grade" id="grade" min="0" max="100" step="0.01" value="<?= $sub['grade'] !== null ? h((string)$sub['grade']) : '' ?>">
        </div>
        <div class="field">
          <label for="feedback">Feedback (optional)</label>
          <textarea name="feedback" id="feedback" placeholder="Write feedback for the student..."><?= h((string)($sub['feedback'] ?? '')) ?></textarea>
        </div>
        <div class="field" style="margin-top:8px">
          <button class="btn primary" type="submit">Save</button>
        </div>
      </form>

      <?php if (!empty($sub['file_url'])): ?>
        <div class="field">
          <label>Attached file</label>
          <a class="btn" href="<?= h($sub['file_url']) ?>" target="_blank" rel="noopener">Open file</a>
        </div>
      <?php endif; ?>

      <?php if (!empty($sub['text_answer'])): ?>
        <div class="field">
          <label>Text answer</label>
          <div class="card" style="border-style:dashed">
            <div style="white-space:pre-wrap"><?= nl2br(h((string)$sub['text_answer'])) ?></div>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
