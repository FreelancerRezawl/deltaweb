<?php
// teacher/index.php
declare(strict_types=1);

require_once '../includes/config.php';
require_once '../includes/auth.php';
@require_once '../includes/filemanager.php';

requireTeacher();

$userId = (int)$_SESSION['user_id'];

/** Small helpers */
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function getUserData(PDO $pdo, int $id): array {
  $q = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
  $q->execute([$id]);
  return $q->fetch(PDO::FETCH_ASSOC) ?: [];
}

/** Handle quick actions (POST): create announcement, quick assignment */
$errors = [];
$notices = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['action']) && $_POST['action'] === 'create_announcement') {
    $courseId = isset($_POST['course_id']) && ctype_digit($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
    $title    = trim((string)($_POST['title'] ?? ''));
    $content  = trim((string)($_POST['content'] ?? ''));

    // validate course ownership
    $own = $pdo->prepare("SELECT 1 FROM course_instructors WHERE course_id = ? AND user_id = ?");
    $own->execute([$courseId, $userId]);
    $isMine = (bool)$own->fetchColumn();

    if (!$courseId || !$isMine) $errors[] = "Please select a valid course.";
    if ($title === '') $errors[] = "Title is required.";
    if ($content === '') $errors[] = "Content is required.";

    if (!$errors) {
      $ins = $pdo->prepare("INSERT INTO announcements (course_id, title, content, created_by) VALUES (?, ?, ?, ?)");
      $ins->execute([$courseId, $title, $content, $userId]);
      $notices[] = "Announcement posted.";
    }
  }

  if (isset($_POST['action']) && $_POST['action'] === 'create_assignment') {
    // Create a quick assignment under the first lesson of a chosen course section, or auto-create a section if missing
    $courseId = isset($_POST['a_course_id']) && ctype_digit($_POST['a_course_id']) ? (int)$_POST['a_course_id'] : 0;
    $title    = trim((string)($_POST['a_title'] ?? ''));
    $dueDate  = trim((string)($_POST['a_due_at'] ?? '')); // optional: 'YYYY-MM-DD HH:MM:SS'
    $inst     = trim((string)($_POST['a_instructions'] ?? ''));

    // verify ownership
    $own = $pdo->prepare("SELECT 1 FROM course_instructors WHERE course_id = ? AND user_id = ?");
    $own->execute([$courseId, $userId]);
    $isMine = (bool)$own->fetchColumn();

    if (!$courseId || !$isMine) $errors[] = "Please select a valid course for the assignment.";
    if ($title === '') $errors[] = "Assignment title is required.";

    if (!$errors) {
      $pdo->beginTransaction();
      try {
        // ensure at least one section exists
        $sec = $pdo->prepare("SELECT id FROM course_sections WHERE course_id = ? ORDER BY sort_order ASC, id ASC LIMIT 1");
        $sec->execute([$courseId]);
        $sectionId = (int)($sec->fetchColumn() ?: 0);
        if (!$sectionId) {
          $mkSec = $pdo->prepare("INSERT INTO course_sections (course_id, title, sort_order) VALUES (?, 'General', 0)");
          $mkSec->execute([$courseId]);
          $sectionId = (int)$pdo->lastInsertId();
        }

        // ensure at least one lesson exists (for linking assignment)
        $ls = $pdo->prepare("SELECT id FROM lessons WHERE section_id = ? ORDER BY sort_order ASC, id ASC LIMIT 1");
        $ls->execute([$sectionId]);
        $lessonId = (int)($ls->fetchColumn() ?: 0);
        if (!$lessonId) {
          $mkLesson = $pdo->prepare("INSERT INTO lessons (section_id, title, type, is_preview, sort_order) VALUES (?, 'Assignment Container', 'pdf', 0, 0)");
          $mkLesson->execute([$sectionId]);
          $lessonId = (int)$pdo->lastInsertId();
        }

        // create assignment
        $q = $pdo->prepare("INSERT INTO assignments (lesson_id, title, instructions, due_at) VALUES (?, ?, ?, ?)");
        $q->execute([$lessonId, $title, $inst !== '' ? $inst : null, $dueDate !== '' ? $dueDate : null]);

        $pdo->commit();
        $notices[] = "Assignment created.";
      } catch (Throwable $e) {
        $pdo->rollBack();
        $errors[] = "Failed to create assignment.";
      }
    }
  }
}

/** Current teacher */
$user = getUserData($pdo, $userId);
$avatarUrl = null;
if (function_exists('getFileUrl')) {
  try {
    // optional profile avatar
    $p = $pdo->prepare("SELECT avatar_url FROM profiles WHERE user_id = ?");
    $p->execute([$userId]);
    $avatar = $p->fetch(PDO::FETCH_ASSOC);
    if ($avatar && !empty($avatar['avatar_url'])) {
      $avatarUrl = getFileUrl($avatar['avatar_url']);
    }
  } catch (PDOException $e) {
    // Profiles table might not exist, continue without avatar
    $avatarUrl = null;
  }
}
$avatarInitials = strtoupper(substr((string)($user['name'] ?? 'T'), 0, 2));

/** Teaching: courses list */
try {
  $coursesStmt = $pdo->prepare("
    SELECT c.id, c.title, c.status, c.price_cents, c.currency, c.created_at,
           (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS students_count
    FROM course_instructors ci
    JOIN courses c ON c.id = ci.course_id
    WHERE ci.user_id = ?
    ORDER BY c.created_at DESC
    LIMIT 12
  ");
  $coursesStmt->execute([$userId]);
  $myCourses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  // Required tables might not exist
  $myCourses = [];
}

/** Gross earnings (success payments for my courses) */
try {
  $earnStmt = $pdo->prepare("
    SELECT COALESCE(SUM(p.amount_cents),0)/100.0 AS gross_amount,
           COUNT(*) AS txn_count
    FROM payments p
    WHERE p.status='success'
      AND p.course_id IN (SELECT course_id FROM course_instructors WHERE user_id = ?)
  ");
  $earnStmt->execute([$userId]);
  $earnings = $earnStmt->fetch(PDO::FETCH_ASSOC) ?: ['gross_amount'=>0, 'txn_count'=>0];
} catch (PDOException $e) {
  // Required tables might not exist
  $earnings = ['gross_amount'=>0, 'txn_count'=>0];
}

/** Lessons & assignments summary */
try {
  $summaryStmt = $pdo->prepare("
    SELECT
      (SELECT COUNT(*) FROM course_sections s WHERE s.course_id IN (SELECT course_id FROM course_instructors WHERE user_id=?)) AS sections_count,
      (SELECT COUNT(*) FROM lessons l WHERE l.section_id IN (SELECT id FROM course_sections WHERE course_id IN (SELECT course_id FROM course_instructors WHERE user_id=?))) AS lessons_count,
      (SELECT COUNT(*) FROM assignments a WHERE a.lesson_id IN (
          SELECT l.id FROM lessons l WHERE l.section_id IN (SELECT id FROM course_sections WHERE course_id IN (SELECT course_id FROM course_instructors WHERE user_id=?))
      )) AS assignments_count
  ");
  $summaryStmt->execute([$userId, $userId, $userId]);
  $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: ['sections_count'=>0,'lessons_count'=>0,'assignments_count'=>0];
} catch (PDOException $e) {
  // Required tables might not exist
  $summary = ['sections_count'=>0,'lessons_count'=>0,'assignments_count'=>0];
}

/** Latest submissions to my assignments */
try {
  $subStmt = $pdo->prepare("
    SELECT sub.id, sub.assignment_id, sub.student_id, sub.file_url, sub.text_answer, sub.grade, sub.submitted_at,
           u.name AS student_name,
           a.title AS assignment_title,
           l.title AS lesson_title,
           c.title AS course_title
    FROM submissions sub
    JOIN assignments a   ON a.id = sub.assignment_id
    JOIN lessons l       ON l.id = a.lesson_id
    JOIN course_sections s ON s.id = l.section_id
    JOIN courses c       ON c.id = s.course_id
    JOIN course_instructors ci ON ci.course_id = c.id AND ci.user_id = ?
    JOIN users u         ON u.id = sub.student_id
    ORDER BY sub.submitted_at DESC
    LIMIT 8
  ");
  $subStmt->execute([$userId]);
  $recentSubs = $subStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  // Required tables might not exist
  $recentSubs = [];
}

/** My course list (for forms dropdowns) */
try {
  $ddStmt = $pdo->prepare("
    SELECT c.id, c.title
    FROM course_instructors ci
    JOIN courses c ON c.id = ci.course_id
    WHERE ci.user_id = ?
    ORDER BY c.title ASC
  ");
  $ddStmt->execute([$userId]);
  $courseOptions = $ddStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  // Required tables might not exist
  $courseOptions = [];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Teacher Portal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root{
      --bg:#f3ecff;
      --panel:#ffffff;
      --ink:#1a102c;
      --muted:#7d6aa6;
      --brand:#7a4cff;
      --brand-2:#a47cff;
      --brand-3:#e9ddff;
      --ring: rgba(122,76,255,.35);
      --radius:18px;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0; background:linear-gradient(180deg,var(--bg),#efe7ff 60%, #e9e1ff);
      font-family:"Poppins", system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji","Segoe UI Emoji";
      color:var(--ink);
    }

    /* Layout */
    .viewport{
      min-height:100vh;
      width:100vw;
      display:grid;
      grid-template-columns: 300px 1fr;
      gap:24px; padding:24px;
    }
    @media (max-width:1040px){ .viewport{grid-template-columns:1fr; padding:16px;} }

    /* Sidebar */
    .sidebar{
      background:linear-gradient(160deg, #8b63ff, #6237ff 55%);
      border-radius:calc(var(--radius) + 6px);
      padding:22px 16px; color:#fff; position:sticky; top:24px;
      height:calc(100vh - 48px); overflow:auto;
      box-shadow:0 10px 30px rgba(83, 56, 255, .25);
    }
    @media (max-width:1040px){ .sidebar{position:static; height:auto; overflow:visible;} }
    .sb-brand{display:flex; align-items:center; gap:12px; padding:8px 12px; margin-bottom:10px;}
    .logo{width:46px; height:46px; border-radius:12px; background:#fff2; display:grid; place-items:center; box-shadow: inset 0 0 0 2px #ffffff22;}
    .logo svg{width:26px; height:26px; fill:#fff}
    .brand-title{font-weight:700; letter-spacing:.2px}
    .sb-nav{margin-top:12px}
    .sb-item{display:flex; align-items:center; gap:12px; color:#f0eaff; text-decoration:none; padding:12px 14px; border-radius:14px; font-weight:500; opacity:.95;}
    .sb-item svg{width:20px; height:20px; fill:#f0eaff}
    .sb-item:hover{background:#ffffff12}
    .sb-item.active{background:#fff; color:#5b3bff}
    .sb-item.active svg{fill:#5b3bff}
    .logout{margin-top:12px}
    .logout .sb-item{justify-content:center; background:#fff1;}

    /* Topbar */
    main{min-height:calc(100vh - 48px)}
    .topbar{display:flex; align-items:center; gap:16px}
    .search{flex:1; background:#fff; border-radius:999px; padding:10px 16px; display:flex; align-items:center; gap:10px; border:1px solid #eee; box-shadow:0 1px 0 rgba(0,0,0,.04);}
    .search input{border:none; outline:none; flex:1; font:500 14px Poppins; color:var(--ink)}
    .search svg{width:18px; height:18px; fill:#9b8ac6}
    .user-chip{display:flex; align-items:center; gap:10px; background:#fff; border-radius:999px; padding:6px 10px; border:1px solid #eee}
    .avatar{width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,#8fd2ff,#7a8bff); display:grid; place-items:center; color:#fff; font-weight:700}

    /* Banner */
    .banner{
      margin-top:20px; background:linear-gradient(130deg, var(--brand), var(--brand-2)); color:#fff; border-radius:var(--radius);
      padding:28px; position:relative; overflow:hidden; min-height:140px;
    }
    .banner::after{
      content:""; position:absolute; inset:auto -20% -30% -20%; height:160px; background:radial-gradient(circle at 50% 0%, #fff2 0 30%, transparent 31%), radial-gradient(circle at 20% 40%, #fff2 0 18%, transparent 19%), radial-gradient(circle at 80% 60%, #fff2 0 14%, transparent 15%); filter:blur(10px);
    }
    .banner h2{margin:0 0 8px; font-weight:700}
    .banner p{margin:0; opacity:.9}
    .date-tag{position:absolute; top:16px; left:16px; background:#ffffff1a; border:1px solid #ffffff30; padding:6px 10px; border-radius:999px; font-size:12px}

    /* Grid */
    .grid{display:grid; grid-template-columns:2fr 1fr; gap:24px; margin-top:24px;}
    @media (max-width:980px){ .grid{grid-template-columns:1fr;} }

    /* Cards */
    .card{background:var(--panel); border-radius:var(--radius); box-shadow:0 8px 25px rgba(95,77,182,.12); border:1px solid #eee}
    .card.pad{padding:18px}
    .section-title{font-size:18px; font-weight:700; margin:0 0 12px}
    .row{display:flex; align-items:center; justify-content:space-between; gap:8px}
    .muted{color:#6c5a97}
    .see-all{font-size:13px; color:var(--brand); font-weight:600; text-decoration:none}

    /* Stats */
    .finance-cards{display:grid; grid-template-columns:repeat(3, 1fr); gap:14px}
    @media (max-width:640px){ .finance-cards{grid-template-columns:1fr} }
    .mini{border-radius:16px; padding:16px; border:1px solid #eee; background:#fff; display:grid; gap:8px; align-content:start; position:relative}
    .mini.highlight{outline:3px solid var(--brand-3)}
    .stat-icon{width:38px; height:38px; border-radius:12px; background:linear-gradient(135deg,var(--brand-3),#fff); display:grid; place-items:center;}
    .stat-icon svg{width:22px; height:22px; fill:var(--brand)}
    .stat-value{font-weight:700; font-size:20px}
    .stat-label{font-size:13px; color:#6c5a97}

    /* Lists */
    .list{display:grid; gap:12px}
    .item{display:grid; grid-template-columns:1fr auto; gap:12px; align-items:center; padding:12px; border:1px solid #eee; border-radius:14px; background:#fff}
    .badge{display:inline-block; padding:2px 8px; border-radius:999px; font-size:12px; border:1px solid #eee; background:#faf7ff}
    .btn{display:inline-block; padding:8px 12px; border-radius:10px; border:1px solid #dad2ff; background:#fff; color:#5b3bff; text-decoration:none; font-weight:600; font-size:13px}
    .btn.primary{background:var(--brand); color:#fff; border-color:transparent; box-shadow:0 6px 18px var(--ring)}
    .btn.block{display:block; text-align:center}

    /* Forms */
    .form{display:grid; gap:10px}
    .field{display:grid; gap:6px}
    .field label{font-weight:600; font-size:13px}
    .input, select, textarea{border:1px solid #e5e3f3; border-radius:12px; padding:10px 12px; font:500 14px Poppins; outline:none; background:#fff}
    textarea{min-height:100px; resize:vertical}
    .msg{padding:10px 12px; border-radius:12px; font-size:14px}
    .msg.ok{background:#ecfff6; border:1px solid #b6f3d1}
    .msg.err{background:#fff0f0; border:1px solid #ffc9c9}
  </style>
</head>
<body>
  <div class="viewport">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sb-brand">
        <div class="logo" aria-hidden="true">
          <svg viewBox="0 0 24 24" role="img"><path d="M12 3 1 8l11 5 9-4.09V17h2V8L12 3Zm0 8.8L5.23 8.6 12 5.8l6.77 2.8L12 11.8ZM6 12.5v3.25C6 17.99 8.69 20 12 20s6-2.01 6-4.25V12.5l-6 2.5-6-2.5Z"/></svg>
        </div>
        <div>
          <div class="brand-title">DCti Edu</div>
          <div style="font-size:12px; opacity:.8">Teacher Portal</div>
        </div>
      </div>
      <nav class="sb-nav">
        <a class="sb-item" href="index.php"><svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>Overview</a>
        <a class="sb-item active" href="dashboard.php"><svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>Dashboard</a>
        <a class="sb-item" href="../student/dashboard.php"><svg viewBox="0 0 24 24"><path d="M4 6h16v2H4zM4 11h16v2H4zm0 5h10v2H4z"/></svg>Student View</a>
        <a class="sb-item" href="test.php"><svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>Test Portal</a>
        <a class="sb-item" href="db_check.php"><svg viewBox="0 0 24 24"><path d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 6c0 1.668 3.582 3 8 3s8-1.332 8-3M4 5c0 1.668 3.582 3 8 3s8-1.332 8-3"/></svg>DB Check</a>
        <a class="sb-item" href="../logout.php"><svg viewBox="0 0 24 24"><path d="M10 17v-3h4v3l4-4-4-4v3h-4V5H5v14h5Z"/></svg>Logout</a>
      </nav>
    </aside>

    <!-- Main -->
    <main>
      <div class="topbar">
        <div class="search">
          <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5Z"/></svg>
          <input placeholder="Search (coming soon)..." />
        </div>
        <div class="user-chip">
          <?php if ($avatarUrl): ?>
            <img class="avatar" src="<?= h($avatarUrl) ?>" alt="Avatar" style="width:34px; height:34px; object-fit:cover;">
          <?php else: ?>
            <div class="avatar"><?= h($avatarInitials) ?></div>
          <?php endif; ?>
          <div>
            <div style="font-weight:600; font-size:13px"><?= h($user['name'] ?? 'Teacher') ?></div>
            <div class="muted" style="font-size:12px">Teacher</div>
          </div>
        </div>
      </div>

      <section class="banner card">
        <div class="date-tag"><?= date('F j, Y') ?></div>
        <h2>Welcome back, <?= h($user['name'] ?? 'Teacher') ?>!</h2>
        <p>Manage your courses, assignments, and student submissions from one place.</p>
      </section>

      <?php if ($errors): ?>
        <div class="msg err" style="margin-top:16px">
          <?= h(implode(' ', $errors)) ?>
        </div>
      <?php endif; ?>
      <?php if ($notices): ?>
        <div class="msg ok" style="margin-top:16px">
          <?= h(implode(' ', $notices)) ?>
        </div>
      <?php endif; ?>

      <div class="grid">
        <!-- Left column -->
        <section class="card pad">
          <div class="row">
            <h3 class="section-title">Overview</h3>
          </div>
          <div class="finance-cards">
            <div class="mini">
              <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 18h18v2H3v-2Zm2-5h3v4H5v-4Zm5-3h3v7h-3V10Zm5-4h3v11h-3V6Z"/></svg></div>
              <div class="stat-value"><?= number_format((float)($earnings['gross_amount'] ?? 0), 2) ?> <?= h('BDT') ?></div>
              <div class="stat-label">Gross earnings (all-time)</div>
              <div class="muted" style="font-size:12px"><?= (int)($earnings['txn_count'] ?? 0) ?> payments</div>
            </div>
            <div class="mini highlight">
              <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4Z"/></svg></div>
              <div class="stat-value"><?= (int)count($myCourses) ?></div>
              <div class="stat-label">Active courses</div>
            </div>
            <div class="mini">
              <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 17h18v2H3v-2Zm0-7h18v2H3V10Zm0-7h18v2H3V3Z"/></svg></div>
              <div class="stat-value"><?= (int)($summary['assignments_count'] ?? 0) ?></div>
              <div class="stat-label">Assignments total</div>
              <div class="muted" style="font-size:12px"><?= (int)($summary['lessons_count'] ?? 0) ?> lessons • <?= (int)($summary['sections_count'] ?? 0) ?> sections</div>
            </div>
          </div>

          <div class="row" style="margin-top:22px">
            <h3 class="section-title">Your Courses</h3>
            <a class="see-all" href="#" onclick="alert('Add a courses.php later for full management');return false;">Manage</a>
          </div>
          <div class="list">
            <?php if ($myCourses): ?>
              <?php foreach ($myCourses as $c): ?>
                <div class="item">
                  <div>
                    <div style="font-weight:600"><?= h($c['title']) ?></div>
                    <div class="muted" style="font-size:12px">
                      Status: <span class="badge"><?= h($c['status']) ?></span>
                      • Students: <?= (int)$c['students_count'] ?>
                      • Price: <?= number_format(((int)$c['price_cents'])/100, 2) . ' ' . h($c['currency']) ?>
                    </div>
                  </div>
                  <a class="btn" href="#" onclick="alert('Hook to course edit page later');return false;">Open</a>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <div class="item">
                <div class="muted">No courses yet. Ask an admin to assign you as an instructor.</div>
              </div>
            <?php endif; ?>
          </div>
        </section>

        <!-- Right column -->
        <section class="card pad">
          <div class="row">
            <h3 class="section-title">Quick Actions</h3>
          </div>

          <div class="card pad" style="margin-bottom:14px">
            <h4 style="margin:0 0 10px">Post Announcement</h4>
            <form class="form" method="post">
              <input type="hidden" name="action" value="create_announcement">
              <div class="field">
                <label for="course_id">Course</label>
                <select name="course_id" id="course_id" required>
                  <option value="">-- Select Course --</option>
                  <?php foreach ($courseOptions as $opt): ?>
                    <option value="<?= (int)$opt['id'] ?>"><?= h($opt['title']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="field">
                <label for="title">Title</label>
                <input class="input" type="text" id="title" name="title" placeholder="Announcement title" required />
              </div>
              <div class="field">
                <label for="content">Content</label>
                <textarea id="content" name="content" placeholder="Write your announcement..." required></textarea>
              </div>
              <button class="btn primary" type="submit">Publish</button>
            </form>
          </div>

          <div class="card pad">
            <h4 style="margin:0 0 10px">Create Assignment (quick)</h4>
            <form class="form" method="post">
              <input type="hidden" name="action" value="create_assignment">
              <div class="field">
                <label for="a_course_id">Course</label>
                <select name="a_course_id" id="a_course_id" required>
                  <option value="">-- Select Course --</option>
                  <?php foreach ($courseOptions as $opt): ?>
                    <option value="<?= (int)$opt['id'] ?>"><?= h($opt['title']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="field">
                <label for="a_title">Assignment title</label>
                <input class="input" type="text" id="a_title" name="a_title" placeholder="e.g., Week 1 Homework" required />
              </div>
              <div class="field">
                <label for="a_due_at">Due at (optional)</label>
                <input class="input" type="datetime-local" id="a_due_at" name="a_due_at" />
              </div>
              <div class="field">
                <label for="a_instructions">Instructions (optional)</label>
                <textarea id="a_instructions" name="a_instructions" placeholder="Describe the task, grading, files allowed, etc."></textarea>
              </div>
              <button class="btn primary" type="submit">Create</button>
            </form>
          </div>
        </section>
      </div>

      <section class="card pad" style="margin-top:24px">
        <div class="row">
          <h3 class="section-title">Recent Submissions</h3>
          <a class="see-all" href="#" onclick="alert('Create submissions.php later');return false;">See all</a>
        </div>
        <div class="list">
          <?php if ($recentSubs): ?>
            <?php foreach ($recentSubs as $s): ?>
              <div class="item">
                <div>
                  <div style="font-weight:600"><?= h($s['student_name']) ?></div>
                  <div class="muted" style="font-size:12px">
                    <?= h($s['course_title']) ?> • <?= h($s['lesson_title']) ?> • <span class="badge"><?= h($s['assignment_title']) ?></span>
                    • Submitted: <?= h(date('M d, Y H:i', strtotime($s['submitted_at']))) ?>
                    <?php if ($s['grade'] !== null): ?> • Grade: <strong><?= h((string)$s['grade']) ?></strong><?php endif; ?>
                  </div>
                  <?php if (!empty($s['text_answer'])): ?>
                    <div class="muted" style="font-size:12px; margin-top:6px"><?= h(mb_strimwidth(strip_tags($s['text_answer']), 0, 120, '…','UTF-8')) ?></div>
                  <?php endif; ?>
                </div>
                <?php if (!empty($s['file_url'])): ?>
                  <a class="btn" href="<?= h($s['file_url']) ?>" target="_blank" rel="noopener">File</a>
                <?php else: ?>
                  <span class="badge">No file</span>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="item"><div class="muted">No recent submissions.</div></div>
          <?php endif; ?>
        </div>
      </section>

    </main>
  </div>
</body>
</html>
