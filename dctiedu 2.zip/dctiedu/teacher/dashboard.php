<?php
// teacher/dashboard.php - Enhanced Teacher Dashboard
declare(strict_types=1);

require_once '../includes/config.php';
require_once '../includes/auth.php';
@require_once '../includes/filemanager.php';

requireTeacher();

$userId = (int)$_SESSION['user_id'];

/** Helper Functions */
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function getUserData(PDO $pdo, int $id): array {
  $q = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
  $q->execute([$id]);
  return $q->fetch(PDO::FETCH_ASSOC) ?: [];
}

/** Handle Actions */
$errors = [];
$success = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['action'])) {
    switch ($_POST['action']) {
      case 'create_announcement':
        $courseId = (int)($_POST['course_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');

        if (!$courseId || !$title || !$content) {
          $errors[] = "All fields are required.";
        } else {
          try {
            $stmt = $pdo->prepare("INSERT INTO announcements (course_id, title, content, created_by) VALUES (?, ?, ?, ?)");
            $stmt->execute([$courseId, $title, $content, $userId]);
            $success[] = "Announcement created successfully!";
          } catch (PDOException $e) {
            $errors[] = "Failed to create announcement.";
          }
        }
        break;

      case 'create_assignment':
        $courseId = (int)($_POST['course_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $instructions = trim($_POST['instructions'] ?? '');
        $dueDate = trim($_POST['due_date'] ?? '');

        if (!$courseId || !$title) {
          $errors[] = "Course and title are required.";
        } else {
          try {
            $pdo->beginTransaction();

            // Create assignment
            $stmt = $pdo->prepare("INSERT INTO assignments (course_id, title, instructions, due_date) VALUES (?, ?, ?, ?)");
            $stmt->execute([$courseId, $title, $instructions ?: null, $dueDate ?: null]);

            $pdo->commit();
            $success[] = "Assignment created successfully!";
          } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Failed to create assignment.";
          }
        }
        break;
    }
  }
}

/** Get Dashboard Data */
$user = getUserData($pdo, $userId);

// Get courses taught by this teacher
try {
  $coursesStmt = $pdo->prepare("
    SELECT c.id, c.title, c.status, c.price_cents, c.currency,
           COUNT(e.id) as student_count,
           COUNT(DISTINCT a.id) as assignment_count
    FROM courses c
    LEFT JOIN course_instructors ci ON c.id = ci.course_id
    LEFT JOIN enrollments e ON c.id = e.course_id
    LEFT JOIN assignments a ON c.id = a.course_id
    WHERE ci.user_id = ?
    GROUP BY c.id
    ORDER BY c.created_at DESC
    LIMIT 10
  ");
  $coursesStmt->execute([$userId]);
  $courses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  $courses = [];
}

// Get recent submissions
try {
  $submissionsStmt = $pdo->prepare("
    SELECT s.id, s.submitted_at, s.grade, s.student_id,
           u.name as student_name,
           a.title as assignment_title,
           c.title as course_title
    FROM submissions s
    JOIN assignments a ON s.assignment_id = a.id
    JOIN courses c ON a.course_id = c.id
    JOIN course_instructors ci ON c.id = ci.course_id
    JOIN users u ON s.student_id = u.id
    WHERE ci.user_id = ?
    ORDER BY s.submitted_at DESC
    LIMIT 5
  ");
  $submissionsStmt->execute([$userId]);
  $recentSubmissions = $submissionsStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  $recentSubmissions = [];
}

// Get statistics
try {
  $statsStmt = $pdo->prepare("
    SELECT
      (SELECT COUNT(*) FROM courses c JOIN course_instructors ci ON c.id = ci.course_id WHERE ci.user_id = ?) as total_courses,
      (SELECT COUNT(*) FROM assignments a JOIN courses c ON a.course_id = c.id JOIN course_instructors ci ON c.id = ci.course_id WHERE ci.user_id = ?) as total_assignments,
      (SELECT COUNT(*) FROM submissions s JOIN assignments a ON s.assignment_id = a.id JOIN courses c ON a.course_id = c.id JOIN course_instructors ci ON c.id = ci.course_id WHERE ci.user_id = ?) as total_submissions,
      (SELECT COUNT(*) FROM submissions s JOIN assignments a ON s.assignment_id = a.id JOIN courses c ON a.course_id = c.id JOIN course_instructors ci ON c.id = ci.course_id WHERE ci.user_id = ? AND s.grade IS NOT NULL) as graded_submissions
  ");
  $statsStmt->execute([$userId, $userId, $userId, $userId]);
  $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  $stats = ['total_courses' => 0, 'total_assignments' => 0, 'total_submissions' => 0, 'graded_submissions' => 0];
}

// Get courses for dropdown
try {
  $courseOptionsStmt = $pdo->prepare("
    SELECT c.id, c.title
    FROM courses c
    JOIN course_instructors ci ON c.id = ci.course_id
    WHERE ci.user_id = ?
    ORDER BY c.title
  ");
  $courseOptionsStmt->execute([$userId]);
  $courseOptions = $courseOptionsStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  $courseOptions = [];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher Dashboard - DCti Edu</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #6366f1;
      --primary-dark: #4f46e5;
      --secondary: #f1f5f9;
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
      --gray-50: #f9fafb;
      --gray-100: #f3f4f6;
      --gray-200: #e5e7eb;
      --gray-300: #d1d5db;
      --gray-600: #4b5563;
      --gray-700: #374151;
      --gray-800: #1f2937;
      --gray-900: #111827;
      --white: #ffffff;
      --radius: 12px;
      --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
      --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      color: var(--gray-900);
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .header {
      background: var(--white);
      border-radius: var(--radius);
      padding: 24px;
      margin-bottom: 24px;
      box-shadow: var(--shadow-lg);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .header h1 {
      color: var(--gray-900);
      font-size: 28px;
      font-weight: 700;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--primary), var(--primary-dark));
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 600;
      font-size: 18px;
    }

    .user-details h3 {
      font-size: 16px;
      font-weight: 600;
      color: var(--gray-900);
      margin-bottom: 2px;
    }

    .user-details p {
      font-size: 14px;
      color: var(--gray-600);
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 32px;
    }

    .stat-card {
      background: var(--white);
      border-radius: var(--radius);
      padding: 24px;
      box-shadow: var(--shadow);
      border-left: 4px solid var(--primary);
    }

    .stat-card h3 {
      font-size: 32px;
      font-weight: 700;
      color: var(--gray-900);
      margin-bottom: 8px;
    }

    .stat-card p {
      color: var(--gray-600);
      font-size: 14px;
      margin-bottom: 16px;
    }

    .stat-card .icon {
      width: 48px;
      height: 48px;
      border-radius: var(--radius);
      background: var(--secondary);
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 16px;
    }

    .content-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 24px;
    }

    .card {
      background: var(--white);
      border-radius: var(--radius);
      padding: 24px;
      box-shadow: var(--shadow);
      margin-bottom: 24px;
    }

    .card h2 {
      font-size: 20px;
      font-weight: 600;
      color: var(--gray-900);
      margin-bottom: 16px;
    }

    .courses-list {
      display: grid;
      gap: 16px;
    }

    .course-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px;
      border: 1px solid var(--gray-200);
      border-radius: var(--radius);
      background: var(--gray-50);
    }

    .course-info h4 {
      font-weight: 600;
      color: var(--gray-900);
      margin-bottom: 4px;
    }

    .course-meta {
      display: flex;
      gap: 16px;
      font-size: 14px;
      color: var(--gray-600);
    }

    .badge {
      padding: 4px 8px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
    }

    .badge.active {
      background: var(--success);
      color: white;
    }

    .badge.inactive {
      background: var(--gray-300);
      color: var(--gray-700);
    }

    .btn {
      padding: 8px 16px;
      border: none;
      border-radius: var(--radius);
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      transition: all 0.2s;
    }

    .btn-primary {
      background: var(--primary);
      color: white;
    }

    .btn-primary:hover {
      background: var(--primary-dark);
    }

    .btn-secondary {
      background: var(--gray-100);
      color: var(--gray-700);
    }

    .btn-secondary:hover {
      background: var(--gray-200);
    }

    .form-group {
      margin-bottom: 16px;
    }

    .form-group label {
      display: block;
      margin-bottom: 6px;
      font-weight: 500;
      color: var(--gray-700);
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 12px;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius);
      font-size: 14px;
    }

    .form-group textarea {
      min-height: 100px;
      resize: vertical;
    }

    .alert {
      padding: 12px 16px;
      border-radius: var(--radius);
      margin-bottom: 16px;
    }

    .alert-success {
      background: #d1fae5;
      color: #065f46;
      border: 1px solid #a7f3d0;
    }

    .alert-error {
      background: #fee2e2;
      color: #991b1b;
      border: 1px solid #fecaca;
    }

    .submissions-list {
      display: grid;
      gap: 12px;
    }

    .submission-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px;
      border: 1px solid var(--gray-200);
      border-radius: var(--radius);
      background: var(--gray-50);
    }

    .submission-info h5 {
      font-weight: 500;
      color: var(--gray-900);
      margin-bottom: 2px;
    }

    .submission-meta {
      font-size: 12px;
      color: var(--gray-600);
    }

    @media (max-width: 768px) {
      .content-grid {
        grid-template-columns: 1fr;
      }

      .header {
        flex-direction: column;
        gap: 16px;
        text-align: center;
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      <h1>Teacher Dashboard</h1>
      <div class="user-info">
        <div class="avatar">
          <?= strtoupper(substr($user['name'] ?? 'T', 0, 1)) ?>
        </div>
        <div class="user-details">
          <h3><?= h($user['name'] ?? 'Teacher') ?></h3>
          <p>Teacher Portal</p>
        </div>
      </div>
    </div>

    <!-- Messages -->
    <?php if ($errors): ?>
      <?php foreach ($errors as $error): ?>
        <div class="alert alert-error">
          <?= h($error) ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <?php if ($success): ?>
      <?php foreach ($success as $msg): ?>
        <div class="alert alert-success">
          <?= h($msg) ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon">📚</div>
        <h3><?= $stats['total_courses'] ?? 0 ?></h3>
        <p>Total Courses</p>
      </div>
      <div class="stat-card">
        <div class="icon">📝</div>
        <h3><?= $stats['total_assignments'] ?? 0 ?></h3>
        <p>Total Assignments</p>
      </div>
      <div class="stat-card">
        <div class="icon">📊</div>
        <h3><?= $stats['total_submissions'] ?? 0 ?></h3>
        <p>Total Submissions</p>
      </div>
      <div class="stat-card">
        <div class="icon">✅</div>
        <h3><?= $stats['graded_submissions'] ?? 0 ?></h3>
        <p>Graded Submissions</p>
      </div>
    </div>

    <div class="content-grid">
      <!-- Main Content -->
      <div>
        <!-- My Courses -->
        <div class="card">
          <h2>My Courses</h2>
          <div class="courses-list">
            <?php if ($courses): ?>
              <?php foreach ($courses as $course): ?>
                <div class="course-item">
                  <div class="course-info">
                    <h4><?= h($course['title']) ?></h4>
                    <div class="course-meta">
                      <span>Students: <?= $course['student_count'] ?></span>
                      <span>Assignments: <?= $course['assignment_count'] ?></span>
                      <span class="badge <?= $course['status'] === 'active' ? 'active' : 'inactive' ?>">
                        <?= ucfirst($course['status']) ?>
                      </span>
                    </div>
                  </div>
                  <div>
                    <a href="#" class="btn btn-primary">Manage</a>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <p style="color: var(--gray-600); text-align: center; padding: 20px;">
                No courses assigned yet. Contact administrator.
              </p>
            <?php endif; ?>
          </div>
        </div>

        <!-- Recent Submissions -->
        <div class="card">
          <h2>Recent Submissions</h2>
          <div class="submissions-list">
            <?php if ($recentSubmissions): ?>
              <?php foreach ($recentSubmissions as $submission): ?>
                <div class="submission-item">
                  <div class="submission-info">
                    <h5><?= h($submission['student_name']) ?></h5>
                    <div class="submission-meta">
                      <?= h($submission['assignment_title']) ?> •
                      <?= h($submission['course_title']) ?> •
                      <?= date('M d, Y H:i', strtotime($submission['submitted_at'])) ?>
                    </div>
                  </div>
                  <div>
                    <?php if ($submission['grade'] !== null): ?>
                      <span class="badge active">Grade: <?= h($submission['grade']) ?></span>
                    <?php else: ?>
                      <a href="submission_grade.php?id=<?= $submission['id'] ?>" class="btn btn-primary">Grade</a>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <p style="color: var(--gray-600); text-align: center; padding: 20px;">
                No submissions yet.
              </p>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Sidebar -->
      <div>
        <!-- Quick Actions -->
        <div class="card">
          <h2>Quick Actions</h2>

          <!-- Create Announcement -->
          <form method="post" style="margin-bottom: 24px;">
            <input type="hidden" name="action" value="create_announcement">
            <h3 style="margin-bottom: 12px; font-size: 16px;">Create Announcement</h3>
            <div class="form-group">
              <label for="course_id">Course</label>
              <select name="course_id" id="course_id" required>
                <option value="">Select Course</option>
                <?php foreach ($courseOptions as $course): ?>
                  <option value="<?= $course['id'] ?>"><?= h($course['title']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="title">Title</label>
              <input type="text" name="title" id="title" required>
            </div>
            <div class="form-group">
              <label for="content">Content</label>
              <textarea name="content" id="content" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create Announcement</button>
          </form>

          <!-- Create Assignment -->
          <form method="post">
            <input type="hidden" name="action" value="create_assignment">
            <h3 style="margin-bottom: 12px; font-size: 16px;">Create Assignment</h3>
            <div class="form-group">
              <label for="course_id">Course</label>
              <select name="course_id" id="course_id" required>
                <option value="">Select Course</option>
                <?php foreach ($courseOptions as $course): ?>
                  <option value="<?= $course['id'] ?>"><?= h($course['title']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="title">Title</label>
              <input type="text" name="title" id="title" required>
            </div>
            <div class="form-group">
              <label for="instructions">Instructions</label>
              <textarea name="instructions" id="instructions"></textarea>
            </div>
            <div class="form-group">
              <label for="due_date">Due Date (Optional)</label>
              <input type="datetime-local" name="due_date" id="due_date">
            </div>
            <button type="submit" class="btn btn-primary">Create Assignment</button>
          </form>
        </div>

        <!-- Quick Links -->
        <div class="card">
          <h2>Quick Links</h2>
          <a href="index.php" class="btn btn-secondary" style="display: block; margin-bottom: 8px;">Main Dashboard</a>
          <a href="test.php" class="btn btn-secondary" style="display: block; margin-bottom: 8px;">System Test</a>
          <a href="db_check.php" class="btn btn-secondary" style="display: block; margin-bottom: 8px;">Database Check</a>
          <a href="../student/dashboard.php" class="btn btn-secondary" style="display: block; margin-bottom: 8px;">Student View</a>
          <a href="../logout.php" class="btn btn-secondary" style="display: block;">Logout</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
