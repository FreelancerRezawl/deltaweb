# Teacher Portal - DCti Edu

## Overview
The Teacher Portal provides teachers with a comprehensive dashboard to manage their courses, assignments, and student submissions.

## Files Structure

### Main Files
- `dashboard.php` - Main teacher dashboard with modern UI
- `index.php` - Overview page with detailed statistics
- `submission_grade.php` - Grade student submissions
- `test.php` - System diagnostic tool
- `db_check.php` - Database tables verification

## Features

### Dashboard (`dashboard.php`)
- **Statistics Overview**: Total courses, assignments, submissions, graded items
- **Course Management**: View and manage assigned courses
- **Recent Submissions**: Quick access to recent student work
- **Quick Actions**:
  - Create announcements
  - Create assignments
  - Quick links to other tools

### Overview (`index.php`)
- **Detailed Analytics**: Earnings, course statistics, assignment counts
- **Course Listings**: Detailed view of all courses with student counts
- **Recent Activity**: Latest submissions from students
- **Quick Forms**: Create announcements and assignments

### Grading (`submission_grade.php`)
- **Grade Submissions**: Review and grade student work
- **Provide Feedback**: Add comments and feedback
- **File Attachments**: View submitted files
- **Text Answers**: Review text-based submissions

## Navigation
- **Dashboard**: Main teacher interface
- **Overview**: Detailed statistics and analytics
- **Student View**: Switch to student perspective
- **Test Portal**: System diagnostics
- **DB Check**: Database verification

## Setup Requirements

### Database Tables Required
- `users` - User accounts
- `courses` - Course information
- `course_instructors` - Teacher-course assignments
- `enrollments` - Student enrollments
- `assignments` - Assignment details
- `submissions` - Student submissions
- `announcements` - Course announcements
- `profiles` - User profiles (optional)

### Permissions
- Teacher role must be assigned in the `users` table
- Teachers must be linked to courses in `course_instructors` table

## Usage

1. **Access**: Navigate to `/teacher/dashboard.php`
2. **Authentication**: Login required with teacher role
3. **Navigation**: Use sidebar to switch between sections
4. **Actions**: Use forms to create content and manage courses

## Troubleshooting

### HTTP 500 Errors
- Check database connection in `includes/config.php`
- Verify required tables exist using `db_check.php`
- Check PHP error logs for detailed error messages

### Missing Features
- Some features may require additional database tables
- Use diagnostic tools to identify missing components

## Security Features
- Role-based authentication
- Input validation and sanitization
- SQL injection protection via prepared statements
- XSS protection via htmlspecialchars

## Customization
- Modify CSS styles in the `<style>` section
- Update navigation links in sidebar
- Add new features by extending the existing structure
