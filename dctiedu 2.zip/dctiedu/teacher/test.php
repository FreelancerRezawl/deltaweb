<?php
// Simple test to check if teacher portal is working
require_once '../includes/config.php';
require_once '../includes/auth.php';

echo "<h1>Teacher Portal Test</h1>";

// Test database connection
try {
    $test = $pdo->query("SELECT 1");
    echo "<p style='color: green;'>✓ Database connection successful</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . $e->getMessage() . "</p>";
}

// Test session
session_start();
if (isset($_SESSION['user_id'])) {
    echo "<p style='color: green;'>✓ Session is working</p>";
} else {
    echo "<p style='color: orange;'>⚠ Session not set (this is normal if not logged in)</p>";
}

// Test requireTeacher function
if (function_exists('requireTeacher')) {
    echo "<p style='color: green;'>✓ requireTeacher function exists</p>";
} else {
    echo "<p style='color: red;'>✗ requireTeacher function missing</p>";
}

// Test getFileUrl function
if (function_exists('getFileUrl')) {
    echo "<p style='color: green;'>✓ getFileUrl function exists</p>";
} else {
    echo "<p style='color: red;'>✗ getFileUrl function missing</p>";
}

echo "<hr>";
echo "<p><a href='index.php'>Go to Teacher Dashboard</a></p>";
echo "<p><a href='../login.php'>Go to Login</a></p>";
