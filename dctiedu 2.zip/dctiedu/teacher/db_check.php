<?php
// Check database tables required for teacher portal
require_once '../includes/config.php';

echo "<h1>Database Tables Check</h1>";

$required_tables = [
    'users',
    'courses',
    'course_instructors',
    'enrollments',
    'payments',
    'course_sections',
    'lessons',
    'assignments',
    'submissions',
    'announcements',
    'profiles'
];

echo "<h2>Required Tables:</h2>";
foreach ($required_tables as $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✓ $table - EXISTS</p>";
        } else {
            echo "<p style='color: red;'>✗ $table - MISSING</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>✗ $table - ERROR: " . $e->getMessage() . "</p>";
    }
}

echo "<hr>";
echo "<h2>Database Connection Test:</h2>";
try {
    $pdo->query("SELECT 1");
    echo "<p style='color: green;'>✓ Database connection successful</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='test.php'>Back to Test Page</a></p>";
echo "<p><a href='index.php'>Go to Teacher Dashboard</a></p>";
